# Desvios a reportar no paper — a obrigação que substitui a emenda

> **Decisão do Toto, 2026-08-27T16:52 BRT: não emendar o registro por enquanto.** O
> pré-registro fica **como registrado**, e todo desvio é declarado no paper.
>
> Este arquivo existe porque essa escolha só é honesta se a obrigação sobreviver até o
> paper ser escrito. Em 27/08 não havia manuscrito do Paper 2 nem documento de desvios:
> a obrigação não tinha onde morar. Uma decisão de "reportar depois" sem lugar onde
> ficar registrada é uma decisão de **não reportar**, com atraso.

## O custo aceito, dito sem eufemismo

Enquanto isto não for reportado, o registro público (`10.5281/zenodo.22110203` e OSF
`yf7d2`) afirma coisas **falsas** — e, em **duas** linhas, está *pior* que a realidade
(seta ⬇). Atualizado 27/08 com o replay do pipeline real:

| o registro diz | o que se mediu | |
|---|---|---|
| `Δ_cut = 0,043` é *"the measured salience spread at the brief cut"* | não existe cut: o código não aplica limiar. O comparador é lexicográfico e `salience` só desempata `last_served` idêntico | ⬆ |
| a banda `{2,0 · 4,0 · 7,5}` está entre *"what does not move, and could not"* | **move**: 11 / 15 / 17 estados de 350, monótono. A unidade segue sem referente registrado, mas a banda **não** é vazia — e sua dose superior está **acima** da saturação, que fica em `(4,0 ; 4,4]` | ⬇ |
| a alocação é `117/39/39/39` | suspensa junto com a banda — e a razão de suspender mudou: não é que as doses sejam indistinguíveis, é que a escala não tem referente | ⬆ |
| *(v1.12 §5)* a designação é defeito **aberto** | **fechada** em 26/08 20:28Z, com precedência verificável de 1.056 s | ⬇ |

⚠️ **As duas linhas ⬇ são as que mais incomodam,** e são as que o tempo não conserta.
As ⬆ superestimam o desenho: quem ler vai achar o estudo mais forte do que é, e a
correção só melhora a percepção do rigor. As ⬇ fazem o contrário — o registro afirma
que o parâmetro não tem efeito quando tem, e que um defeito está aberto quando foi
fechado. Quem ler daqui a um ano vai acreditar nas duas.

⚠️ E a linha da banda mudou de status **por causa de um defeito de instrumento meu**,
não por dado novo: o controle positivo que produziu o "não move" rodava sobre um pool
reimplementado. Isso é matéria do §5, não nota de rodapé.

## O que o paper tem de carregar

Fonte integral: `AMENDMENT-DRAFT-band-collapse-2026-08-26.md` (retratações 29–44) e
`REMEDIATION-2026-08-27.md`. O resumo abaixo é índice, não substituto.

### 1. O achado estrutural — 🔴 PARCIALMENTE REVERTIDO em 27/08

> ⚠️ **O que estava escrito aqui vinha de um controle positivo rodado sobre um pool
> REIMPLEMENTADO.** O replay do pipeline real
> (`REPLAY-OPORTUNIDADE-2026-08-27.md`, fidelidade 350/350 contra a produção)
> mediu o contrário em três pontos. O texto original fica abaixo, riscado, porque
> retratação apagada não é retratação.

**O que sobrevive, e é dedutivo:** o boost é aditivo em `salience`, a coordenada
**subordinada** de um comparador lexicográfico — quando `last_served` difere,
`salience` nunca é consultada. Isso é verdade, é o que produz a **saturação**, e é
o que impede o parâmetro de ter alcance ilimitado.

**O que cai:**

| ~~o registro e a emenda dizem~~ | medido no pipeline real (9 doses × 350 estados) |
|---|---|
| ~~`w = 100.000` dá `churn` **0**~~ | churn **20**, em **17 de 350** estados |
| ~~"o parâmetro não está na coordenada que decide"~~ | decide **dentro** do estrato — e é lá que a medida de desfecho vive |
| ~~as duas doses superiores são "indistinguíveis por construção do dado"~~ | `2,0 → 11`, `4,0 → 15`, `7,5 → 17` estados: **distinguíveis** |

A resposta é **monótona** — e monótona em cada um dos 350 estados, não só no
agregado (0 → 5 → 8 → 11 → 15 → 17 estados para `w = 0 / 0,5 / 1 / 2 / 4 / 7,5`) —
e **satura**. O teto do canal é **17/350 = 4,86%**. E `w = 2` reproduz o
`11/350 = 3,1429%` publicado: o replay é fiel também no agregado.

⚠️ **O ponto de saturação está em `(4,0 ; 4,4]`, não em 7,5.** Com grid de 23 doses
sobre os 17 estados, o maior limiar individual é `w_min = 4,4` (mediana 1,7, mínimo
0,02 — espalhamento de 220×). O "7,5" era o ponto seguinte de um grid grosso, e a
aparente coincidência com o topo da banda registrada era o instrumento, não o
sistema. **A banda registrada tem, portanto, a dose superior ACIMA da saturação** —
`7,5` e qualquer valor maior são indistinguíveis entre si, mas `4,0` e `7,5`
continuam distinguíveis (15 vs 17 estados).

⚠️ **Isto é a segunda linha em que o registro público está PIOR que a realidade** —
afirma que o parâmetro não tem efeito quando tem. Como a designação (§2), não se
conserta com o tempo: quem ler vai supor que o canal é vazio.

**A quantidade de gap intra-estrato segue publicada e foi CONFIRMADA** — 38 pares
adjacentes, 11 zeros, 27 positivos, máximo 0,031808734967844865, reproduzidos exatos
pela harness nova. Mas o paper **não pode** usá-la para argumentar sobre a banda, por
duas razões medidas em 27/08:

1. aquele máximo é da coluna **filtrada** (só pares em que ao menos um chunk é do
   estudo). Sem filtro, no mesmo pool e instante, é **0,05272**. O boost move o
   designado para além de quem estiver acima dele, seja do estudo ou não;
2. e nenhuma das duas colunas **cota** o mecanismo: o maior `w_min` (4,4) vale boost
   `0,0946` em S1, **1,79×** o maior passo adjacente do pool. A grandeza que governa é
   a **distância** até os 2 slots de cobertura, não o **passo** até o vizinho.

⚠️ E a hipótese de que os gaps maiores viessem do sub-pool do **agente** está
**refutada**: em `T_REF` o sub-pool do agente é **vazio** — 265/6.001/3.011 chunks de
`sessions/<agente>/%` passam o piso de importance e **zero** passam a janela de 7 dias.
`interleaveFresh([], global) === global`: todo o canal é o sub-pool global. Isso é fato
sobre aquele instante, e uma rajada de sessões muda a composição do canal sob os pés do
estudo — o que o paper tem de declarar como ameaça.

### 2. O que a designação fechou, e como

Sorteio com seed declarada: drand quicknet **31657512** (emissão 20:25:00Z), declaração
pushada **20:07:24Z** — **1.056 s** de precedência, com a rodada devolvendo HTTP 425 na
escrita, e o frame de 55 linhas depositado **antes** da aleatoriedade existir. Um
revisor independente rederivou os 19 designados só com o beacon público e o CSV.

⚠️ **A precedência não depende do depósito** — está no timestamp do GitHub e na rodada
drand. Adiar o registro não a enfraquece. Foi isso que tornou a opção 2 viável.

### 3. As comparações que NÃO identificam nada, e por quê

Na janela fechada `[2026-08-26T20:28:00Z , 2026-08-27T09:00:00Z)`: **11/350 = 3,1429%**
(Wilson [1,76; 5,54]). Último dia da regra anterior: 20/574 = 3,4843%.

| comparação | diferença | Fisher | uso |
|---|---|---|---|
| contra o agregado pós-gate (132/2.226) | −2,79 pp | **p = 0,0326** | ⛔ **não usar** — mede composição de dias |
| contra o último dia | −0,34 pp | p = 0,8523 | a defensável, e subpotente (~7%) |

A série anterior é declinante (13,64% → 7,29% → 3,13% → 3,48%) e 23+24/08 concentram
**69% dos eventos em 44% do n**. A "redução significativa" vem inteira de incluir os
dois primeiros dias. **O paper não pode reportar a agregada como efeito**, e a adjacente
não estabelece aumento, redução nem equivalência.

### 4. Os defeitos que ficam abertos

- ✅ **FECHADO 27/08 — oportunidade agora corresponde ao pipeline.**
  `measurement/replay-oportunidade.mjs` importa `buildBriefDiverse` do `dist` e
  reproduz a produção em **350 de 350** briefs da janela fechada (composição do
  controle, `churn`, `would_enter`, `would_leave`; zero inventado, zero perdido).
  Os `5/44` grupos qualificáveis seguem **não** sendo a oportunidade do código —
  a do código é `11/350` em `w = 2` e tem teto de `17/350`. Detalhe em
  `REPLAY-OPORTUNIDADE-2026-08-27.md`.
- **Auto-extinção NÃO testada.** A série reconstruída é toda anterior ao tratamento.
- **`last_served` não é congelado pelo snapshot de epoch** e realimenta: o tratamento em
  `T` altera a estrutura de grupos em `T+1`. Interage com a **F1** (carry-over).
- **Nada é randomizado.** Toda comparação é antes/depois.

### 5. Os defeitos de instrumento — e reportá-los é parte do método

O paper perde a contribuição declarada se omitir isto, porque a contribuição **é o
método**:

- a "descontaminação" fazia rollback temporal: 3.735 linhas removidas para excluir 25;
- eram **cinco** sondas e 25 linhas, não três e 15 — duas delas 55 s depois de o
  mecanismo subir, porque **verificavam** que ele subira;
- `julianday('now')` em três scripts fazia a população elegível mudar a cada execução;
- uma janela ficou **aberta** por cima e o `11/310` publicado envelheceu para 359;
- um commit citado (`0087c918`) **não existia**: o nome morreu numa reconciliação de
  histórico enquanto o conteúdo sobreviveu;
- duas correções que a revisão adversarial me levou a propor estavam **erradas**, e o
  rascunho certo — vinham do rollback, não da exclusão das sondas.
- **no serving, `julianday('now')` decide a população elegível** apesar de a função
  receber `nowMs` por argumento: o brief não é função pura de (corpus, serve-state,
  `nowMs`);
- **`brief_log.served_at` tem resolução de segundo** e 46,9% dos briefs dividem o segundo
  com outro. Nenhum corte temporal reproduz o estado; sob corte estrito o replay inventa
  churn 3× e perde 1×, e a contagem de desfecho sai **14 em vez de 12**. O corte tem de
  ser por `brief_log.id` (`AUTOINCREMENT`);
- **`ordenarCobertura` descarta `lastServedMs` do que devolve**, então agrupar pela chave
  que ordenou o pool dá um grupo só, em silêncio;
- **o controle positivo publicado media o instrumento, não o sistema** — e produziu o
  número que virou a retratação central. Ver §1;
- **grid grosso produziu um ponto de saturação neat demais.** Um salto de `w = 4` para
  `7,5` fez a saturação *parecer* cair exatamente no topo da banda registrada. Com 23
  doses ela está em `(4,0 ; 4,4]`. Eu sinalizei a coincidência como suspeita antes de
  saber a razão, e a razão era a mais chata possível: resolução do meu grid;
- **o gatilho de saturação do item 7 vigia a grandeza errada.** Foi calibrado sobre gap
  entre **adjacentes** (`0,0318`, "margem 1,35× contra `Δ_cut`"), mas o mecanismo exige
  vencer a **distância** até os 2 slots de cobertura: o maior `w_min` observado vale
  1,79× o maior passo adjacente do pool. O gatilho pode ficar verde enquanto o canal
  satura. *Substituído 27/08 por uma identidade — `churn(w_servido) == churn(w_absurdo)` —
  e estendido a `active` em 28/08, quando a dose passa a vir do `ASSIGNMENT.json`;*
- **um gatilho de braço único não distingue controle sorteado de resolução falhada.**
  `resolverBraco` devolve controle em *toda* falha, por desenho — o que é a escolha
  certa para servir e a errada para vigiar: enviesa o estudo para o nulo e não deixa
  rastro. Só se resolve **cruzando** o `ASSIGNMENT` com o log de serving, e essa
  conferência não existia até 28/08;
- **a composição do canal não está vigiada por nada.** O sub-pool do agente está vazio
  por idade em `T_REF`; se voltar a encher, `interleaveFresh` deixa de ser função-zero e
  a escala de dose muda sem que nenhum alarme dispare.

### 6. Procedência, para o paper não repetir o erro que descreve

Toda medição citada precisa de **`T_REF` + caminho do snapshot de corpus + janela
fechada**, e de reprodução de âncora publicada antes de variar qualquer coisa. Sem os
três, a tabela envelhece para falsa — foi o que aconteceu duas vezes aqui.

### 7. Alegações retiradas em 2026-08-29, e por quê

Três, todas no Paper A (o diagnóstico observacional), todas achadas por revisão
adversarial ou por recomputar o que estava em prosa. **Nenhuma foi retirada por ter sido
refutada por dado novo** — as três foram retiradas por *não estarem estabelecidas pelo
dado que existia*, que é uma classe diferente e mais incômoda.

| alegação retirada | por quê | o que ficou no lugar |
|---|---|---|
| `β = −0,961 ⇒ ×0,38 por década de tamanho` | o eixo de tamanho tem um vazio: **zero** tipos entre n=53 e n=1.046, 32,1% da amplitude sem um único ponto. "Por década" convida à leitura pontual numa faixa sem observação | o contraste entre as duas nuvens — 5 tipos grandes em 10,7–27,0%, 8 dos 10 pequenos acima de 32,5% |
| "o teste **separa** curadoria de tamanho" (§4.2) | não separa. As parciais controlam idade, importância média e comprimento de texto; **nenhuma é curadoria**, e o corpus não tem variável que a meça | declaração explícita de que os dois seguem confundidos por construção |
| "8.928 fragmentos de sessão de **205** caracteres" | os 205 são a média de **todos os 14.456 `distilled` do corpus**, não a dos 8.928 que a frase nomeia — que é **232**. Número certo, população errada | o número do subconjunto, com a população nomeada e artefato |

⚠️ **A terceira merece nota de método**, porque é a que o paper descreve acontecendo com
outros: a frase vinha de consulta *ad hoc* de 27/08 que não deixou artefato, e sobreviveu
a três revisões adversariais — nenhuma das quais tinha como recomputá-la. Só apareceu
quando o número virou script, dois dias depois, por outro motivo. **Prosa que afirma
resultado calculado é cache sem invalidação**, e a demonstração é esta.

Em contrapartida, uma alegação foi **promovida** no mesmo dia, e o desvio é simétrico:
"dos 13.388 chunks que passam o piso de relevância do próprio sistema, 10.008 = 74,75%
nunca foram expostos" estava enterrada num aviso e virou co-manchete do §4.1. A objeção
que a motivou (a taxa é incondicional; chunks jovens não tiveram oportunidade) foi medida
e **aponta para o lado oposto**: a coorte com oportunidade máxima é a mais não-exposta.
Corrigir pela censura temporal aumentaria a taxa reportada.

### 8. Uma afirmação de completude falsa no manifesto da v1.12 (achada em 30/08)

`SERVING-CODE-MANIFEST.md` argumenta — corretamente — que hash de commit não sobrevive
a uma reconciliação de histórico, e conclui: *"é por isso que **toda linha acima**
carrega o sha256 dos bytes do arquivo — esse pino sobrevive a qualquer reescrita, e é o
que um leitor pode conferir contra o blob depositado sem acesso ao repositório
privado."*

**Três das seis linhas não carregavam sha256.** As da segunda tabela traziam só o hash
de commit — o pino que o próprio parágrafo acabara de declarar instável. O leitor que
aceitasse a promessa e fosse conferir `serving-brief-diversity.ts` contra o blob
depositado não teria contra o que conferir, e precisaria exatamente do acesso que a
frase promete dispensar.

O arquivo mais exposto pela lacuna é o mais citado: `serving-brief-diversity.ts` carrega
o `DIVERSITY_DEFAULTS`, de onde sai o piso 0,7/0,7 de uma das duas manchetes.

**Remediação, sem tocar no registro.** Os três `sha256` foram computados sobre os blobs
da tag `paper2-v1.12` — byte a byte idênticos aos arquivos em disco, conferido por
`git show paper2-v1.12:… | shasum -a 256` — e acrescentados ao manifesto no repositório:

| arquivo | bytes | sha256 |
|---|---|---|
| `serving-brief-diversity.ts` | 8712 | `34c9aee5f80311c8aff5c0ae35f37dd6dbf52f31a9f940b01cdb8d205c69e7a2` |
| `serving-salience.ts` | 12553 | `083399fc190920ff8f2a590bd74876e25b1f95552515977920edb64025924684` |
| `serving-search.ts` | 29622 | `d76034e2b7796744ae5836af02c5a1155ddc5750f0fa2d94875f63b9b1b723d3` |

A v1.12 depositada permanece como está. Os valores acima pinam os mesmos bytes, então
quem for conferir o depósito consegue.

⚠️ **Por que nenhuma das seis revisões adversariais pegou.** Todas leram o parágrafo
como argumento, e o argumento está certo — hash de commit realmente não é pino estável.
O defeito não estava na tese, e sim no **alcance do quantificador**: "toda linha acima"
foi escrito olhando a primeira tabela e passou a quantificar as duas. É uma classe que
revisão não vê, porque exige contar linhas de tabela contra uma palavra, e nova para
este catálogo: as anteriores eram rótulo divergindo do predicado, não quantificador
divergindo do escopo.

### 9. O corpus congelado do Paper 2 não existe — e os episódios adjudicados também não

`CORPUS-FREEZE.md` declara que a reprodução roda contra
`action-archive-20260729T094609Z.tar.gz` (107 MB, 5.547 episódios, `sha256 ba5fcc81…`),
em `/var/backups/nox-mem/paper2-corpus/` com modo `0400`, e afirma: *"quem reproduzir a
partir deste snapshot obtém 5.547 episódios"*.

Procurado em 2026-08-30 por **nome**, por **tamanho** (~107 MB) e por **`sha256`** em
toda a máquina de serving: não existe, e o diretório também não.

🔴 **E a consequência é maior que a perda de reprodutibilidade:** dos **280** episódios
adjudicados em `p2_verdict`, **zero** estão no archive vivo. O painel julgou 280
episódios que hoje ninguém pode ler. As 55 lições e os 19 grupos de designação existem
como veredito sem evidência — `sig_primary`, `severity` e `chunk_id` sobreviveram na
tabela; o material que os justificava, não.

**O que sobreviveu:** a `sig()`. `extract_episodes.py` tem `sha256 e860357bd9f1fc06…`,
idêntico ao congelado no pré-registro. A taxonomia é reproduzível; o corpus sobre o qual
foi derivada, e o material que o painel viu, não são.

⚠️ **Por que isto entra no paper e não numa nota operacional.** É a **terceira** ocorrência
da mesma classe em três dias — o corpus do teto (rotacionado, §5.7.2), os três `.ts`
pinados por hash de commit (recuperados, §8) e este. Um paper cuja tese metodológica é
que a verificação precisa ser mecânica não pode omitir que a sua própria disciplina de
congelamento falhou três vezes, e sempre do mesmo modo: **pinar o identificador de um
artefato não o preserva**. A regra que sai disto, e que vale para todo depósito futuro, é
depositar o **blob**, não o hash.

### 10. O Epoch 1 é heterogêneo, e o braço de controle não deixa rastro (2026-09-01/03)

Dois desvios que só apareceram com o ensaio no ar. O primeiro é de execução; o segundo
é de instrumento e o mais consequente dos dois.

#### 10.1 O Epoch 1 tem 42 briefs servidos como CONTROLE dentro de um epoch de tratamento

A fronteira do epoch é **09:00 UTC** (`epochInicioISO`, `brief-outcome.ts`), e a
ativação aconteceu às **10:25:39Z** — uma hora e vinte e cinco minutos depois de o
epoch abrir. Nesse intervalo o serving ainda estava em `shadow`, e os briefs foram
servidos como controle. Medido no log:

| epoch | n | modo | w | servido |
|---|---:|---|---|---|
| 2026-08-29 | 672 | `shadow` 672 | 2 | controle 672 |
| 2026-08-30 | 672 | `shadow` 672 | 2 | controle 672 |
| 2026-08-31 | 672 | `shadow` 672 | 2 | controle 672 |
| **2026-09-01** | **672** | **`shadow` 42 · `active` 630** | **2 e 4** | **controle 42 · tratado 630** |

**6,25% do Epoch 1 recebeu o braço errado.** O gatilho `p2-saturacao-da-dose` acusou
corretamente em 09-02 09:12Z: `modo-no-log=['active','shadow'] != active`.

⚠️ **A ativação não foi tardia por descuido — foi adiada de propósito, e o adiamento
evitou um defeito pior.** Às 07:08Z o epoch corrente era `2026-08-31`, data ausente da
sequência de atribuição; ligar ali faria `resolverBraco` devolver
`epoch ... ausente da sequência` e servir controle em **todo** brief por 1h52, com
`systemctl is-active` dizendo `active`. Esperar até depois das 09:00Z era o certo. O que
faltou foi ligar **na** fronteira, não depois dela.

##### A escolha de análise, FECHADA em 2026-09-04 sem que desfecho algum fosse consultado

> **Precedência.** Decidido em **2026-09-04**, com o ensaio no seu quarto epoch. Nenhum
> desfecho foi computado, consultado ou estimado antes desta decisão — nem por mim nem a
> pedido meu. O que foi medido para decidir é **exclusivamente estrutura de exposição**:
> quantos briefs, em que braço, em que instante, lidos do log de serving. A densidade de
> falhas repetidas, que é o desfecho, não foi tocada. Quem auditar pode conferir pelo
> `git log` que este parágrafo antecede qualquer artefato de desfecho no repositório.

✅ **A decisão usa a estrutura que o registro JÁ tem, em vez de criar uma paralela.**
`PREREG-DRAFT.md` §"Mandatory ITT co-estimate" determina que *"the primary is reported
alongside an intention-to-treat estimate over all post-washout epochs with no coverage
exclusion whatsoever. Agreement between the two is the strength of the claim; divergence
is reported as-is and is not adjudicated in favour of either."* A disciplina de reportar
duas análises, tratar concordância como força e divergência como achado não-adjudicado,
portanto, **é registrada, não inventada agora**.

> ⚠️ A primeira redação desta seção dizia "primária: ITT", o que **renomeava** a
> estrutura registrada — ali o *primary* é distinto do co-estimador ITT. Corrigido no
> mesmo dia, ao reler o §1042. Registrado porque descrever errado o próprio plano de
> análise é o defeito que este documento existe para não cometer.

**A decisão, então, é de inclusão e não de estrutura:** o Epoch 1 **não é excluído** nem
do *primary* nem do co-estimador ITT. Os seus 672 briefs entram no braço `w = 4,0`
conforme designado, incluindo os 42 servidos como controle.

**Acrescenta-se uma terceira análise, pré-especificada aqui:** o mesmo par de estimativas
com o Epoch 1 excluído, reportado sob a mesma regra do §1042 — concordância é força,
divergência é reportada como está e não é adjudicada a favor de nenhuma das duas.

**Por que ITT e não descartar.** O custo estatístico de descartar é desprezível — a
alocação é `117/39/39/39`, o Epoch 1 é `w = 4,0`, logo seria 1 de 39, e com o *design
effect* de 21,9 (ICC 0,0985) o epoch é a unidade efetiva: o erro-padrão inflaria
`√(39/38)` = **1,3%**. A decisão, portanto, **não é sobre poder**.

O que decide é outra coisa: a lista registrada de eventos intercorrentes tem **três**
entradas — epochs anulados pela regra de aborto, *downtime* da frota, e epochs sobrepostos
a intervenção manual de memória em `ops_audit` (PREREG §5). **Contaminação parcial de
braço não está entre elas.** Descartar o Epoch 1 significaria criar critério de exclusão
novo com o ensaio já em curso, que é precisamente o grau de liberdade que o pré-registro
existe para eliminar. Pagar 1,3% de intervalo por manter a lista intacta é troca boa.

E a direção do viés é conhecida: 6,25% de um epoch de tratamento recebeu controle, o que
**atenua** a diferença medida. Se houver efeito, a contaminação não o fabricou; se não
houver, ela está declarada entre as razões. ITT é conservadora nas duas pontas — e é por
isso que a sensibilidade importa: se as duas análises concordam, a contaminação é
irrelevante e isso fica demonstrado; se divergem, a divergência é o achado, e foi
pré-especificada antes de ser vista.

**Por que os 42 não são reatribuídos ao controle.** Seria análise *per-protocol*, e
quebraria a randomização: esses 42 não são um subconjunto aleatório do controle, são a
primeira hora e meia de um dia específico. A designação do braço vem do sorteio, não do
que o serving fez.

⚠️ **O epoch contaminado não está no braço que carrega a hipótese principal.** `w = 4,0`
é a dose intermediária; a condição de detectabilidade (§2 do registro prospectivo) mostra
que a dose que testa H1 é `w = 2,0`, onde apenas **3,14%** dos briefs mudam de composição.
Isso enfraquece ainda mais o caso para descartar, e é observação de desenho, não de
resultado.

**Para os 233 epochs restantes o problema não se repete:** a transição de modo já
aconteceu e não há outra prevista. Um reinício do serviço no meio de um epoch **não**
recria o defeito — o modo vem do drop-in e a designação do `ASSIGNMENT-SERVING.json`.

#### 10.2 O braço de controle não produz nenhuma linha de log

Os epochs `2026-09-02` e `2026-09-03` são `control`/`w=0` por sorteio, e o log de
serving não tem **uma única linha** deles. Não é falha: é o que o código faz.

```ts
if (provedorDeBoost && cfg.freshSlots > 0) { … altBoosted = … }   // brief.ts:836
if (logDiff && diffP2 && altBoosted) { logarDecisaoDeServing({…}) }   // brief.ts:980
```

Sem boost não há `provedorDeBoost`; sem ele não há `altBoosted`; sem `altBoosted` não há
linha. Consequências, em ordem de gravidade:

1. **o `n` do braço de controle não é observável** — 117 dos 234 epochs são controle, e
   nenhum deles deixa registro de quantos briefs serviu;
2. **não se pode auditar que o controle foi servido corretamente** — a ausência de linha
   é compatível com "serviu controle como devia" e com "não serviu nada";
3. **"epoch de controle" é indistinguível de "serving parado"** — foi a primeira leitura
   ao ver o log parar em 09-02T08:52Z, e foram necessárias três medições para descartar.

É a mesma classe da regra 9 do `CLAUDE.md`: o gatilho que mede a janela precisa do dado,
e o dado não existe em controle.

⚠️ **O crédito de o silêncio não ter sido total é do `YELLOW n=0`.** O gatilho tem uma
perna que alarma quando a janela vem vazia — `janela-com-n-insuficiente n=0 minimo=30`,
disparada em 09-03 09:12Z. Sem ela, 117 epochs de controle passariam calados e o silêncio
pareceria saúde.

**Correção classificada como instrumentação, não emenda**, e a razão é verificável: a
linha nova registra o que **já** é servido, não altera designação, dose, ordenação nem
composição. Nenhum braço muda de conteúdo. O que muda é haver registro do que antes não
tinha. Declarado aqui em vez de emendado no registro, pela decisão do item 7.

#### 10.3 O morning report lê um status escrito 21 horas antes

`morning-report.sh` roda **06:30** e `run-saturacao.sh` roda **09:12**. O report de um
dia lê o status gravado às 09:12 do dia **anterior** — o RED de 09-02 apareceu no report
de 09-03, quando o estado corrente já era YELLOW. Não é dado errado, é dado velho
apresentado como corrente, que na prática dá no mesmo para quem lê o alerta.

#### 10.4 O gatilho de saturação descartava exatamente os briefs em que a dose mordeu

Nos dois primeiros epochs de tratamento medidos em `active`, o gatilho `p2-saturacao-da-dose`
reportou **RED `dose-servida-inerte: nenhum estado se move`**. Os dois vereditos ficam
preservados aqui com a procedência de cada janela, porque o que este item registra é um
alarme **diagnosticado**, não um alarme silenciado:

| epoch | janela | `sha256` do recorte | `n_janela` | `estados` | `mexem_servido` | `mexem_absurdo` |
|---|---|---|---|---|---|---|
| 2026-09-04 | `[09-04T09:00Z, 09-05T09:00Z)` | `64da3be2…20d59e` | 672 | 638 | 0 | 11 |
| 2026-09-05 | `[09-05T09:00Z, 09-06T09:00Z)` | `a17ceafd…d84c7027` | 672 | 640 | 0 | 14 |

**A leitura natural — e errada — é "a dose servida saturou".** O log de serving, que é
independente do replay, diz o contrário na mesma janela: no epoch de controle `w = 0`,
**0 de 441** briefs têm `churn > 0`; nos dois de tratamento `w = 2,0`, **35 de 672** e
**33 de 672**.

**Causa raiz.** O replay localiza cada brief no `brief_log` pela assinatura
`(agente, segundo, conjunto dos 10 `chunk_id`)`, e a assinatura que ele usa é
`ids_controle` (`replay-oportunidade.mjs:549`). Em `active`/tratamento o conjunto
**servido** é o **tratado**. Logo, em todo brief no qual o boost mudou a composição, a
assinatura procurada não existe no `brief_log`: `cands.length === 0`, o item vira `erro`
e o `continue` de `:561` o remove **antes** do laço de doses (`:622`). Na agregação, itens
com `erro` não entram no `estados` da tabela.

Medido sobre a janela do epoch 09-05, casando o `brief_log` inteiro da janela em memória:

| grupo | n | casa por `ids_controle` | casa por `ids_tratado` |
|---|---|---|---|
| `churn > 0` | 33 | **1** | 33 |
| `churn = 0` | 639 | 634 | 634 |

`33 − 1 = 32`, exatamente o `672 − 640` da tabela acima. A interseção é exata: das 33 com
churn, 32 falham e **1** casa (`2026-09-05T21:52:02.445Z`, `nox`, `churn = 2`); falhas
entre as sem churn: **0**.

Confirmação por rota independente, que não usa o campo em que a correção se apoia:
reconstruindo o servido a partir do próprio log como
`(ids_controle − would_leave) ∪ would_enter`, o casamento vai de **640/672** (regra atual)
para **672/672**. Como subproduto, isso é uma âncora nova: `would_enter`/`would_leave` do
log de serving são exatamente consistentes com o que o `brief_log` registra como servido,
nos 672.

**O defeito é puramente de seleção — não há ponta a montante.** Rodado o harness em
modo de fidelidade (`--modo campo`, que compara o controle reconstruído com o que a
produção gravou) sobre a mesma janela: `bate_controle` **640/640**, `bate_churn`
**639/640**, `erros` **32**. Ou seja, o pipeline reproduz a produção em tudo que
consegue alcançar; o que falha é só *quais* briefs ele alcança.

⚠️ E o próprio número da fidelidade tem de ser citado sobre a população **pretendida**,
não sobre a que sobrou: `639/640` é 99,8% de uma população já encolhida pelo defeito, e
sobre os 672 da janela é **639/672 = 95,1%**, com 32 briefs sem resposta nenhuma. Citar
o primeiro seria medir a fidelidade no denominador que o defeito produziu — a mesma
armadilha de população que este documento registra em outra unidade.

> ⚠️ **O viés é anticorrelacionado com o efeito que o instrumento mede.** Quanto mais a
> dose funciona, mais briefs saem da população, e mais perto de zero fica o resultado. É
> um erro de seleção que se disfarça precisamente de resultado nulo — a mesma forma do
> classificador de SOTA que usava "menciona um baseline" como prova de ser de terceiro.

**Por que não foi visto por dois dias.** O gatilho carregava os dois números lado a lado
na própria linha de status — `n_janela=672` e `estados=640` — e **nenhum predicado os
comparava**. Não é a família "guarda calado por não ter o dado" (regra 9 do `CLAUDE.md`):
é o agravante dela, guarda que **tem** o dado e não pergunta.

**Alcance do dano, e o limite honesto da varredura.** O defeito é exclusivo do modo
`active`: em `shadow` o servido *era* o controle, a assinatura casava, e `estados ==
n_janela == 672` nas **seis** rodadas shadow — a série mostra o descolamento aparecendo
só nas duas rodadas `active`. Todo número derivado de replay já escrito rastreia para a
calibração de **2026-08-27** (`11/350 = 3,1429%`, `15`, `17`, teto `17/350 = 4,86%`,
`w_min = 4,4`, saturação em `(4,0 ; 4,4]`), cuja janela `[2026-08-26T20:28Z,
2026-08-27T09:00Z)` é anterior à ativação — portanto não contaminada. Único consumidor
automático do replay é o próprio gatilho de saturação. A varredura cobre os artefatos
versionados e os consumidores automáticos; **não** cobre uma rodada ad-hoc cujo número
tenha ido direto para prosa sem deixar arquivo.

**Correções, classificadas como instrumentação e não emenda**, pelo mesmo critério do
§10.2 — nenhuma toca designação, dose, ordenação ou composição; o que muda é o que o
instrumento consegue enxergar:

1. `idDoBrief` passa a chavear pelo conjunto **efetivamente servido**, usando o campo
   `servido` que o log já grava (`ids_tratado` quando `servido == "tratado"`, senão
   `ids_controle`). Nada é reconstruído.
2. Perna nova no gatilho: `estados != n_janela ⇒ RED erros-no-replay=N`. Independente da
   correção 1, e é a que impede a próxima confusão desta família.
3. Teste de regressão que morde **este** defeito: sobre janela de epoch tratado, exigir
   `erros == 0`. Hoje ele falha; depois da correção 1, passa. Sem ele a correção fica sem
   nada que a proteja — ausência deliberada precisa de teste que a defenda.

**Adendo de 2026-09-07 — a perna nova era estrita demais, e custou um sinal no dia
seguinte.** Na primeira versão ela abortava, e no epoch `2026-09-06` **um** brief com
escrita incompleta no `brief_log` (1 linha de 10, em `23:07:02.425Z`) suprimiu um
veredito substantivo: `w = 7,5` e `w = 100000` produziram resultado **idêntico**
(`mexeu = 38`, `churn_total = 44`, `folga = 1,0`), isto é **`saturado`** — na dose mais
alta do desenho, subir `w` não muda mais nada.

A lição que motivou a perna era "não medir sobre população reduzida **em silêncio**", não
"nunca medir". Descartar o veredito por 1 em 672 transforma o guarda em ruído que suprime
sinal — a fadiga de alarme que ele existia para evitar. Corrigido para **emitir os dois**:
o estado continua `RED` (o *morning report* tem de ver), e o veredito de dose viaja junto
com a população explícita. A linha, verificada rodando o próprio bloco de decisão do
script implantado sobre os números reais do epoch:

```
RED|motivo=erros-no-replay: a janela nao foi respondida inteira faltam=1;
veredito_dose=RED:SATURADO: dose servida == dose absurda; a dose nao esta identificada
populacao_do_veredito=671/672 … mexem_servido=38 mexem_absurdo=38 folga=1.0 n_janela=672
```

⚠️ E um erro de contagem **meu** no diagnóstico desse `faltam=1`, registrado porque a
causa é transferível: minha reconstrução independente acusou **4** briefs não
respondidos contra o **1** do gatilho, e o gatilho estava certo. O código faz
`GROUP BY brief_id` sobre a janela de 3 s; eu agrupei **por segundo**, e três dos quatro
briefs têm os 10 chunks atravessando a fronteira do segundo (10 linhas, 2 `served_at`
distintos), então meu agrupamento os partia em 5 + 5 e nenhum casava a assinatura. É
invariante verificado sobre o conjunto errado.

**Controle positivo da correção — o critério foi o número, não o verde.** Rodado o
mesmo `--modo dose` sobre a mesma janela (`sha256` conferido idêntico ao do veredito
RED), com o `idDoBrief` corrigido:

| | antes | depois |
|---|---|---|
| `estados` | 640 | **672** |
| `erros` | 32 | **0** |
| `mexeu` (w = 2,0) | 0 | **33** |
| `churn_total` (w = 2,0) | 0 | **35** |
| `mexeu` (w = 100000) | 14 | 47 |

Os dois números da dose servida — **33** e **35** — reproduzem exatamente o que o log
de serving registrou de forma independente para o epoch, e é isso que valida a
correção: um veredito GREEN por si não distinguiria "consertado" de "quebrado de
outro jeito". A folga passa a `33/47 = 0,70`, dentro da faixa responsiva.

⚠️ **Uma comparação que este item NÃO faz.** Os `35/672` são *briefs com churn*; os
`3,14%` da condição de detectabilidade foram medidos como *estados que movem* (`11/350`).
Denominador e unidade diferentes; dizer "acima do previsto" antes de casar a unidade
repetiria o defeito "número certo, população errada" já registrado neste documento. O que
se afirma aqui é só o contraste interno, mesma fonte e mesma unidade: `0/441` no controle
contra `35/672` e `33/672` no tratamento.

**Procedência.** Divergência notada em 2026-09-06 ao conferir a série viva do ensaio.
Duas explicações minhas foram levantadas e **falsificadas** antes desta: (i) "ponto fixo
— em `active` o boost já está aplicado, reaplicar não move nada", incompatível com o
código, já que a linha de base do replay é o controle reconstruído (`out.alt`, comparado
a `ids_controle` em `:745`); (ii) "o snapshot de corpus deixou de cobrir a janela após a
mudança de fronteira de 28/08", falsificada por medição — dos 141 `chunk_id` distintos da
janela, **zero** ausentes no corpus, e os 84 registros posteriores ao snapshot não batem
com o gap de 32 nem em contagem nem em direção. O sítio do descarte e a perna
`estados != n_janela` foram localizados em paralelo pela sessão vizinha; a conferência por
reconstrução do servido e a varredura de contaminação são dela.

#### 10.5 O corpus esteve congelado durante os seis primeiros epochs — por defeito

`MAX(created_at)` em `chunks` esteve cravado em **2026-08-24 01:06:35** até
**2026-09-07T14:06:13Z**. A série diária não declina: **corta**.

| dia | chunks com `created_at` nesse dia |
|---|---|
| 2026-08-21 | 118 |
| 2026-08-22 | 15 |
| 2026-08-23 | 57 |
| 2026-08-24 | 40 |
| 2026-08-25 … 2026-09-06 | **0** (14 dias) |
| 2026-09-07 | 182 |

Causa: `nox-mem-watch.sh:52` invocava `/usr/local/bin/nox-mem ingest`, binário
ausente há ~15 dias — o mesmo que havia quebrado o *nightly*. O journal do watcher
registra `No such file or directory`. As **buscas nunca pararam** (`updated_at`
seguia andando); só a ingestão.

⚠️ **Discrepância de contagem que fica declarada em vez de resolvida por escolha.**
O total foi de 67.187 para 67.224 (**+37 líquidos**), e há **182** linhas com
`created_at` de 2026-09-07 — logo ~145 substituíram versões existentes. O relatório
do próprio *catch-up* diz **124** chunks em 13 arquivos. Os 58 de diferença entre
124 e 182 não estão explicados; "criados", "tocados" e "reingeridos" são três
grandezas e aqui divergem.

**O congelamento não alcança o alvo da intervenção.** Os **19** chunks designados
foram todos criados no mesmo instante — `2026-08-21 22:51:23`, lote único —, todos
anteriores ao congelamento: **zero** designados com `created_at` posterior a
2026-08-24. O conjunto que recebe boost nunca ia mudar.

**O que o congelamento alcança é contra quem o boost compete.** Chunks passando o
piso do canal fresco (`importance ≥ 0,7` e `pain ≥ 0,7`) são **17** para
`created_at ≥ 2026-08-24`, **17** para `≥ 2026-08-31` e **17** para `≥ 2026-09-07`
— os três contam os **mesmos 17**, todos criados em 2026-09-07. Ou seja o pool
fresco esteve **vazio o ensaio inteiro** até 14:06 daquele dia, o que também
explica os **246** registros horários do gatilho de composição reportando
`agent_fresh_elegiveis=0` para os seis agentes desde 2026-08-27 — número que até
então estava sem causa nomeada.

Epochs afetados: `2026-09-01` (w = 4,0), `09-02` e `09-03` (controle), `09-04` e
`09-05` (w = 2,0), `09-06` (w = 7,5) — **6 de 234**.

**Decisão: nota de limitação com a fronteira cravada, sem alterar a análise.** Três
razões, todas medidas e não retóricas:

1. o alvo da intervenção é fixo e anterior ao congelamento (acima), logo o
   congelamento não muda quem é tratado;
2. o congelamento é propriedade do **tempo de calendário**, e o braço é sorteado
   sobre o calendário ⇒ é covariável **balanceada em expectativa**, não
   confundidor. Ele estreita a validade **externa** (o ensaio mediu um ambiente de
   ordenação estático), não a interna;
3. são 6 de 234 epochs.

⚠️ **Por que não virar dois regimes com regime como fator.** Seria decisão de
análise tomada **depois** de os dados existirem — exatamente o grau de liberdade que
o pré-registro existe para eliminar. Uma escolha reaberta com dados na mesa vale
zero mesmo chegando à mesma conclusão, porque o leitor não pode distinguir "decidiu
antes" de "decidiu e diz que decidiu antes". É o mesmo argumento do §10.1.

**Isto é o inverso de um fato registrado antes**, e a contradição é aparente, não
real: em 2026-08-15 foi medido que o corpus do piloto **não** era estacionário. Era
verdade então; o congelamento é posterior e tem causa operacional. Série viva citada
como instante envelhece para falsa — aqui a fronteira fica cravada por isso.

#### 10.6 Um script DEPOSITADO dependia de um insumo fora do depósito, em caminho volátil

`measurement/ordem.mjs` é o **item 115** de `deposit/paperA/MANIFEST.json` — script
publicado, que um terceiro deveria conseguir executar. Ele abria, por **caminho
fixo**, `/var/tmp/p2-ord-ro.db`: **1,6 GB**, e o MANIFEST não contém **nenhum**
`.db`. O resultado que ele sustenta está citado em `measurement/README.md:69` —
*28 casos, 0 com ordem diferente*, que é o que **refuta o canal de reordenação**.

O arquivo quase foi apagado num varrimento de espaço em disco em 2026-09-07. E
**naquele mesmo dia deixou de ser recriável**: o descongelamento do §10.5, às
14:06:13Z, fez o `main` deixar de ser o de 2026-08-26. Até 14:06 "recriar a partir
do `main`" ainda era caminho; depois, não.

Isto é literalmente o defeito que o texto do próprio depósito declara já ter
cometido: *"um corpus pinado por identificador já foi perdido neste mesmo trabalho,
levando 280 episódios adjudicados junto"*.

**Correção aplicada.** Movido para
`/var/lib/nox-mem/p2/corpus/p2-ord-ro-2026-08-26.db`, com `sha256` conferido
**antes** de remover a fonte e `mtime` preservado; verificado depois por terceiro:
`PRAGMA quick_check` **ok**, **67.187** chunks, `MAX(created_at)` =
**2026-08-24 01:06:35** — o estado congelado exato. O `-wal` órfão tinha **0
bytes**, logo não havia transação pendente. O caminho passou a ser parametrizável
por `NOX_P2_ORD_LIVE`, com o novo local como default.

⚠️ **Uma premissa que foi medida e caiu, e fica registrada porque enfraquece a
urgência que eu alegava:** não existe regra de idade para `/var/tmp` neste sistema
(`systemd-tmpfiles --cat-config` só traz `x /var/tmp/systemd-private-%b-*` e
`X …/tmp`). O arquivo **não** estava com prazo correndo. A correção se justifica por
caminho volátil por convenção, por dependência publicada fora do depósito e por um
agente de faxina que perguntou mas podia não ter perguntado — **não** por deleção
iminente.

**Resolução, e ela falsificou a minha própria proposta.** Eu havia sugerido "depositar
o recorte de 28 casos em vez do corpus de 1,6 GB". Ao executar, dois fatos derrubaram
isso:

1. **não havia recorte a depositar, porque não havia artefato nenhum.** A alegação vivia
   só em prosa, em três lugares (`measurement/README.md:69`,
   `AMENDMENT-DRAFT-band-collapse-2026-08-26.md:862` e este documento). É a classe já
   catalogada no §6 — *um valor citado em vários lugares sem nenhum artefato que o
   contivesse*;
2. **e o recorte não seria recortável:** `ordem.mjs` passa o handle do DB **para dentro**
   do código de produção (`boostsParaCandidatos`, `buildBriefDiverse`), então "só as
   linhas de que ele precisa" exigiria reimplementar o que a produção lê — a
   reconstrução que este trabalho já pagou para não fazer.

⚠️ **Pior: a rodada de 2026-08-26 não é mais reproduzível, e não por causa do arquivo que
eu salvei.** O par de insumos é `live` + `corpus`. O `live` está preservado; o `corpus`
apontava para `/var/lib/nox-mem/epochs/current.db`, e os snapshots de epoch de 08-24 a
09-02 **foram podados** — restam apenas os `*.manifest.json`. Salvei metade do insumo.

**O que ficou feito:** a comparação foi **reestabelecida** num par preservado e pinado, e
gravada como `out/ORDEM-SEQUENCIAS-2026-09-07.json` (5,4 KB — não 1,6 GB), com
`sha256` dos dois insumos, o resumo e os 28 resultados. Resultado: **`mesmaOrdem` = true
em 28 de 28**, `mesmoConjunto` = true em 28 de 28. O artefato entra no MANIFEST (item
121), e o `sha256` do próprio `ordem.mjs` foi recomputado ali, porque a edição do caminho
o havia desatualizado — o gate 0 do `deposit.sh` teria falhado, corretamente.

⚠️ **Este artefato NÃO reproduz a rodada de 26/08** — reestabelece a alegação em outro
par de insumos, e diz isso no próprio campo `procedencia.porque`. O `README.md:69` foi
alterado para carregar a ressalva junto do número, em vez de apresentá-lo como se fosse a
medição original.

⚠️ **Ressalva de poder, declarada no artefato em vez de silenciada.** `mesmoConjunto =
true` nos 28 é a **pré-condição** do teste, não defeito: a objeção que ele responde é *"se
`churn = 0`, um boost que **reordena** dentro do conjunto fica invisível"*. Mas o artefato
**não registra se um boost foi de fato emitido** em cada estado, então a refutação vale
condicionada a isso e o poder do teste fica sem medida. Fechar essa ponta exige gravar
`boosts_emitidos` por caso — trabalho declarado, não feito.

#### 10.7 O canal de tratamento mudou de composição no meio do ensaio — por conserto

> 🔴 **CORRIGIDO PELO §10.10, no mesmo dia.** O `agentFresh = 219` é real no corpus que
> o *gatilho* lê e **falso** no canal que o *serving* usa: o processo serve de um snapshot
> aberto por *file descriptor* em 03/09, onde `agentFresh = 0`. Não houve mudança de
> composição no canal servido, e os 7 epochs listados abaixo **não foram afetados**. O
> item fica no registro porque a medição, o mecanismo do `interleave` e a regra de
> tratamento continuam corretos *como raciocínio* — e porque um item retirado esconde o
> erro em vez de o mostrar.

O gatilho de composição (item 7(b)) virou `RED` em **2026-09-08T06:09:04.208Z**, com
`agent_fresh_elegiveis = 219` (`nox:0 atlas:0 boris:205 cipher:8 forge:6 lex:0`). A
transição é **única e limpa**: desde a primeira linha do gatilho
(`2026-08-27T17:55:21.650Z`) todas as execuções horárias anteriores reportaram `0` para
os seis agentes, sem uma exceção. Este é o alarme que o item 7(b) foi escrito para dar, e
ele deu — a ameaça que ele vigia é *"a única que muda a escala de dose **durante** o
estudo, em silêncio"*.

**Não é rajada de trabalho dos agentes. É ingest em bloco.** Os 219 chunks foram criados
numa janela de **18 minutos**, `2026-09-08 02:19:44` → `02:37:23` (UTC), e a série diária
de `chunks` com `source_file LIKE 'sessions/%'` no banco vivo mostra corte e volta:

| dia | chunks `sessions/%` criados | passam o piso do canal |
|---|---:|---:|
| 2026-08-01 … 08-10 | 67 · 105 · 143 · 55 · 39 · 77 | 44 · 81 · 102 · 39 · 21 · 54 |
| 2026-08-11 … 09-07 | **0** (28 dias) | **0** |
| 2026-09-08 | **382** | **253** |

**Causa: o conserto do `session-distill` em 2026-09-07** — a migração da VPS havia movido
o endereço *e* o schema dos transcripts, e o cron reportava `ok` com `exit 0` por 28 dias
imprimindo `No unprocessed sessions found`. Consertado o parser, o distill foi rodado
**à mão** naquela noite. **Não existe entrada de cron para ele** — conferido no
`crontab -l` completo da VPS, onde estão os 30 jobs de manutenção e os dois gatilhos do
P2, e nenhum `distill`.

Este é o **segundo passo** do descongelamento descrito em §10.5, e não o mesmo. Lá o
conserto de `nox-mem-watch.sh` (2026-09-07T14:06:13Z) reencheu o sub-pool **global**
(`memory/entities/%`, `lessons.md`) — e o gatilho de composição seguiu reportando `0`,
porque ele mede `sessions/<agente>/%`, que é a outra perna. O `agentFresh` só deixou de
ser vazio com o distill, ~12 h depois.

##### Por que isto atinge o desenho, e não só o corpus

`interleaveFresh(agentFresh, globalFresh)` era **função-zero** — `interleaveFresh([], g)
=== g`, todo o canal era o sub-pool global. Toda a calibração de dose de 27/08 (a
distribuição de `w_min`, o teto de 17/350) foi medida **nesse** regime. Com `agentFresh`
povoado, `interleaveFresh` passa a intercalar de fato, e o `w_min` de qualquer estado
afetado deixa de valer. Não é ruído a tolerar: é a premissa da calibração caindo, que é
exatamente o texto que o gatilho imprime como ação.

E a mudança não pegou um epoch de controle:

| fato | valor | fonte |
|---|---|---|
| epoch de **2026-09-08** | **`treatment`, `w = 2,0`** | `ASSIGNMENT-SERVING.json` |
| abertura do epoch | `09:00Z` | fronteira `epochInicioISO` |
| entrada dos chunks | `02:19Z`–`02:37Z` | `created_at` |
| snapshot que os capturou | `e20260908T060004Z.db` (`06:00Z`) | `current.db` |

Isto é, o epoch de hoje é o **primeiro epoch de tratamento servido com o canal
intercalado**, e ele foi servido inteiro nesse regime — a ordem dos três horários não
deixa ambiguidade.

##### O regime é transitório, e a data de saída está cravada

`freshMaxAgeDays = 7`, e os **253** chunks elegíveis de `sessions/%` têm todos
`source_date = '2026-09-08'` ⇒ deixam de passar o predicado em **2026-09-15 00:00:00Z**,
todos no mesmo instante. Sem cron para o distill, `agentFresh` volta a vazio ali.

⚠️ **A primeira versão deste parágrafo errou o conjunto de epochs**, e o erro tem forma
reconhecível: derivei a expiração com `date(…, '+7 days')`, que devolve **2026-09-15**, e
tratei o dia como se o epoch daquela data estivesse dentro. O predicado é
`julianday('now') − julianday(source_date) <= 7` — **com hora** —, `source_date` é
meia-noite, e os epochs abrem às **09:00Z**. Logo o epoch `09-15`
(`[09-15T09:00Z, 09-16T09:00Z)`) começa **9 h depois** da expiração e está **inteiro** no
regime antigo. Resolução de dia contra fronteira de nove horas: mesma família de
"número certo, população errada".

Medido corretamente, o regime `[2026-09-08T02:19Z, 2026-09-15T00:00Z)` cobre:

| epoch | braço | dose | cobertura pelo regime novo |
|---|---|---:|---|
| 2026-09-08 | treatment | 2,0 | inteiro |
| 2026-09-09 | treatment | 2,0 | inteiro |
| 2026-09-10 | control | 0 | inteiro |
| 2026-09-11 | control | 0 | inteiro |
| 2026-09-12 | treatment | 4,0 | inteiro |
| 2026-09-13 | control | 0 | inteiro |
| 2026-09-14 | treatment | 4,0 | **parcial** — 15 h de 24 |
| 2026-09-15 | treatment | 4,0 | **nenhuma** |

São **7 epochs de 234**: 3 de tratamento inteiros, 1 de tratamento **atravessado pela
fronteira** e 3 de controle. O `09-14` é heterogêneo por dentro, como o Epoch 1 (§10.1) e
o `09-03` (§10), e herda a mesma questão de tratamento.

⚠️ **E o regime novo não exercita a dose alta.** As doses cobertas são `{2,0; 2,0; 4,0}`
inteiras mais `{4,0}` parcial — **nenhum epoch de `w = 7,5`** cai dentro. A curva
dose-resposta no regime novo tem, no máximo, **dois** pontos de dose, e o teto do desenho
não é tocado. Qualquer afirmação sobre "a dose no regime intercalado" fica limitada a
`w ∈ {2,0; 4,0}`.

⚠️ **Um dos números começou como reconstrução minha e foi remedido contra o fonte.** Os
`219` são do gatilho, que lê os limiares de `DIVERSITY_DEFAULTS` no `dist` e confere as
duas cláusulas do predicado contra `src/api/brief.ts` antes de medir — e o valor que eu
havia reconstruído à mão para os seis agentes bate com ele, o que valida os patterns de
sessão. Para o sub-pool global eu errei **duas** coisas. O pattern: escrevi `%lessons.md`, e o
literal é `GLOBAL_FRESH_PATTERNS = ["memory/entities/%", "memory/lessons.md"]` — que o
`replay-oportunidade.mjs` **extrai do fonte e aborta se divergir**, em vez de confiar na
cópia. E a **janela de idade**: usei os 7 dias de `freshMaxAgeDays`, mas o segundo
`fetchFreshCandidates` é chamado com `{ ...cfg, freshMaxAgeDays: cfg.freshGlobalMaxAgeDays }`
⇒ o sub-pool global usa **30 dias**, não 7.

Com pattern e janela corretos o global dá **108** no corpus que o serving usa e **115** no
snapshot de hoje — não 60. E os **108** batem exatamente com o número que o cabeçalho do
`gatilho-composicao.mjs` documenta (*"108 candidatos de `memory/entities/%` + `memory/lessons.md`"*),
o que é a conferência que eu devia ter feito antes de publicar um número reconstruído.

⚠️ **A janela errada quase produziu uma conclusão invertida.** Com 7 dias, os 19
designados — do lote de `2026-08-21`, portanto com 17 dias — **não** passariam, e o pool
fresco apareceria como *inteiro vazio*: eu cheguei a escrever que o canal de cobertura
estava inerte e que o boost não teria onde agir. Com os 30 dias reais, os 19 estão **todos**
no pool nos dois corpora, o mecanismo funciona, e o `mexeu = 38` medido no epoch 09-06
deixa de ser contraditório. Quarta ocorrência da classe *reconstrução que modela regra que
o código não aplica* — e a primeira em que o parâmetro errado apontava para "o ensaio não
mede nada".

Um terceiro número que o gatilho **não** conta e que não é defeito dele: **34** chunks
elegíveis em `sessions/main/%`. `main` não é um dos seis agentes do ensaio, e o gatilho
vigia os seis.

##### O mecanismo é derivável do código, e a direção não é a intuitiva

`interleaveFresh(a, b)` é alternância estrita — `a[0], b[0], a[1], b[1], …`, com
deduplicação por `row.id` —, `a` é o `agentFresh` e `b` o `globalFresh`. Duas
consequências caem direto disso:

1. **Nada é cortado por teto.** `FRESH_CANDIDATE_POOL = 400` e o canal passou de `0 + 60`
   para `219 + 60 = 279`. O pool continua cabendo inteiro; o que mudou não é *quem entra*.
2. **A posição de cada candidato global no `freshPool` passou de `i` para `2i + 1`.** Com
   `agentFresh` vazio, `interleaveFresh([], b) === b` e o i-ésimo global ficava na posição
   `i`. Com 219 à frente na alternância, ele vai para `2i + 1` — a distância até os
   `freshSlots` **dobra**.

⚠️ **E os 19 chunks designados são todos do sub-pool global** (`memory/entities/%`,
criados no lote único de `2026-08-21 22:51:23`). Logo a derivação prevê que a mesma dose
alcance **menos**, não mais: o boost tem o dobro de distância para cobrir. Se essa
previsão se confirmar, a mudança de canal **reduz** a exposição do tratamento — o
contrário do que "o canal ficou mais rico" sugere.

Isto está escrito como **derivação sobre o código, não como resultado**. A posição na
ordem de entrada do `freshPool` não é necessariamente a grandeza que decide o pick, e
"reconstrução que modela regra que o código nunca aplica" é defeito já cometido três vezes
neste projeto. A medição que decide está descrita abaixo.

##### A medição, e o que dela ficou impossível

⚠️ **A âncora de 27/08 não é reproduzível.** A distribuição publicada (`w_min` mín 0,02 ·
mediana 1,7 · máx 4,4, espalhamento 220×; teto 17/350 = 4,86%) foi medida sobre o snapshot
de corpus daquele dia, e `/var/lib/nox-mem/epochs/` tem hoje **16 manifests e 3 `.db`** —
os snapshots antigos foram podados, como já ocorreu no §10.6. Logo **não existe** a
comparação "mesma janela, corpus de 27/08 contra corpus de hoje": qualquer diferença
contra aquele número confundiria mudança de corpus com mudança de janela.

O que ainda é possível, e é mais limpo que o delta histórico, é um **contraste interno com
a janela fixa**:

| corpus | `agentFresh` | `globalFresh` | chunks de sessão |
|---|---:|---:|---:|
| **C3** — produção, `e20260908T060004Z.db` | **219** | 60 | 14.838 |
| **C2** — C3 menos os 382 ingeridos em 08/09 | **0** | 60 | 14.456 |

C2 não é um snapshot antigo: é C3 com os 382 chunks removidos, e por isso difere de C3
**apenas** naquilo que se quer isolar. Duas conferências antes de rodar: `14.838 − 382 =
14.456` é **exatamente** a contagem de sessões do snapshot real de 2026-09-07, o que prova
que os 382 são todos novos e **nenhum substituiu** versão anterior; e `global_elegivel`
fica em 60 nos dois, `quick_check = ok`.

⚠️ **Por que o snapshot real de 07/09 NÃO serve como braço de comparação.** Ele é de
`06:00Z`, anterior ao conserto do watcher das `14:06Z`, e tem `global_elegivel = 0`.
Usá-lo misturaria o reenchimento do pool global (§10.5) com o do `agentFresh` (este item)
— dois fatores num contraste de dois pontos, que é a forma de não medir nenhum dos dois.

A rodada usa o próprio gatilho de saturação (que já carrega o `sha256` do recorte e o
cruzamento designado × servido), com `--epoch 2026-09-06` e a janela
`[2026-09-06T09:00:00Z, 2026-09-07T09:00:00Z)`, `n_janela = 672` — reproduzido, igual ao
que o gatilho publicou. **Grava em arquivos próprios**, nunca no
`status-saturacao.txt` nem no `gatilhos.ndjson` de produção: rodada de medição
contaminando a série de vigilância é o defeito que este repositório já carrega no nome de
`p2-write-path.CONTAMINADO-por-verificacao-20260818.ndjson`.

##### A regra de tratamento, FECHADA em 2026-09-08 sem que desfecho algum fosse consultado

> **Precedência.** Decidida em **2026-09-08**, no oitavo epoch do ensaio. Nenhum desfecho
> foi computado, consultado ou estimado antes desta decisão. O que foi medido para decidir
> é **exclusivamente estrutura de exposição** — contagens de candidatos elegíveis por
> sub-pool, posição na ordem do `freshPool`, e quantos estados **mudam de conteúdo** no
> brief (`mexeu`/`churn_total`) sob doses contrafactuais. A densidade de falhas repetidas,
> que é o desfecho, **não foi tocada**. Confere-se pelo `git log` que este parágrafo
> antecede qualquer artefato de desfecho no repositório.

✅ **A decisão reusa a estrutura já registrada, em vez de criar uma paralela** — o mesmo
fundamento que fechou o Epoch 1 (§10.1). O `PREREG-DRAFT.md` §"Mandatory ITT co-estimate"
determina que o *primary* seja reportado ao lado de um co-estimador ITT sobre todos os
epochs pós-washout **sem exclusão de cobertura alguma**, com concordância como força da
alegação e divergência reportada como está, não adjudicada a favor de nenhuma das duas.

**Nenhum epoch sai.** Os 7 epochs do regime intercalado entram no *primary* e no
co-estimador ITT, no braço e na dose designados. **Acrescenta-se uma terceira análise,
pré-especificada aqui:** o mesmo par de estimativas com os epochs do regime novo
excluídos, sob a mesma regra do §1042.

**Por que não descartar — e a razão é viés, não poder.** Duas coisas, medidas:

1. **Excluir seria seleção correlacionada com o mecanismo.** A derivação acima prevê que
   no regime intercalado a mesma dose alcance **menos**. Se ela se confirmar, os epochs
   afetados são os de **menor** efeito, e removê-los **infla** a estimativa. É a mesma
   classe de defeito do §10.4 — onde o replay descartava justamente os briefs em que a
   dose mordeu — com o sinal trocado. Filtrar por uma variável que o efeito move é vício
   independentemente da direção.
2. **O custo estatístico de descartar é desprezível**, logo não compra nada em troca. Com
   a alocação `117/39/39/39`, os afetados são 2 de 39 em `w = 2,0` e 1 inteiro + 1 parcial
   de 39 em `w = 4,0`; o erro-padrão inflaria `√(39/37)` = **2,7%**. Como no Epoch 1, a
   decisão não é sobre poder.

E não há viés a remover em troca: o regime é propriedade do **tempo de calendário** e o
braço é sorteado sobre o calendário ⇒ covariável balanceada em expectativa, não
confundidor. É o mesmo argumento que o §10.5 aceitou para o corpus congelado, e ele
estreita a validade **externa**, não a interna.

##### O indicador de regime é MECÂNICO, não uma lista de datas

O regime entra na análise como indicador por epoch, definido por **medição** e não por
data escrita à mão: `agent_fresh_elegiveis > 0` na linha
`p2_gatilho_composicao` do NDJSON, que roda a cada hora e persiste. Para o epoch
atravessado, a **fração de horas** cobertas.

⚠️ **Isto não é preciosismo: a primeira versão desta seção errou a lista de datas** —
`date(…, '+7 days')` devolveu `2026-09-15` e eu incluí o epoch daquele dia, que abre 9 h
**depois** da expiração. Uma lista de datas escrita à mão também não sobrevive ao distill
rodar de novo; o predicado medido sobrevive. Mesma disciplina do estado vivo que só se lê
por comando, nunca por lista transcrita.

##### O que fica em aberto, e é decisão operacional, não de análise

Pôr o distill em cron estabiliza o canal no regime intercalado pelos 227 epochs
restantes; não pôr deixa o canal oscilar por ação manual não registrada, que é pior que
congelado. A escolha tem **gatilho quantitativo**: se `w = 2,0` continua movendo estados
no regime intercalado, estabilizar é preferível a oscilar; se `w = 2,0` fica **inerte**,
estabilizar tornaria um terço dos epochs de tratamento não-informativos pelo resto do
ensaio, e aí o certo é preservar o regime da calibração até o fim ou emendar as doses —
o que exigiria a emenda ao pré-registro que hoje está preparada e **não** executada.

#### 10.8 Dois defeitos no gatilho de saturação, achados ao ler o RED de hoje

**(a) `emitir()` não grava o NDJSON — e é por onde saem os alarmes mais valiosos.** A
função escreve `stdout` e o arquivo de `--status`, e nunca o `--ndjson`. Só o caminho
normal (o bloco `python3` do veredito) persiste linha. Logo todo veredito que sai por
atalho — `log-de-serving-ausente`, `assignment-nao-existe`, `assignment-sha256-divergente`,
`janela-com-n-insuficiente`, `log-diverge-do-assignment`, `epoch-de-controle`,
`replay-falhou` — fica **apenas** no arquivo de status, que é **sobrescrito** na execução
seguinte. É perda permanente, não atraso.

Medido: `/var/log/nox-p2-gatilhos.log` tem **12** execuções de `p2-saturacao-da-dose`
contra **9** linhas `p2_gatilho_saturacao` no `gatilhos.ndjson`, e o NDJSON **não tem
nenhuma linha de 2026-09-07 nem de 2026-09-08**, embora as duas existam no log e a de
09-08 esteja no status agora. Entre os motivos que existem só no log de texto está
`log-diverge-do-assignment` — que o próprio comentário do script chama de *"o alarme mais
valioso deste script … a única coisa aqui que compara o que devia ser servido com o que
foi"*. O alarme mais valioso é o que não deixa rastro estruturado.

**Consertado em 2026-09-08, com mutação.** `emitir()` e `morte_por_sinal()` passam a
gravar uma linha de atalho; a escrita dupla no caminho normal é impedida por uma
**sentinela** em `$TMP` que o bloco de veredito cria depois de gravar — e não por contagem
de linhas, porque o `gatilho-composicao.mjs` escreve no **mesmo** NDJSON a cada hora e uma
rodada de saturação leva ~15 min, de modo que a linha do outro gatilho entraria no meio e
seria lida como *"já gravei"*.

O registro de atalho **não finge ter os campos do veredito**: `servido`, `absurdo` e
`folga` saem `null`, com `via: "atalho"` dizendo por quê. Preenchê-los com zero fabricaria
`mexeu = 0`, isto é `dose-servida-inerte` — precisamente o veredito errado que o §10.4
documenta ter custado dois dias de RED com o motivo trocado.

Cobertura: `teste-gatilho-active.sh` vai de 12 para **15** casos (T12 atalho grava com
`via=atalho` e sem campos fabricados; T13 o caminho normal grava **uma** linha com os
campos reais; T14 o `log-diverge-do-assignment` persiste). **Duas mutações confirmam que
os casos mordem, e em pontos distintos:** contra a versão pré-patch falham T12 (`n=0`),
T13 (`via=None`) e T14 (`n=0`), e os 12 antigos seguem verdes; removendo **só** a
sentinela, falha **apenas** T13, com `n=2 vias=['veredito-de-dose','atalho']`. Produção e
repo no mesmo `sha256` (`61b56d69aeec…`), 15/15 verdes contra o script implantado; a
versão anterior ficou em `gatilho-saturacao.sh.pre-ndjson-2026-09-08`.

⚠️ **O que o conserto NÃO recupera.** As linhas dos atalhos já ocorridos estão perdidas —
o arquivo de status foi sobrescrito. O log de texto (`/var/log/nox-p2-gatilhos.log`)
guarda as linhas cruas dessas execuções e é a única fonte para elas; qualquer análise da
série de vereditos anterior a 2026-09-08 tem de ler o log, não o NDJSON, e sabendo que o
log não é estruturado nem tem garantia de retenção.

**(b) O patch de 2026-09-07 ainda não foi exercitado em produção.** A perna que
*alarma e preserva* o veredito (§10.4, adendo) entrou em `gatilho-saturacao.sh` às
**2026-09-07T14:30:14Z** — **5 h depois** do `RED` das `09:12` daquele dia. Aquele `RED`
saiu da versão anterior, a que **abortava**, e é por isso que ele não carrega
`veredito_dose=`, `mexem_*` nem `folga=` na linha, e que não há linha dele no NDJSON. Da
implantação até agora o gatilho rodou **uma** vez, em `2026-09-08T09:12:01Z`, sobre o
epoch `2026-09-07` de **controle** — que sai por atalho, antes do bloco que a perna nova
habita.

⚠️ **Consequência de leitura, e ela é a armadilha:** o `RED` de 09-07 saiu do morning
report de hoje substituído por um `GREEN`, e o `GREEN` é
`motivo=epoch-de-controle-sem-dose-a-saturar semantica=pergunta-indefinida-nao-verificada`
— isto é, **verde por pergunta indefinida, não por defeito resolvido**. O `faltam=1` de
09-06 (o brief com 1 linha de 10 em `2026-09-06T23:07:02.425Z`) e o veredito `SATURADO`
que ele encobria continuam onde estavam. Um epoch de controle limpando um `RED` de
tratamento do painel é a mesma família do guarda que fica calado por não ter o dado.

#### 10.9 Reingestão por arquivo mata a identidade dos chunks servidos — a auditoria de janela tem meia-vida

> 🔴 **PARCIALMENTE CORRIGIDO PELO §10.10.** Os 53 ids não estão mortos *para o serving*:
> eles vivem no snapshot que o processo tem aberto. A irreprodutibilidade medida é
> **desalinhamento** entre o corpus do serving e o corpus que o replay recebe, e não
> perda de dados — o que a torna consertável. A reingestão por arquivo **existe** e mata
> ids de verdade no banco vivo; o guarda dos designados segue justificado por isso.

Achado em 2026-09-08 ao conferir se o corpus cobria a janela **antes** de rodar a medição
do §10.7. Ele a cancelou, e vale mais que ela.

**Medido.** Dos **141** `chunk_id` distintos que o canal serviu na janela do epoch
`2026-09-07`, **53** já não existem no banco vivo — todos de `memory/lessons.md`, ids
**contíguos** `308444..308496`, todos com `created_at 2026-08-22 02:01:58`. O arquivo
reaparece com **60** chunks em ids **novos**, `309034..309093`,
`created_at 2026-09-07 23:01:36`.

| snapshot | `memory/lessons.md` | ids |
|---|---:|---|
| `e20260906T060001Z` | 53 | `308444..308496` |
| `e20260907T060001Z` | 53 | `308444..308496` |
| `e20260908T060004Z` | **60** | **`309034..309093`** |
| banco vivo (agora) | 60 | `309034..309093` |

Isto é **reingestão de arquivo**, não perda de dados: o conteúdo permanece, a
**identidade** muda. O ingest apaga os chunks daquele `source_file` e cria outros. Uma
única reingestão em 16 dias — a taxa é baixa, o evento é destrutivo para a auditoria.

##### O efeito é sobre o que se pode REPRODUZIR, e ele é grande

O replay localiza cada estado pelos ids que o log de serving registrou. Ids mortos ⇒
estados não localizáveis ⇒ o brief vira `erro` e **sai da população antes do laço de
doses**:

| janela | briefs | com ao menos um id morto |
|---|---:|---:|
| epoch 2026-09-05 | 672 | **400 (59,5%)** |
| epoch 2026-09-06 | 672 | **436 (64,9%)** |
| epoch 2026-09-07 | 672 | **440 (65,5%)** |

⚠️ **Por isso a medição do §10.7 foi abortada em vez de concluída.** Ela ia gastar ~30 min
para produzir um veredito de dose sobre ~35% da população, com a perda concentrada
justamente nos estados que a dose alcança — o viés anticorrelacionado com o efeito que o
§10.4 documenta. Um número assim é pior que nenhum: parece resultado.

**A consequência de método, e ela vai ao paper:** a auditoria de uma janela tem **meia-vida
curta**. O `gatilho-saturacao.sh` roda 09:12Z, 12 min após o fecho do epoch, e é por isso
que ele funciona; **re-análise retroativa de uma janela é impossível** depois da primeira
reingestão dos arquivos do canal. O `run-saturacao.sh` já declara uma aproximação vizinha
("um dia UTC atravessa DOIS corpora e este replay usa um só"), mas essa nota é sobre
**qual** corpus escolher, não sobre o corpus **deixar de conter** o que a janela referencia.

##### Uma causa registrada neste documento que a medição NÃO reproduz

O §10.4 atribui o `faltam=1` do epoch `2026-09-06` a *"UM brief com escrita incompleta no
`brief_log` (1 linha de 10, em `2026-09-06T23:07:02.425Z`)"*. Medido agora, **não se
sustenta**:

- agrupando por **`brief_id`** — a chave certa —, a janela tem **672 briefs, todos com
  exatamente 10 linhas**, zero `brief_id` nulo, zero fora de 10;
- os dois contadores que a perna `estados != n_janela` compara **não** divergem por
  critério: `p2_outcome` na janela = **672**, e com `ids_controle.length == 10` = **672**;
- e a reingestão de `lessons.md` (23:01:36 de 07/09) é **14 h posterior** ao gatilho que
  emitiu o `faltam=1` (09:12Z de 07/09) — no snapshot que ele usou, os 141 ids estavam
  **todos** presentes (0 ausentes, conferido).

Fica **sem causa confirmada**, e é assim que entra no registro. Trocar uma hipótese não
verificada por outra minha seria o mesmo defeito com outro nome.

⚠️ **Armadilha de medição no caminho, que quase virou um número falso.** Agrupei
primeiro por `served_at` e obtive uma distribuição com 12 grupos "anômalos" (n = 1, 2, 11,
12, 18, 19). Não há anomalia alguma: `served_at` tem resolução de **segundo** e colide
entre briefs distintos. A chave é `brief_id`, que existe na tabela. Chave de agrupamento
errada fabrica anomalia.

##### O risco que isto expôs, e que não tinha guarda nenhum

Os **19 designados estão íntegros** — conferido em quatro corpora, 19/19 em vivo, 06/09,
07/09 e 08/09. Eles vivem em **19 arquivos DISTINTOS** de `memory/entities/lessons/`, um
chunk designado por arquivo, todos do lote `2026-08-21 22:51:23`, **nunca reingeridos**.

Mas a reingestão é **por arquivo**. Editar um daqueles 19 mata aquele designado, e a
designação — sorteada uma vez, com semente pública, e que **não se refaz** — quebra **em
silêncio**. Nada vigiava isso.

**Implantado 2026-09-08: `gatilho-designados.mjs`**, cadência horária no minuto `:24`, lido
pelo `morning-report.sh` com teto de 3 h. Duas pernas, porque uma não cobre a outra:

1. **ausência** de um id ⇒ `RED` com a lista — é o que a reingestão produz;
2. **deriva** com id vivo (`sha256` do `chunk_text`, ou o `source_file`, diferente do
   baseline) ⇒ `YELLOW` — um `UPDATE` no mesmo id altera o alvo e deixa a perna 1 calada,
   que é a forma de defeito da regra 9 do `CLAUDE.md`.

O **baseline é imutável**: o guarda cria se não existir e **nunca** sobrescreve — uma
referência reescrita pelo próprio guarda o faria comparar o estado corrompido consigo
mesmo e dizer `GREEN` para sempre. Baseline criado em `2026-09-08T14:51:49Z`, 19/19,
`sha256 = e43fbc9076fdd91f2d24a5fe8b008aca1eb3a5f61b31724529d90312bdfedeaa`. Trocá-lo
exige ação humana explícita.

Cobertura: `teste-gatilho-designados.sh`, **12** casos, com quatro mutações conferidas
(ausência, deriva, imutabilidade do baseline, conferência de `sha256` do DESIGNATION).

⚠️ **Uma delas corrigiu o próprio teste.** A mutação "baseline passa a ser sobrescrito"
deixava `T3b` e `T7b` **verdes** — os dois casos que eu havia escrito justamente para
proteger a imutabilidade. Motivo: nos dois há **ausência**, e o bloco de criação recusa
criar sobre estado quebrado, então o baseline fica intacto de qualquer forma. O caso que
prova a imutabilidade é outro — deriva detectada e **segunda** execução ainda `YELLOW`
(`T10`) —, e com ele a mutação passa a derrubar 5 casos. Teste que morde a mutação **pelo
motivo errado** não protege o que se pensa.

##### E uma regra de calibração que estava invertida no `morning-report.sh`

O comentário que fixa o teto de idade dizia *"Se der < 1, o guarda esta CEGO"*, e
**contradiz os dois exemplos que ele mesmo dá três linhas abaixo**. Computado:

| gatilho | teto | idade normal | intervalo | `rodadas_toleradas` | 1 falha | o comentário chama de |
|---|---:|---:|---:|---:|---|---|
| saturação 09:12Z | 30 h | 21,3 h | 24 h | **0,36** | 45,3 h ⇒ dispara | OK |
| saturação 05:41Z | 30 h | 0,8 h | 24 h | **1,22** | 24,8 h ⇒ silêncio | CEGO |

Cego ⟺ `rodadas_toleradas ≥ 1`, o inverso do que estava escrito. Quem calibrasse pela
regra, e não pelos exemplos, escolheria o teto ao contrário. Corrigido no mesmo dia.

#### 10.10 🔴 O serving lê um snapshot congelado por *file descriptor* — e isso reescreve §10.7

> ⚠️ **A DATA deste item foi corrigida pelo §10.11 (2026-09-09).** O achado, a
> delimitação dos snapshots equivalentes e a validade dos vereditos até o epoch 09-06
> seguem de pé. O que caiu foi a justificativa aritmética de `2026-09-15`: ela supunha
> que nada mais entra no pool, e a ingestão de sessões é por *hook* dirigido por
> atividade de agente. Data vigente: **`2026-09-10 09:00Z`**.

Achado em 2026-09-08, ao investigar por que o log de serving registrava ids que **não
existem** no banco. Domina os dois itens anteriores e corrige uma conclusão do §10.5.

**Medido.** `nox-mem-api` está no ar desde `2026-09-03 17:23:30 UTC` e roda com
`NOX_EPOCH_SNAPSHOT=active`, isto é, serve de um snapshot de epoch. O caminho é o symlink
`/var/lib/nox-mem/epochs/current.db`, que o cron reaponta às 06:00Z todo dia.

| o quê | inode |
|---|---|
| `current.db` → `e20260908T060004Z.db` (hoje) | **524930** |
| fd 26 do processo: `e20260903T060001Z.db` **(deleted)** | **553124** |

O processo **resolveu o symlink uma vez**, em 03/09 17:30, abriu o arquivo apontado então e
nunca reabriu. O symlink mudou cinco vezes desde aí e os snapshots antigos foram podados
do disco — o arquivo que o serving lê **só existe pelo descriptor**.

⚠️ **Recuperado antes de qualquer restart**, via `cat /proc/<pid>/fd/26`, em
`/var/lib/nox-mem/p2/corpus-SERVING-REAL-e20260903-recuperado.db` (1.197 MB,
`quick_check = ok`). Era a única cópia do corpus que serviu 5 dias de ensaio; um restart a
teria apagado para sempre.

##### O que o corpus do serving realmente contém

| medida | valor |
|---|---|
| total de `chunks` | **67.187** |
| `MAX(created_at)` | **2026-08-24 01:06:35** |
| os 53 ids "mortos" do §10.9 | **presentes** |
| chunks de sessão de 08/09 | **0** |
| `agentFresh` elegível | **0** |

##### 🔴 Correção do §10.7: o canal NÃO mudou de composição para o serving

O `gatilho-composicao.mjs` lê `current.db` e resolve o symlink **a cada execução horária**;
o serving lê o inode de 03/09. Hoje os dois divergiram pela primeira vez: o gatilho vê
**219** candidatos de `agentFresh`, o serving vê **0**.

Logo o `RED` de `2026-09-08T06:09:04Z` é **verdadeiro sobre o corpus do gatilho e falso
sobre o canal que o ensaio serve**. `interleaveFresh` continua sendo função-zero. **Não
existe "regime intercalado"**, e os 7 epochs que o §10.7 lista como afetados **não foram
afetados**. A decisão de tratamento registrada ali (nenhum epoch sai) fica **sem objeto**
— e não é revogada, porque não havia o que tratar.

⚠️ **O gatilho funcionou por coincidência até hoje.** Os dois corpora concordavam em
`agentFresh = 0` porque o banco estava congelado (§10.5) — não porque o gatilho vigiasse a
grandeza certa. Vigiar o corpus **do symlink** quando o serving tem um **fd** é a mesma
família de "monitor que reimplementa o predicado do código": ele mede uma coisa parecida,
que coincide até deixar de coincidir.

##### 🔴 Correção do §10.5: o congelamento não terminou em 07/09 — está em curso

O §10.5 mediu que o corpus estava congelado em `2026-08-24 01:06:35` por defeito do
watcher, e datou o conserto em `2026-09-07T14:06:13Z`. O conserto descongelou o **banco
vivo** e os **snapshots** seguintes. Não descongelou o **serving**: para ele
`MAX(created_at)` segue `2026-08-24`, e seguirá até o processo reabrir o arquivo.

Os "6 de 234 epochs afetados" do §10.5 estão portanto **subcontados**: o congelamento
alcança todo epoch servido por este processo, do `2026-09-01` em diante e **sem fim
declarado**.

##### O que este achado NÃO explica — delimitado por medição, não por suposição

| snapshot | total | `MAX(created_at)` | `agentFresh` |
|---|---:|---|---:|
| serving real (03/09) | 67.187 | 2026-08-24 01:06:35 | 0 |
| `e20260906T060001Z` | 67.187 | 2026-08-24 01:06:35 | 0 |
| `e20260907T060001Z` | 67.187 | 2026-08-24 01:06:35 | 0 |
| `e20260908T060004Z` | **67.606** | **2026-09-08 02:37:34** | **253** |

Os snapshots de 03/09 a 07/09 são **equivalentes em conteúdo** — o banco esteve congelado
desde 24/08, então qual deles se usa era **inerte**. A divergência começa **exatamente** no
snapshot de `2026-09-08 06:00Z`. Consequências:

- os vereditos de dose até o epoch `2026-09-06` foram medidos em 07/09 09:12Z com o
  snapshot de 07/09 ⇒ corpus **equivalente** ao do serving ⇒ **não** são invalidados por
  este achado;
- o `faltam=1` do §10.9 e o `dose-servida-inerte` de 09-04/09-05 **não** se explicam pelo
  fd, pelo mesmo motivo. O primeiro segue sem causa confirmada;
- o que este achado invalida é o `RED` de composição de hoje e a medição do §10.7 —
  ambos posteriores a 08/09 06:00Z.

⚠️ Registro deste raciocínio porque a tentação era atribuir **tudo** ao fd, que é uma
causa vistosa e recém-achada. Três dos quatro sintomas do dia são anteriores à divergência
e continuam com as suas próprias causas.

##### A decisão que isto abre, e ela não é minha

Reiniciar o `nox-mem-api` realinha o corpus — e faz o canal do serving pular de 67.187
para 67.606 chunks e de `agentFresh = 0` para 253, **de uma vez, no meio do ensaio**. Não
reiniciar mantém o ambiente estável e consistente com os epochs já servidos, ao custo de
uma validade externa presa a 24/08 pelo resto do estudo. As duas escolhas precisam ser
declaradas, e a fronteira do restart — se houver — tem de cair numa fronteira de epoch,
não no meio de um.

E há um **fix de código** por trás: o serving deveria reabrir o snapshot na virada de
epoch, ou seguir o symlink em vez de manter o descriptor. Implementá-lo **muda o
comportamento do ensaio**, e por isso não é conserto rotineiro.

#### 10.11 🔴 A data do realinhamento era premissa falsa: `agentFresh` **não** volta a zero

**Registrado em 2026-09-09, antes de qualquer ação e antes de consultar qualquer
desfecho.** O que foi medido para decidir é **exclusivamente** a proveniência do fluxo
de ingestão e a distribuição temporal do pool. Nenhum resultado do ensaio foi
computado, consultado ou estimado.

O §10.10 fixou o realinhamento em `2026-09-15 09:00Z` sob a premissa de que os 253
chunks de sessão de 08/09 sairiam da janela de 7 dias às `2026-09-15 00:00:00Z` e
`agentFresh` **voltaria a 0 por expiração**, tornando o restart uma pura atualização de
corpus. A premissa supõe que **nada mais entra**. Está falsa.

**Medido em 2026-09-09:**

| fato | medição |
|---|---|
| elegíveis na janela | **285** = 219 (`source_date` 08/09) + **66 (09/09)** |
| entrada dos 66 | `created_at` 01:01:00 → 01:02:13, **3 arquivos** `sessions/boris/*` |
| cron responsável | **nenhum** — a ingestão é por *hook* (`nox-mem-ingest.sh`), disparada por **atividade de agente** |
| `session-distill` do nightly | **`Phase 4: Sunday`** — próximo domingo é **2026-09-13** |
| histórico de ingestão de sessão (60 d) | rajadas em jul/ago, **nada de 11/08 a 07/09** (28 d), retomada em 08/09 |

Duas consequências, e a segunda é mais importante que a primeira.

**(a) O script abortaria para sempre.** A pré-condição 3 exigia `agentFresh == 0`. Com
`session-distill` rodando domingo 13/09 e o *hook* injetando a cada sessão de agente, a
condição não se satisfaz em 15/09 — nem depois. Um script de ação cujo predicado exige
um estado que não retorna não falha: **fica calado**. É a regra 9 do `CLAUDE.md`
(*guarda cujo predicado exige o dado que falta não cobre a falta do dado*) aplicada a um
caminho de **ação**, onde o silêncio é indistinguível de "ainda não chegou a hora".

**(b) O regime da calibração era o regime QUEBRADO.** O buraco de 28 dias na ingestão de
sessões coincide com a migração que moveu endereço e schema das sessões, consertada em
07/09. A medição de `agentFresh` **vazio** de 26/08 — que fundamenta a escala de dose de
27/08 — foi feita **dentro** desse buraco. Não existe "voltar ao regime da calibração"
sem quebrar a ingestão de novo. O canal com `agentFresh` não-vazio é o comportamento
**correto** do sistema; o outro era o defeito.

⇒ Esperar a expiração não é conservador, é **indefinido**. E cada dia de espera é um dia
em que o serving expõe a partir de um corpus congelado em `MAX(created_at) = 2026-08-24`.

**Delimitação honesta do custo de esperar.** O congelamento atinge **os dois braços
igualmente** — é o mesmo corpus para tratamento e controle. Ele **não** enviesa a
comparação interna; degrada **validade externa** (o ensaio mede sobre um corpus que
envelhece). Já a composição do canal muda a **posição** dos designados no `interleave`,
o que afeta a **dose efetiva** — e essa é interna. Portanto a pressa não se justifica
pelo congelamento; o que se justifica é **não esperar por um evento que não vem**.

### Decisão

**Realinhar em `2026-09-10 09:00Z`** (quinta), não em 15/09. Escolha da fronteira:

| epoch | dia | arm | por que importa |
|---|---|---|---|
| 2026-09-09 | qua | treatment `w=2.0` | **em curso** — não se corta epoch no meio |
| **2026-09-10** | **qui** | **control `w=0`** | ⬅️ **fronteira escolhida** |
| 2026-09-11 | sex | control `w=0` | 2º epoch de controle limpo no regime novo |
| 2026-09-12 | sáb | treatment `w=4.0` | 1º tratamento **inteiramente** dentro do regime novo |

O regime novo estreia em **controle**, com dois epochs de controle antes do primeiro
epoch de tratamento — o contraste dentro do regime começa sem dose, e o primeiro
tratamento nasce inteiro. Estrear numa fronteira de tratamento faria o regime novo
começar já sob dose.

**A pré-condição 3 muda de natureza:** deixa de exigir `agentFresh == 0` e passa a
**medir e registrar** `agentFresh`/`globalFresh` no `ndjson`, abortando apenas se a
**medição** falhar. As outras quatro seguem intactas e abortivas: fronteira de epoch,
guarda de alinhamento em RED, 19/19 designados presentes, recuperação do corpus antigo
com `quick_check = ok`.

**Regra de tratamento — inalterada.** A análise já pré-especificada no §10.7 é o
instrumento para isto e não precisa de emenda: *primary* + co-estimador ITT com todos os
epochs, **mais** o mesmo par com os epochs do regime intercalado excluídos. O que o
§10.11 acrescenta é que a fronteira do regime novo passa a ser **`2026-09-10 09:00Z`**, e
que o conjunto "regime intercalado" é `{09-08 … 09-09}` do canal congelado mais tudo a
partir de `09-10` no canal realinhado — a serem enumerados a partir do `ndjson` dos
guardas, não de contagem à mão.

⚠️ **Isto não retira nada do §10.10.** O achado do *file descriptor*, a delimitação dos
snapshots equivalentes (03/09–07/09) e a validade dos vereditos de dose até o epoch
09-06 continuam de pé. O que muda é **só a data** e o **predicado da pré-condição 3** —
e muda porque a justificativa aritmética da data supunha um mundo sem ingestão.


#### 10.12 A causa do `faltam=1`: o replay descarta briefs **lentos**

**Medido em 2026-09-09.** Fecha o item que o §10.4 deixava aberto e que o HANDOFF
registrava como "sem causa estabelecida". Nenhum desfecho foi consultado: o que se mediu
é o **mecanismo de casamento** entre o log de serving e o `brief_log`.

Distribuição de `cands.length` em `idDoBrief()` sobre a janela de 09-06: **`{0: 1, 1: 671}`**
— reproduz `estados=671 / n_janela=672 / faltam=1` exato. O único descartado é
`ts=2026-09-06T23:07:02.425Z`, `agent=nox`, `churn=0`.

O `brief_id=a1ebbe3f-3567-4169-a6c5-84e601bd0aa7` tem as **dez** linhas. O que se
espalha é o `served_at`:

| `id` | `served_at` | `chunk_id` |
|---|---|---|
| 647955 | `2026-09-06 23:07:02` | 116467 |
| 647956 … 647964 | `2026-09-06 23:07:09` | os outros nove |

`idDoBrief()` casa por `served_at IN (t, t+1s, t+2s)`. As nove de `:09` ficam **fora**, o
`GROUP_CONCAT` devolve **um** id, não casa com os dez do ndjson, `cands.length === 0`, e o
estado sai por `continue`.

**Span por brief na janela:** 670 com span 0 s, 1 com 1 s, **1 com 7 s**. Um outlier, e é ele.

### Três afirmações anteriores que isto corrige

1. **O comentário do `gatilho-saturacao.sh`** atribuía o descarte a *"escrita incompleta
   no `brief_log` (1 linha de 10)"*. **Errado na causa, certo no alvo:** o brief tem as
   dez linhas; "1 linha de 10" é o que se **vê** de dentro da janela de 3 s. Sintoma
   lido como causa. Corrigido no próprio arquivo, com o mecanismo.
2. **A medição por `brief_id` de 08/09** (672 briefs, dez linhas cada, zero incompletos)
   está **certa** e refuta *incompletude* — mas não localiza o defeito, e concluir dali
   que "a explicação está falsificada, logo não há defeito ali" inverte o sentido. As
   duas medições são verdadeiras sobre **populações diferentes**: a janela do epoch
   inteira contra uma janela de 3 s.
3. **A hipótese de ambiguidade** (`cands.length > 1`, plausível porque `served_at` tem
   resolução de segundo e colide entre briefs) está **morta**: deu 0, não 2.

### Por que é viés, e não ruído

O critério de exclusão não é composição do brief — é **latência de escrita**. Latência
não é independente de carga, e carga não é independente de quanto trabalho o brief deu.
⇒ O descarte é potencialmente **correlacionado ao que se mede**. É a mesma classe do
`estados=640` (`672 − 32`) do §10.4 — *regra que exclui em vez de atribuir* — na versão
de tamanho 1, com um critério novo.

Com `n=1` e `churn=0`, o dano **neste** epoch é nulo, e o veredito de 09-06 segue
utilizável. A classe é que fica registrada.

### O que o conserto **não** é

Casar por `brief_id`: o `p2_outcome` do ndjson **não tem** esse campo — medido, 0/672. Os
campos são `ts, tag, epoch, modo, w, servido, scope, agent, ids_controle, ids_tratado,
churn, would_enter, would_leave, fresh_added, designated_ids, boost_by_id`. A
reconstrução por (agent, segundo, ids) é hoje necessária.

Duas frentes, nenhuma executada nesta entrada:

- **histórico** — alargar a janela de casamento e desambiguar pelos ids. Exige medir o
  custo em ambiguidade **antes**: alargar aumenta `cands.length > 1`, que é a *outra*
  saída para `null`. Trocar um descarte por outro não é conserto.
- **raiz** — emitir `brief_id` no `p2_outcome`, eliminando a reconstrução para frente.

⚠️ Enquanto nenhuma das duas estiver feita, todo `faltam=N` do gatilho deve ser lido como
**"N briefs cuja escrita atravessou a janela de casamento"**, e não como perda de dado.


#### 10.13 🔴 Dois defeitos que o desenho não previa: o canal perde capacidade no corpus atual, e os designados saem do pool em 2026-09-20

**Registrado em 2026-09-09, antes de qualquer ação e sem consultar desfecho.** O que se
mediu é **capacidade do canal** e **elegibilidade dos alvos** — nunca resultado.

### (A) O RED de produção é artefato de instrumento — e o número inverte para o lado ruim

O `run-saturacao.sh` passa `--corpus /var/lib/nox-mem/epochs/current.db`. O serving **não
lê** esse corpus desde 03/09 (§10.10). Rodando o **mesmo** gatilho, **mesmo** log
(`sha256 d5ba483d…`), **mesmo** `estados=672`, **mesma** janela, variando **só** o corpus:

| corpus | veredito | `mexem_servido` | `mexem_absurdo` | folga |
|---|---|---:|---:|---:|
| o que o serving **leu** (recuperado do `fd`, `agentFresh=0`) | **GREEN** dose responsiva | **20** | **37** | **0,5405** |
| `current.db` (produção usou, `agentFresh=285`) | RED sem capacidade | **0** | **0** | — |

⇒ **A intervenção está viva no epoch 09-08.** O par utilizável é `20 / 37 / 0,5405`, do
corpus servido. O RED diário do gatilho é **falso positivo** enquanto o `fd` estiver
pinado, e conta no `red=` do morning report.

⚠️ **E a dose não conserta.** A corrida de produção testou `w = 100 000`: `mexem_absurdo=0`.
Boost é **aditivo** (regra 5 do `CLAUDE.md`); se a dose absurda não move, **nenhum `w`
move**. Isto **não** é falha de calibração — é falta de capacidade do canal. Recalibrar
`w` sobre o corpus novo não recupera nada.

**Mecanismo NÃO estabelecido, e o candidato do `agentFresh` está FALSIFICADO**
(2026-09-09, sessão `memoria-nox-21`): 384 de 672 briefs são de agentes com sub-pool
vazio nos **dois** corpora, para quem o freshPool é estruturalmente idêntico, e `mexeu`
é 0 sobre os 672. Ver §10.14. Outro candidato lido no código, **não verificado**: a Fase 0 de
`pickDedup` reserva `pinned` (high-pain já presentes no brief) que *"entram primeiro e
nunca são expulsos pelo freshness slot"*, e *"pinned excedente come dos fresh slots"* —
com `freshSlots = 2`, dois pinned zeram o canal. Não meço isso aqui, e **não atribuo**:
os dois corpora diferem em `agentFresh` (0 → 285), `globalFresh` (108 → 115) e 419
chunks. Atribuir a `agentFresh` seria inferência sobre o `interleaveFresh`, e a classe
*reconstrução modela regra que o código nunca aplica* já apareceu **cinco vezes** neste
repo.

### (B) Os alvos saem do pool em 2026-09-20, e o desenho não fecha

Os 19 designados têm **`source_date` = NULL**; o `2026-08-21 22:51:23` é o
**`created_at`**, e é um **único** valor para os 19 — eles saem da janela **juntos**.
(Medi com `COALESCE(source_date, created_at)` e reportei como `source_date`; a
desambiguação é da sessão `memoria-nox-21`, e **fortalece** a conclusão: caindo no
`created_at`, o predicado não se renova nem por reingestão parcial — só criando chunk
novo, que é exatamente o que troca o id.) A janela do sub-pool global é
`freshGlobalMaxAgeDays = 30` (default; nenhum `NOX_BRIEF_DIV_FRESH_*` no env do unit)
⇒ saem em **2026-09-20 22:51:23**. Depois disso **nenhuma
dose os alcança, em nenhum corpus** — não é questão de capacidade, é elegibilidade.

| | |
|---|---|
| epoch 1 no ar | 2026-09-01 |
| alvos elegíveis até | **2026-09-20** |
| último epoch previsto | 2027-04-22 |
| ⇒ fração do ensaio **com alvo alcançável** | **8,2 %** (19 dias de 232) |

Um ensaio de 234 epochs com alvos fixos é **incompatível** com um pool que só admite os
últimos 30 dias. É inconsistência **interna** do desenho, descoberta agora — não mudança
de circunstância.

**E o `source_date` não pode ser renovado.** Os **19 de 19** arquivos-fonte
(`memory/entities/lessons/<hash>.md`) estão **apagados do disco**, **nunca foram
versionados** (`git log --all --diff-filter=AD` vazio; `git ls-files` devolve 42, que são
os que existem) e **não estão nos checkpoints** (0 arquivos em `entities/lessons/`).
Renovar exigiria reingestão, que **troca os ids** e mata a designação (§10.9).

⇒ Os 19 chunks no banco são a **única cópia** do ativo. Salvos em
`/var/lib/nox-mem/p2/DESIGNADOS-CONTEUDO-20260909T103409Z.json` (19/19, `sha256 92060a9f…`,
modo 600).

⚠️ **O guarda de designados diz GREEN 19/19 e está certo pelo seu predicado** — ele lê o
**banco**, onde os chunks estão. É cego para "o arquivo-fonte não existe", que é a regra 9
do `CLAUDE.md` reaparecendo **dentro do guarda escrito em 08/09 para proteger este
ativo**. Perna nova é necessária.

### Decisão do Toto (2026-09-09) e a dependência que a condiciona

Escolhido: **alargar a janela do pool global** e **manter o cron do realinhamento
desarmado**.

> ⚠️ **A primeira metade desta decisão foi REVERTIDA no mesmo dia — ver §10.14.** O que a
> reverteu: o corpus congelado não protege da expiração (o predicado usa o relógio de
> **request**), logo alargar não prolonga o ensaio, prolonga o registro de um ensaio
> inerte. O cron segue desarmado.

Alargar resolve **(B)**. Medido, sobre o corpus atual:

| janela | pool global | designados em 21/09 | cobre 22/04/2027 |
|---|---:|---|---|
| 30 d (atual) | 115 | **0/19** | não |
| 90 d | **116** | 19/19 | não — só até 19/11/2026 |
| ≥ 244 d | **305** | 19/19 | sim |

Cobrir o ensaio inteiro **triplica** o pool (115 → 305). Não existe valor que cubra
abril/2027 sem esse salto: ele acontece entre 90 d e 180 d, e o mínimo necessário é 244 d.

🔴 **A dependência:** `diversityConfigFromEnv()` é chamado **por request**
(`dist/api/brief.js:819`) mas lê `process.env`, e o env de um processo em execução **só
muda com restart**. Logo alargar a janela **exige o restart** que a segunda decisão mantém
desarmado — e o restart traz o corpus atual, que é onde **(A)** vale. As duas decisões,
como escolhidas, são **incompatíveis** sem resolver (A) primeiro.

### Delimitação: o instrumento **não** expira; o ensaio expira

O harness de replay compensa a idade (`cfgEm` soma `desloc` a
`freshGlobalMaxAgeDays`), como o cabeçalho promete. Depois de 2026-09-20 o replay
**continua respondendo certo** — quem deixa de morder é a **produção**. Sem esta
delimitação, o item acima se leria como se a medição também fosse expirar.

### Dois defeitos do instrumento, achados ao investigar (A) — consertos pendentes

**(i) O recibo não registra o corpus.** Os campos gravados são `absurdo, estado, folga,
janela, motivo, n_janela, semantica, servido, sha256_janela, tag, ts, via, w_servido`.
Há `sha256` **do log** e **nada** do corpus. Consequência medida: o GREEN `20/37` e o RED
`0/0` têm o **mesmo** `sha256_janela = d5ba483d…`, a mesma janela e o mesmo
`estados=672` — **dois vereditos opostos com recibos indistinguíveis**. Enquanto
existirem três corpora em jogo (o `fd` pinado, o symlink que anda, os snapshots), nenhum
veredito de saturação é interpretável. Conserto: gravar `corpus_path` **e**
`corpus_sha256` no ndjson e no status.

**(ii) `--corpus current.db` é um symlink que anda.** O relink acontece às 06:02, então o
gatilho replaya o epoch **fechado de 08/09** contra o snapshot de **09/09**, e o alvo
troca sozinho todo dia. Conserto: apontar para o snapshot do epoch que fechou. É a lição
do cabeçalho do próprio harness (*"a primeira remediação usou o DB vivo como corpus
quando a produção serve o snapshot de epoch"*) reaparecida na **fiação do wrapper**.

### Evidência independente do instrumento

Medido **direto do `p2-serving.ndjson`**, sem replay (sessão `memoria-nox-21`):

| epoch | n | w | servido | `churn>0` | desig. controle → tratado |
|---|---:|---|---|---:|---|
| 2026-09-06 | 672 | 7,5 | tratado | **38** | 124 → 144 |
| 2026-09-07 | 672 | 0 | controle | 0 | 175 → 0 |
| **2026-09-08** | **672** | **2** | **tratado** | **20** | **172 → 187** |

`churn > 0` em **20** de 672 (2,98%, contra 3,74% da era shadow) — **o mesmo 20** do
`mexem_servido`. Duas vias independentes, e esta **não depende de escolher corpus**, que
é justamente o parâmetro que estragou a outra. ⇒ O mecanismo **mordeu em produção** no
epoch 09-08.

**Nada foi aplicado.** O que está feito: ativo salvo, cron desarmado, medições acima.


#### 10.14 Decisão revisada (2026-09-09, tarde): **não alargar a janela**. O ensaio termina em 2026-09-20

> ⚠️ **O FUNDAMENTO desta seção foi corrigido pelo §10.15 (mesma tarde).** O argumento de
> que o corpus realinhado mataria o mecanismo é **verdadeiro sobre o estado e falso sobre
> o corpus**: o zero vem de uma coorte nunca-servida ocupando os `freshSlots`, e esse
> estado **dura ~1,2 h** (medido em coorte histórica). A decisão pode se sustentar pela
> **expiração de 20/09** e pelo custo de triplicar o pool — não pelo que está escrito
> abaixo sobre valor nulo.

**Registrado antes de qualquer ação e sem consultar desfecho.**

A decisão de manhã (§10.13) foi *alargar `freshGlobalMaxAgeDays`*. Ela está **revertida**,
e o que a reverteu é uma medição que faltava: **o corpus congelado não protege da
expiração.**

O predicado do sub-pool usa `julianday('now')` (`dist/api/brief.js:470`) — relógio de
**request**. O `fd` pinado congela os **dados**, não o **tempo**. Medido no próprio
corpus servido (o recuperado):

| data | designados no `globalFresh` |
|---|---|
| 2026-09-09 | 19/19 |
| 2026-09-15 | 19/19 |
| 2026-09-20 | 19/19 |
| **2026-09-21** | **0/19** |

⇒ Os dois cenários terminam no **mesmo dia**:

| cenário | epochs úteis |
|---|---|
| **não alargar** | **até 2026-09-20**, ~20 epochs, com canal medidamente ativo (`churn>0` em 20/672 no epoch 09-08) |
| alargar | os mesmos ~20 **mais** 214 epochs cujo valor **não está estabelecido**, ao custo de triplicar o pool |

⚠️ **O que eu NÃO posso afirmar, e quase afirmei.** A primeira versão desta seção dizia
que alargar daria *"214 epochs de zero"*, apoiada no `mexem_absurdo = 0` sobre o
`current.db`. Isso **não** se sustenta, e a refutação veio da sessão `memoria-nox-21`:

- **A hipótese do `agentFresh` está falsificada.** **384 de 672 briefs (57,1%)** são de
  agentes com sub-pool **vazio nos dois corpora** (`nox:0, atlas:0, lex:0`), para quem
  `interleaveFresh([], globalFresh) === globalFresh` — freshPool estruturalmente
  idêntico. Se o deslocamento fosse a causa, esses 384 continuariam se movendo. `mexeu`
  é 0 sobre os **672**.
- **O replay rastreava a produção até 01/09 e parou quando o corpus divergiu.** Em 29/08:
  `mexeu(2) = 30` contra `churn>0 = 30`. Os três REDs (05, 06 e 09/09) são os três dias
  em que deixou de rastrear, e o `fd` pinado tem mtime `2026-09-03 17:30`.

⚠️ **E a correção da correção (mesma tarde).** Eu havia concluído daí que *"`mexeu = 0`
aparece quando o corpus do replay não é o que serviu"* — e **retirei uma afirmação
verdadeira**. `mexeu` é **interno ao corpus**, verificado no código:

```js
// dist/api/brief.js:628
diffP2 = diffBriefs(alt.items.map(i=>i.id), altBoosted.items.map(i=>i.id), …)
```

`alt` (sem boost) e `altBoosted` (com boost) saem **ambos** de
`buildBriefDiverse(corpus, …)`, o **mesmo** banco; e o replay lê `churn: out.diffP2.churn`.
Logo `mexeu` conta estados em que a dose muda a saída **contra a saída sem dose no mesmo
corpus** — não depende de casar com o corpus servido.

⇒ **`mexem_absurdo = 0` é afirmação verdadeira sobre o `current.db`.** O par que rodei é
contraste isolado com **uma** variável (mesma janela `sha256 d5ba483d…`, mesmo
`estados=672`, mesmo serve-state, mesmos `t_ref`):

| corpus | `mexeu(2)` | `mexeu(10⁵)` | leitura |
|---|---:|---:|---|
| recuperado (o que **serviu**) | **20** | **37** | canal existe e responde |
| `current.db` (realinhado) | **0** | **0** | canal ausente |

E o **20** bate exato com o `churn>0 = 20` que a produção registrou, por via independente
do replay ⇒ **validação externa**: no corpus que serviu, o harness reproduz o mundo.

**Conclusão que os dois números sustentam:** não é que o replay falhe no corpus novo — é
que **o corpus novo mata o mecanismo**, medido até em dose absurda. O que fica
indecidível é a **magnitude sob serving real**, não o **sinal**. (E a "quebra de
rastreamento" a partir de 05/09 é compatível: o harness sempre calcula certo sobre o
corpus que **recebe**; o que mudou é que o corpus recebido deixou de ser o servido.)

**Então o fundamento é mais forte do que eu havia escrito.** Alargar a janela exige
restart; o restart faz o serving abrir um snapshot construído do vivo **realinhado** — a
família medida com `mexeu(10⁵) = 0`. Não são 214 epochs de valor *desconhecido*: há
medição apontando para valor **nulo**. Somado a:

1. A expiração de 2026-09-20 encerra o ensaio **nos dois cenários** — o corpus congelado
   congela dados, não o tempo.
2. Cobrir abril/2027 exige janela ≥ 244 d, que **triplica** o pool global (115 → 305),
   mudando a composição do canal para **todos** os candidatos, em ensaio pré-registrado.
3. O que se compraria são 214 epochs num corpus onde o canal **não responde nem a dose
   absurda**, contra um custo conhecido de mudança de desenho.

⚠️ O que **não** está estabelecido: **por que** o corpus realinhado mata o mecanismo.
`agentFresh` está **excluído** (os 384 briefs de sub-pool vazio); sobram `globalFresh`
108 → 115 e a deriva de +537 chunks no pool principal, e nenhuma das duas foi medida. E
não se sabe se um epoch **servido** do corpus novo se comportaria como o replay dele —
isso exigiria o restart.

Trocar composição de pool sob incerteza sobre o resultado é o oposto do que um
pré-registro serve para prevenir.

### O que fica decidido

1. **Nada é alargado.** `freshGlobalMaxAgeDays` permanece em 30 (default).
2. **O cron de realinhamento permanece desarmado.** Reiniciar antecipa a inércia sem
   comprar nada.
3. **O ensaio encerra em `2026-09-20 22:51Z`**, por expiração dos alvos, com os epochs
   de `2026-09-01` a `2026-09-20`. O que se reporta é o que esses epochs contêm, com a
   limitação declarada — não os 234 pré-registrados.
4. **Os 11 dias restantes vão para os consertos de instrumento**, que não tocam o
   serving: `corpus_path`/`corpus_sha256` no recibo, e `--corpus` apontando para snapshot
   de epoch fechado em vez do symlink que anda (§10.13, i e ii).

### O que o ensaio entrega, dito sem eufemismo

**~20 epochs de 234 (8,5%).** A potência cai proporcionalmente e a alocação `117/39/39/39`
não se realiza — o que existe é o prefixo dela. A causa é **defeito de desenho**, não
circunstância: alvos fixos designados sobre um pool que só admite os últimos 30 dias
nunca poderiam sustentar 8 meses, e isso era verdade desde a designação de 2026-08-26.

⚠️ **O que NÃO é conclusão sobre a intervenção.** O mecanismo **funcionou** onde pôde
agir: `churn>0` em 20 de 672 no epoch 09-08 e 38 de 672 no 09-06, por duas vias
independentes (log de produção e replay sobre o corpus servido). A limitação é de
**duração**, não de efeito — e escrever "a intervenção não se sustentou" seria a conclusão
nula tirada de um prazo, que é a classe que este documento persegue desde o §10.4.

### Se um ensaio futuro for desenhado

O erro a não repetir: **designação por id fixo é incompatível com pool por janela de
recência.** Ou a designação acompanha uma coorte rotativa, ou o alvo tem de estar num
pool sem janela. E o guarda tem de vigiar **elegibilidade**, não só presença — o
`gatilho-designados.mjs` dizia GREEN 19/19 todos os dias enquanto o prazo corria, e
estava **certo** pelo seu predicado.


#### 10.15 O mecanismo do zero: coorte nunca-servida ocupa os `freshSlots` — e o estado dura ~1,2 h

**Medido em 2026-09-09 (tarde), com a sessão `memoria-nox-21`.** Fecha o "mecanismo NÃO
estabelecido" do §10.13 (A) e **corrige o §10.14 pela quarta vez**. Nenhum desfecho
consultado: o que se mediu é ordem de pool e histórico de `last_served`.

### O mecanismo

`fetchFreshCandidates` ordena por **`last_served ASC`** e só depois pela salience
(`dist/api/brief.js:551`; o comentário em `:537` diz *"o LIMIT corta pelos
MENOS-recentemente-servidos (`last_served ASC` ⇒ NULLs…"*). O boost é **aditivo** ⇒
desempata **dentro** de um estrato, nunca atravessa estratos.

`memory/lessons.md` foi **reingerido em 2026-09-07**: 60 chunks novos entraram (idade
2,50 d) e ~53 ids morreram. Estado dos dois pools, medido inteiro:

| pool | tamanho | **nunca-servidos** |
|---|---:|---:|
| corpus **servido** (recuperado do `fd`) | 108 = 55 `entities/*` + 53 `lessons.md` | **0** |
| `current.db` | 115 | **60** |

⇒ Não é "60 entraram num pool de 108": é **60 nunca-servidos entraram num pool que tinha
zero**. Com `freshSlots = 2`, 60 candidatos em `last_served = NULL` ocupam os dois slots
em qualquer brief, e **nenhum `w` promove um designado** — todos os 19 têm `last_served`
preenchido (último `2026-09-09 11:52:06`). Não é preciso invocar dose.

⇒ **`mexem_absurdo = 0` não significa "o canal não existe".** Significa *"o canal está
atrás de uma coorte que o bônus não pode atravessar"*. Duas leituras opostas do mesmo
zero, e `--modo dose` sozinho não as separa — o que separa é consultar `last_served` dos
dois conjuntos.

### O estado dura ~1,2 hora — e isso desfaz a inferência sobre o restart

A coorte de `lessons.md` criada em 22/08 (os mesmos 53) estreou assim, no `brief_log`:

```
2026-08-22 19  →  20 chunks estrearam
2026-08-22 20  →  33 chunks estrearam
span: 19:23:13 → 20:37:18  =  1,2 h
```

**53 nunca-servidos consumidos em 1,2 h**, com a produção em regime normal.

⇒ `mexem_absurdo = 0` descreve um **estado**, não uma propriedade do corpus. O replay não
o vê dissolver porque reproduz **672 vezes o mesmo serve-state inicial**; na produção o
estado evolui e o estrato esvazia.

### Quatro versões deste parágrafo, e por que isso é o registro e não vergonha

| versão | afirmava | caiu por |
|---|---|---|
| 1 | alargar dá "214 epochs de zero" | hipótese do `agentFresh` falsificada (384 briefs de sub-pool vazio) |
| 2 | `mexeu = 0` é artefato de corpus descasado | `mexeu` é **interno ao corpus** (`brief.js:628`, `alt` e `altBoosted` do mesmo `db`) |
| 3 | o corpus novo **mata** o mecanismo | verdadeiro sobre o **estado**, falso sobre o **corpus** — o estado dura 1,2 h |
| **4 (esta)** | coorte nunca-servida ocupa os slots; estado transitório de ~1-2 h | — |

As quatro foram publicadas no repositório. O padrão é claro e é o achado
meta-metodológico do dia: **conclusão escrita antes de esgotar a medição**, quatro vezes,
por duas sessões, sobre o mesmo zero. Cada inversão veio de **uma consulta**, nunca de
releitura.

### O que isto muda, e o que NÃO muda

**Muda:** o argumento *"prolongar não tem valor porque o canal está morto"* **cai**.

⚠️ **Força da afirmação, corrigida:** o precedente é **um**. O que os dados sustentam é
*"a única coorte medida drenou em 1,2 h"*, **não** *"custaria ~1-2 h"*. A taxa depende de
quantos slots a rajada gasta em chunk repetido, e isso não foi medido (as rajadas do mesmo
segundo veem o mesmo serve-state). Ressalva da `memoria-nox-21`, e é de força, não de
direção.

O que **está** observado é o **ciclo inteiro**: coorte chega (22/08) → bloqueia → drena
entre 19:23 e 20:37 → e o canal **volta a responder**, que é a série GREEN de 27/08 a
01/09 (`mexeu` = 25, 15, 11, 30, 20, 11). Chegada, bloqueio, dreno e recuperação, todos
no registro — mais forte que a duração sozinha.

**Não muda:** a **expiração de 2026-09-20** encerra o ensaio nos dois cenários (o
predicado usa o relógio de request), e cobrir abril/2027 exige janela ≥ 244 d que
**triplica** o pool. A decisão de não alargar pode se sustentar por **esses** fundamentos
— não pelo que eu havia escrito.

⇒ A decisão volta ao Toto com a premissa corrigida.

### Consequência operacional que vale além do ensaio

O bloqueio não é propriedade deste corpus: é propriedade de **qualquer reingestão** em
`memory/entities/%` ou `memory/lessons.md` — exatamente os caminhos que o watcher mexe.
Enquanto o ensaio rodar, **toda reingestão nesses caminhos bloqueia a intervenção por
~1-2 h**. É a lição do *fix operacional que anula premissa de ensaio em curso*, agora com
mecanismo nomeado.

**O guarda que falta** (proposto pela `memoria-nox-21`, e não implementado aqui):
`COUNT(*)` de chunks no `globalFresh` com `last_served IS NULL` contra `freshSlots`. Se
`>= freshSlots`, a intervenção está bloqueada naquele instante, **independente de `w`** —
computável em **uma consulta**, segundos em vez de 931 s. Com a duração medida, ele ganha
um segundo patamar: se **não** desarmar em ~2 h, aí sim há algo estrutural. Teria dado
alarme em **07/09**, dois dias antes de qualquer um de nós olhar.


#### 10.16 🔴 A superfície servida é um conjunto FECHADO de 141 chunks — 0,21 % do corpus

**Medido em 2026-09-09.** Apareceu ao investigar o dreno de coortes (§10.15) e é
independente dele. Achado da sessão `memoria-nox-21`; verificado e estendido aqui.

| dia | chunks **distintos** servidos | linhas | serves/chunk |
|---|---:|---:|---:|
| 28/08 … 08/09 (12 dias) | **141**, todos os dias | 6.720/dia | **47,7** |
| acumulado desde 31/08 | **141** | — | — |

O acumulado igual ao diário é o ponto: **não é que 141 sejam servidos por dia e o
conjunto rode** — é o **mesmo** conjunto de 141, dia após dia, por 9 dias, sem uma única
substituição. `6.720 = 672 briefs × 10 itens`, e cada chunk é servido ~48 vezes ao dia.

**141 de 67.187 = 0,21 % do corpus servido.**

⚠️ Isto **não** é efeito do congelamento por `fd`: a constância começa em **28/08**, seis
dias antes de o `fd` pinar (03/09 17:30). Também não é efeito da era `active` (01/09).

### Por que isto importa mais que qualquer coisa medida hoje

O reframe de 27/08 fixou que a manchete do paper é a **superfície de exposição**, não a
intervenção. Este número **é** a superfície, medida: um sistema com 67 mil chunks expõe
**141**, e os expõe 48 vezes por dia cada.

Consequências que precisam entrar no enquadramento:

1. **A intervenção age sobre 0,21 % do corpus.** Qualquer efeito medido é efeito *dentro*
   dessa fatia — e o denominador honesto do ensaio não é o corpus, é a superfície.
2. **Os 19 designados são 13,5 % da superfície** (19/141), não 0,03 % do corpus
   (19/67.187). A dose age sobre uma fração muito maior do que a leitura por corpus
   sugere — em qualquer direção que o efeito aponte.
3. **Explica o dreno instantâneo do §10.15 sem invocar nada:** 2 `freshSlots` × 672
   briefs = 1.344 oportunidades/dia contra uma coorte de 53. O estrato NULL não *pode*
   sobreviver a um dia de tráfego — quando o corpus é aberto.
4. **E explica o zero de estreias desde 26/08:** com o conjunto fechado, nenhum chunk
   novo entra na superfície. O estrato NULL vazio no corpus servido não é virtude, é
   **consequência de o corpus estar fechado** (leitura da `memoria-nox-21`, e ela está
   certa).

### O que NÃO está medido

**Por que** o conjunto é fechado. Candidatos não testados: o `CANDIDATE_POOL = 500` com
ordenação estável sobre salience que não muda; a quota `floor(n/2)` por pool; o
`novelty-penalty` suave que deixou de excluir. Nenhum foi medido, e a constância exata
(**141**, sem ±1, por 12 dias) sugere determinismo, não equilíbrio dinâmico — mas
sugerir não é medir.

Isto é território de enquadramento do paper, não de desvio de protocolo, e fica
registrado aqui porque foi medido dentro da janela do ensaio.


## Se a decisão mudar

A máquina do depósito está pronta e **não executada**: `deposit/PLAN-v1.13.md` e
`deposit/deposit-v1.13.sh` (99 arquivos, 45 uploads, três gates passando, readback
duplo). Nada foi enviado ao Zenodo. Voltar para a opção 1 (depositar) ou 3 (agrupar com
o protocolo prospectivo) custa o token e um `prepare`.

⚠️ Se o depósito acontecer meses depois, **reconferir os 6 arquivos substituídos por
md5 antes do `prepare`** — `claims_check.py` e a emenda continuarão recebendo edições, e
o `sync` só corrige o que sabe comparar.

---

## §10.17 — Os três consertos do instrumento, implantados 2026-09-09

Registrado depois de medir; a decisão de §10.14 (encerrar em 2026-09-20, sem alargar
a janela) não muda. Isto não altera o ensaio: altera o que o **recibo** do vigilante
diz. Os três defeitos foram achados em 08-09/09 e todos são da mesma família — guarda
que fica calado por não ter o dado, em vez de dizer que não tem.

### O que motivou cada um

**(a) O recibo não dizia sobre qual corpus o replay correu.** Os 13 campos gravados
eram `absurdo, estado, folga, janela, motivo, n_janela, semantica, servido,
sha256_janela, tag, ts, via, w_servido` — nenhum de corpus. Consequência **medida** em
09/09: duas corridas com `sha256_janela` idêntico (`d5ba483d…`), `estados=672`
idêntico, mesmo epoch (`2026-09-08`, `arm=treatment`) e mesma janela produziram
vereditos **opostos** — GREEN `20/37/folga=0.5405` sobre o corpus que o serving tinha
aberto, RED `0/0` sobre `current.db`. Recibos indistinguíveis para resultados
contrários: o par não permitia decidir qual era o veredito do ensaio.

**(b) O cabeçalho do wrapper prometia uma aproximação declarada e nada a media.**
Texto vigente desde 27/08: *"`current.db` roda às 06:00Z, então um dia UTC inteiro
atravessa DOIS corpora e este replay usa um só. Medido em 27/08 … resultado IDÊNTICO —
a escolha de corpus foi inerte. **Inerte não é garantido**, e a aproximação fica em
cada linha do NDJSON em vez de silenciosa."* Ela **não** ficava em linha nenhuma, e
desde 03/09 17:30 deixara de ser inerte: o serving lê um inode já apagado do disco
(§10.10) enquanto o symlink seguiu relinkando. O conserto não muda a aproximação —
mede se ela vale, por dia, e grava o veredito.

**(c) `flock -n` no cron pula a rodada em silêncio.** A linha era
`flock -n /tmp/nox-p2-saturacao.lock run-saturacao.sh`. `flock -n` que não pega o lock
sai com código 1 e **corpo vazio**: nenhuma linha, nenhum recibo, `$STATUS` intacto com
o veredito da véspera. Cinco rodadas puladas (02, 03, 04, 07 e 08/09) das quais nada no
disco dá notícia — o morning report leu um veredito velho como se fosse do dia, cinco
vezes.

### O que passou a existir

| campo novo | conteúdo | onde |
|---|---|---|
| `corpus_path` | caminho **resolvido** (`readlink -f`) | NDJSON |
| `corpus_sha256` | sha256 dos **bytes**, não do caminho | NDJSON + linha de status (12 hex) |
| `serving_fd_sha256` | sha256 do que o serving tem aberto no `fd`, lido por `/proc/<pid>/fd/<n>` | NDJSON |
| `aproximacao_valida` | `sim` / `nao` / `indeterminada` | NDJSON + linha de status |

`sim` exige **bytes iguais**, não caminho igual: o corpus recuperado de 03/09 tem
caminho diferente do `fd` e é byte-idêntico a ele; e `current.db` é symlink que às
06:02 passa a apontar para outros bytes sem que arquivo nenhum mude de nome. Gravar o
caminho e chamar aquilo de proveniência é a lição
`a_commit_hash_is_not_a_stable_pin` na versão do corpus.

`indeterminada` quando não há serving vivo ou o `fd` não pode ser lido — **nunca**
`sim` por omissão. Um default otimista aqui reproduziria exatamente o silêncio que se
está consertando.

O lock passou do cron para dentro do `run-saturacao.sh` (`exec 9>`, `flock -n 9`; o fd
sobrevive ao `exec` final porque não tem `O_CLOEXEC`, então cobre a rodada inteira e
não só o preâmbulo). Consequência declarada: um skip **sobrescreve** `$STATUS` com
YELLOW, apagando o veredito da véspera. É deliberado — "a rodada de hoje não
aconteceu" é informação sobre hoje, e um GREEN de ontem apresentado como de hoje é
pior que um YELLOW que diz a verdade.

### Verificação

Suíte de 21 casos, **21/21** na VPS. Os 7 novos (T15–T21) exigem a **linha de status**,
não só o código de saída — é a linha que o morning report lê, e um campo que só
existisse no NDJSON deixaria o report tão cego quanto era. Teste de mutação, 4 mutantes,
todos confirmados aplicados (`cmp` antes de rodar) e todos mortos:

| mutante | casos que morreram |
|---|---|
| M1 `aproximacao_valida` fixa em `sim` | T19, T20 |
| M2 grava sha do **caminho** em vez dos bytes | T15, T17, T18, T21 |
| M3 campos só no NDJSON, fora do status | T15, T17, T18, T19, T20, T21 |
| M4 atalho sem os campos novos | T21 |

⚠️ Duas das minhas previsões de "quem morde" estavam erradas, e nos dois casos o
**teste** estava certo:

- previ que **T16** cairia em M2; não cai, e não deve — hash de caminho é *estável*
  para o mesmo caminho, e T16 é controle de **estabilidade**, não de bytes;
- previ **T19** em M2 e caiu **T18**. Sob M2 os dois shas nunca podem coincidir ⇒
  `aproximacao_valida` fica presa em `nao`, e T19 (que espera `nao`) **passa pelo
  motivo errado**. É para isso que T18 existe. T19 sozinho seria enganado por M2.

Registro as duas porque a lição é sobre o método: *prever qual caso morde é hipótese,
e a mutação a testa como testa o código.* Um mutante que mata os casos que eu previa
confirma menos que um que mata outros e me obriga a explicar por quê.

Verificação de (c) na VPS, com o lock segurado à mão: `rc=0`, `dur=0s`, e a linha
`YELLOW … motivo=rodada-anterior-ainda-em-execucao-lock=…` em stdout **e** em
`$STATUS`. O `$STATUS` de produção foi salvo antes e restaurado depois.

### Pinos

Duas eras do instrumento, com fronteira datada em **2026-09-09 ~12:20Z**. Leituras
anteriores a ela **não** têm proveniência de corpus, e essa ausência é fato do
instrumento, não do ensaio.

| arquivo | sha256 antes (16 hex) | sha256 depois (completo) |
|---|---|---|
| `gatilho-saturacao.sh` | `561d81a328f34c59` | `b08fc330edaa8c574d12fbadd44aebb935e13e5f32a150670007d34032ac0692` |
| `gatilho-saturacao.sh` **v2** | `b08fc330edaa8c57` | `f3dcfb1de659087df7f60aa87c0af227b16b13c2c2d678ecf33ab29ae2ddbd0f` |
| `run-saturacao.sh` | `b25a937137ff2c46` | `59c158a55f2f739c2dbf1ad85efdbe41a0b30843dfec40f47f6740f677cd2ffb` |
| `teste-gatilho-active.sh` | — (14 casos) | `3dccf80a1b59938f` (21 casos) → `7c184ca657c76df02f75ccb3f77f035665350d999a8aa8628508b3765f7b08ab` (25) |

⚠️ **Houve v2 no mesmo dia, ~40 min depois** — ver §10.18. A tabela acima é a v1; as
leituras entre ~12:20Z e ~12:55Z saíram do gatilho v1, que tem `serving_fd_sha256`
singular e não tem a perna do corpus ilegível.

Cópias das versões substituídas em `/var/backups/nox-mem/p2-scripts/`. Crontab: saiu o
`flock -n` externo, uma linha alterada, contagem de linhas conferida antes de instalar.

### Primeira leitura de produção com os campos novos

O estado que (b) passou a enxergar, medido no momento da implantação:

```
fd=26 -> /var/lib/nox-mem/epochs/e20260903T060001Z.db
sha do fd      : 23378a9ea83cd27d0360cfe148207167aee30a376f29ef89d4bcfae415d04131
sha current.db : 084bef6c441cbcbf67b120884644cdbc9880100adc52744b4451293456f10586
```

⇒ `aproximacao_valida=nao`. Divergentes desde 03/09 17:30, seis dias antes de existir
qualquer campo capaz de dizer isso.


---

## §10.18 — A revisão da sessão par: 3 mutantes sobreviventes, 1 deles defeito

Quarenta minutos depois do deploy de §10.17 pedi à sessão par um terceiro mutante que
os 7 casos novos não matassem. Ela achou **três**, por análise estática do fonte
implantado mais duas medições na VPS, e declarou não ter rodado nenhum. **Rodei os
três: os três sobrevivem** — 21/21 com cada mutante aplicado.

### M6 não era mutante sobrevivente: era defeito

Corpus ilegível (`sha256sum` falha ⇒ `CORPUS_SHA="nao-calculado"`) com serving **vivo**
caía no `else` final:

| | valor |
|---|---|
| `CORPUS_SHA` | `nao-calculado` |
| `SERV_SHA` | hash real |
| 1ª perna (`=`) | falsa |
| 2ª (`sem-pid`/`fd-nao-lido`) | **falsa** |
| ⇒ | **`APROX="nao"`** |

O recibo **afirmava divergência sem ter lido um dos dois operandos**. Não é o silêncio
da regra 9 do CLAUDE.md — é o agravante dela: **afirmação positiva sobre dado
ausente**, no campo exato que o morning report lê. E o cenário é banal, não exótico:
`current.db` relinkado às 06:02 para arquivo ainda não criado ⇒ `readlink -f` devolve
caminho, `sha256sum` falha. O replay também falha e sai RED `replay-falhou`, mas o
recibo sobrevive à análise com um `nao` infundado.

Corrigido com uma terceira perna **antes** das outras duas, simétrica à regra do
serving: *sem corpus lido dá `indeterminada`, nunca `nao`* — como *sem serving vivo dá
`indeterminada`, nunca `sim`*.

### M5: a escolha de fd era arbitrária, e o cenário de N fds já aconteceu

`head -1` sobre `ls -l /proc/PID/fd`. Dois fatos medidos na VPS:

- `ls` ali ordena **lexicograficamente**: `0 1 10 11 12 13` — o `10` vem antes do `2`.
  Com os fds 26 e 9 abertos, `head -1` pega o **26**. "O primeiro" não é o menor fd;
  é acidente de ordenação, e não estava declarado em lugar nenhum.
- hoje há **1** fd casando o prefixo, mas foi exatamente o acúmulo de snapshot por
  epoch sem fechar o velho que produziu o §10.10. Um serving nesse estado tem N.

Um `serving_fd_sha256` **singular** sobre N fds seria número certo atribuído a
população errada. A perna passou a coletar **todos**, ordenados numericamente, e a
aproximação vale se o corpus está **entre** os abertos:
`serving_fd_sha256s` (lista) + `serving_fd_n` (no NDJSON **e** na linha de status — a
contagem é a assinatura do §10.10, e quem lê o report tem de vê-la). O `head`/`tail`
deixou de existir em vez de ser escolhido certo.

### M7: `\.db` não é decoração

`[^ ]+` é guloso, então casa `…/e2026….db` com ou sem o sufixo — o mutante era
indistinguível em qualquer fixture que só tivesse `.db` aberto. Mas
`/var/lib/nox-mem/epochs/` tem **4 `.db` e 17 `.json`** (manifests): sem o sufixo, um
manifest aberto pelo serving entraria na comparação e a perna reportaria divergência
por comparar coisas de tipos diferentes.

### E um defeito meu, achado ao reescrever a perna

Troquei `grep -oE` por `sed -nE` com `$` ancorado logo depois de `\.db` — o que
**excluiria exatamente o fd que a perna existe para enxergar**: desde 03/09 17:30 o
que o serving mantém aberto é um inode apagado, e `ls -l` o anota
`-> …e20260903T060001Z.db (deleted)`. A versão com `grep -oE` não ancorava e por isso
não tinha o problema. **Trocar de ferramenta trouxe de volta um defeito que não
existia**, e ele só apareceu porque escrevi a fixture com um fd deletado de verdade.

### Verificação da v2

**25/25.** Seis mutantes, cada um morrendo no caso desenhado para ele:

| mutante | morre em |
|---|---|
| M5 escolhe **um** fd em vez de todos | T23 |
| M6 sem a perna do corpus ilegível | T25 |
| M7 sem o sufixo `\.db` | T24 |
| M8 `$` ancorado sem aceitar ` (deleted)` | T22 |
| M9 `serving_fd_n` fora da linha de status | T23, T24 |
| M10 `sim` sem o corpus estar na lista | T19 |

⚠️ **A primeira aplicação do M8 não era o mutante pretendido.** Troquei `\$#` por
`$#` e o shell expandiu `$#` dentro das aspas duplas, destruindo o regex inteiro —
morreram T18, T19, T22, T23 e T24, e eu quase registrei isso como "o mutante mata cinco
casos". Refeito mantendo o `$` escapado, mata **só T22**, que é a perna que ele ataca.
É a lição `a-mutation-test-can-pass-while-verifying-nothing` na direção oposta: o
mutante **falhou** verificando outra coisa. Conferir o `diff` do regex antes de rodar é
o que separou os dois casos.

### O que a perna passou a dizer sobre o RED de hoje

Primeira corrida real com proveniência (status e NDJSON em `/var/tmp`, sem tocar no
ensaio), sobre o epoch `2026-09-08`, `arm=treatment`:

```
estado             RED  (canal-sem-capacidade)
corpus             e20260909T060001Z.db
corpus_sha256      084bef6c441cbcbf67b120884644cdbc9880100adc52744b4451293456f10586
serving_fd_sha256  23378a9ea83cd27d0360cfe148207167aee30a376f29ef89d4bcfae415d04131
aproximacao_valida nao
servido            w=2      estados=672  mexeu=0  churn_total=0  boosts=19
absurdo            w=100000 estados=672  mexeu=0  churn_total=0  boosts=19
```

⇒ o RED de 09/09 foi computado sobre um corpus que o serving **não** tem aberto, e
agora o próprio recibo diz isso. É o artefato de §10.13(A), passando de inferência
reconstruída a campo gravado.


---

## §10.19 — Por que a perna (b) compara BYTES: o SQLite não abre banco por `/proc/PID/fd/N`

A sessão par mediu isto ao construir o guarda de coorte (PR #484, não implantado), e eu
reproduzi de forma independente com fixture de arquivo apagado de verdade. Não é
preferência de implementação: é a única via que funciona.

| via | resultado |
|---|---|
| `sha256sum /proc/PID/fd/N` | **lê** os bytes do inode apagado |
| `sqlite3 "file:/proc/PID/fd/N?mode=ro"` | `unable to open database file` |
| `sqlite3 "file:…?mode=ro&immutable=1"` | `unable to open database file` |
| `sqlite3 /proc/PID/fd/N` (caminho simples) | **abre**, e apresenta banco **VAZIO** |
| `cat /proc/PID/fd/N > copia.db` e abrir a cópia | lê tudo (controle positivo) |

⇒ o **conteúdo** do corpus servido é inalcançável por query enquanto ele existir só no
`fd`; só copiando 1,2 GB. Comparar hashes é o que dá para fazer, e agora com motivo
medido.

### O caso perigoso é o quarto, não os dois erros

`file:…?mode=ro` falha **alto** — não há ambiguidade. O caminho **simples** abre com
sucesso e reporta `sqlite_master = 0 objetos`: um banco vazio, silenciosamente. Uma
consulta subsequente só falha porque a tabela esperada não existe (`no such table:
chunks`) — isto é, o alarme vem da **sorte**, não do desenho. Um probe escrito como
`SELECT count(*) FROM sqlite_master` ou `CREATE TABLE IF NOT EXISTS` passaria calado.

⚠️ **A frase abaixo, publicada às ~13:10Z, está ERRADA e fica à vista** — a
atribuição causal é minha e caiu no mesmo dia. Correção medida no fim desta seção: não
é a escrita, é o **`connect()` sozinho**.

~~E uma **escrita** através dele cria arquivo de verdade no disco~~, com nome igual ao
**texto do symlink** — incluindo o sufixo:

```
$ exec 3< real.db; rm real.db
$ python3 -c "import sqlite3;c=sqlite3.connect('/proc/$$/fd/3');c.execute('CREATE TABLE intruso(x)');c.commit()"
$ ls -A
'real.db (deleted)'      ← 8192 bytes, banco SQLite válido, tabela `intruso`
```

Em produção isso criaria, no diretório do ensaio,
`/var/lib/nox-mem/epochs/e20260903T060001Z.db (deleted)`. Conferido: **não existe
nenhum arquivo com `(deleted)` no nome em `/var/lib/nox-mem/epochs/`** — nada foi criado
lá; todas as fixtures rodaram em `/var/tmp` e foram removidas.

### Uma ambiguidade que isto revela no meu próprio filtro

Um arquivo **real** chamado `X.db (deleted)` e o **inode apagado** de `X.db` produzem a
**mesma linha** em `ls -l /proc/PID/fd`, e o meu `sed` os captura idênticos:

```
26 -> /var/lib/nox-mem/epochs/e20260903T060001Z.db (deleted)   → captura "…e2026….db"
```

Hoje isso é remoto (o arquivo teria de existir *e* estar aberto pelo serving), mas o
caminho para criá-lo é exatamente o descrito acima. Registrado como limitação conhecida
do filtro; distinguir exigiria `stat` do `fd` contra `nlink == 0`.

### E dois erros meus de observação, no mesmo achado

Medi o arquivo aparecer, e então "não consegui reproduzir" duas vezes seguidas — as três
corridas eram consistentes e o método de observação é que mudou:

1. `ls -la | awk '{print $5, $9}'` imprimiu `8192 real.db`: o campo 9 é `real.db` e o
   ` (deleted)` está nos campos 10-11, **cortado**. Número certo, nome errado.
2. Nas duas verificações seguintes procurei por `stat alvo.db` / `ls alvo.db` — o nome
   que eu tinha lido, não o nome real. Ausência do arquivo errado lida como ausência do
   efeito.

É a família `a-correct-number-carried-by-a-wrong-sentence` duas vezes em quinze minutos,
e a segunda foi **causada** pela primeira: ler o nome truncado me deu o predicado errado
para a verificação. Só ficou visível ao imprimir o diretório inteiro (`ls -A`) em vez de
perguntar por um nome.

⚠️ **Consequência de método:** verificar a ausência de um efeito colateral perguntando
pelo nome que se espera é o mesmo defeito de guarda cujo predicado exige o dado que
falta. Listar o diretório e comparar com o estado anterior — não interrogar um nome.


### ⚠️ Correção da mesma tarde: é o `connect()`, não a escrita

Medido com fixture válida, isolando as três etapas contra o **mesmo** fd deletado,
limpando o diretório entre elas:

| etapa | exceção | listagem do diretório depois |
|---|---|---|
| `sqlite3.connect("file:…?mode=ro", uri=True)` | `unable to open database file` | `[]` |
| `sqlite3.connect(p)` — **só isso, nenhuma query** | nenhuma | **`[x.db (deleted)]`** |
| `sqlite3.connect(p)` + `SELECT` | `no such table: chunks` | `[x.db (deleted)]` |

⇒ **o `connect()` simples materializa o arquivo por si**, porque o modo padrão de
abertura é read-write-**create**. Não precisa de `INSERT`, `CREATE` nem `commit`.

**Isto eleva a severidade.** A frase corrigida acima dizia que era preciso escrever; a
sessão par disse o mesmo com outras palavras ("nasce na escrita, não no `connect()`") e
concluiu que uma asserção de listagem não mataria o mutante do guarda dela, porque o
guarda só lê. **Errado nos dois lados:** um guarda estritamente read-only que use o
caminho simples cria arquivo no diretório do ensaio só por abrir. Medido na suíte dela:
sob o mutante `ro()` → `connect(p)` morrem **T13b, T13c e T13d** — as três, não só a do
modo de abertura.

### Como o erro sobreviveu a duas verificações

A corrida que eu tratei como isolamento definitivo — a que concluiu "nem a escrita cria"
— conferiu o efeito com `stat alvo.db`. **O nome real é `alvo.db (deleted)`.** É o mesmo
defeito de observação que eu havia acabado de documentar duas células antes, aplicado
justamente no teste desenhado para dirimir a causa; e as duas etapas do isolamento
usaram o predicado errado, então concordaram entre si. Concordância entre duas medições
que compartilham a premissa defeituosa não é confirmação — é o mesmo erro contado duas
vezes.

⇒ terceira ocorrência do dia da mesma família, e a mais instrutiva: **documentar a lição
não impede reaplicar o defeito**, porque o que falha é o reflexo de escrever
`stat <nome>`, não o conhecimento. O que quebrou o ciclo foi imprimir a listagem
(`ls -A`) — a única consulta que responde "apareceu algo?" sem precisar acertar o nome.

---

## §10.20 — v3: o hash lia o resultado do `readlink`, não o argumento

A sessão par achou, na saída do teste do próprio mutante, que a perna 1 do guarda dela
imprimia `corpus=$(basename "$CORPUS")` — para `/proc/PID/fd/3` isso sai `corpus=3`, o
número do fd, num guarda cujo objeto é proveniência. Fui medir se o meu instrumento
tinha a mesma cara, pela regra de que classe de defeito não fica consertada onde foi
achada. **Não tinha essa, tinha outra:**

```
argumento           /proc/2372055/fd/3
readlink -f devolve /var/tmp/bn/d/orig.db (deleted)     ← o nome ORIGINAL, com sufixo
basename disso      orig.db (deleted)                   ← rótulo informativo, ok
sha256 do argumento 529bb8c2700a38be…                   ← legível
sha256 do readlink  <FALHOU>                            ← o caminho não existe
```

O código hasheava `$CORPUS_REAL`, isto é o resultado do `readlink`. Para um fd deletado
esse caminho **não existe**, então `CORPUS_SHA` saía `nao-calculado` — e a leitura
degradava a `aproximacao_valida=indeterminada` num caso em que o dado estava
**disponível**. Não é perigoso (graças à perna de §10.18 dizer `indeterminada` e não
`nao`), mas é leitura pior que a possível, no caso exato que o instrumento existe para
cobrir.

Corrigido: **o rótulo vem do `readlink`, o hash vem do argumento.** Para `current.db`
(symlink comum) os dois coincidem, e T17 é esse controle. Se o argumento resolve, ler
dele lê o alvo — hashear o argumento é estritamente melhor, nunca pior.

**26/26.** Mutação M11 (voltar a hashear `$CORPUS_REAL`) mata **só T26**.

Latente, não vivo: `run-saturacao.sh` passa `--corpus /var/lib/nox-mem/epochs/current.db`,
symlink para arquivo real, nunca um caminho `/proc`. Nenhuma leitura publicada foi
afetada.

| arquivo | v2 | v3 |
|---|---|---|
| `gatilho-saturacao.sh` | `f3dcfb1de659087d` | `754e3eb939c27c3f9e8b3f696180c055a2003371cd5a7e672a859722dfcebe4e` |
| `teste-gatilho-active.sh` | `7c184ca657c76df0` | `72b6188d19400e01eede77dc0c3900d852bd362beaa41755b0ac48dd41ecbff8` |


### Premissa da correção, medida (não raciocinada)

Eu havia justificado a v3 com *"se o argumento resolve, ler dele lê o alvo"* — afirmação
por raciocínio. Medida:

| entrada | `sha256sum` | `readlink -f` |
|---|---|---|
| arquivo | `a11ee0f7407d82f9` | o próprio caminho |
| symlink para ele | **mesmo hash** | o alvo |
| symlink para symlink | **mesmo hash** | o alvo final |
| symlink pendurado | `No such file or directory` | o alvo pretendido, ausente |

⇒ `sha256sum` **segue** symlink, inclusive em cadeia; hashear o argumento nunca é pior
que hashear o alvo resolvido, e para `current.db` os dois coincidem (T17). O symlink
pendurado é o caminho de T25 (`nao-calculado` ⇒ `indeterminada`), consistente.

Nada a acrescentar ao recibo: o rótulo do nome original já está lá — `corpus=` na linha
de status é o `basename` do `readlink`, e `corpus_path` no NDJSON é o caminho resolvido
inteiro. Para fd deletado é onde o nome original aparece.


### E o cenário que o symlink pendurado NÃO cobre

A sessão par propôs registrar que a correção também cobriria a janela de relink diária,
porque *"na janela entre o relink e o arquivo novo existir, `current.db` é exatamente um
symlink pendurado"* — e que esse caso é muito mais provável que o do fd deletado. **Fui
ver a rotação antes de escrever, e a premissa não se sustenta.**

`nox-epoch-boundary.sh`, ordem literal das chamadas: `snapshotForEpoch` (linha 31) →
`pointCurrentTo` (37) → `pruneEpochs` (38). E `pointCurrentTo`
(`src/lib/epoch-snapshot.ts:209`) faz, nesta ordem:

```ts
if (!existsSync(alvo)) throw new Error(`… recusando apontar current`);   // 212
const man = readEpochManifest(epochId, dir);
if (!man || man.integrityCheck !== "ok") throw new Error(`… mantendo o current anterior`);
symlinkSync(basename(alvo), tmp);
renameSync(tmp, link);   // atômico
```

⇒ o alvo tem de **existir** e passar o **integrity check** antes de o link se mover, e o
movimento é um `rename` **atômico**. Conferido também que **nenhum outro** script ou
fonte faz `ln -s`, `rm -f`, `unlink` ou `symlink` sobre `current.db` — `pointCurrentTo`
é o único escritor. **Não existe janela em que `current.db` esteja pendurado.**

A perna do symlink pendurado (T25 ⇒ `nao-calculado` ⇒ `indeterminada`) segue legítima
como defesa, mas o que a justifica é o caso do fd, não o relink. A janela real que a
intuição dela tateava é outra e já está documentada: um leitor que mantenha o `fd`
aberto **através** do `rename` — §10.10, exatamente o que a produção vive desde 03/09.

**Verificado nos dois artefatos, independentemente:** eu li `src/lib/epoch-snapshot.ts`,
a sessão par leu `dist/lib/epoch-snapshot.js` — o que a produção realmente executa —, e
os dois concordam (`existsSync` lança em :168-170, o integrity check em :171-174,
`symlinkSync` + `renameSync` em :182-183; o `rmSync` toca só o nome **tmp**, nunca o
link). O par vale mais que qualquer das duas leituras: `src` diz a intenção, `dist` diz o
que corre, e a lição
`what-production-runs-proves-what-runs-not-which-version-is-correct` é sobre exatamente a
possibilidade de divergirem.

### A simetria que isto fecha

**O mesmo `rename` atômico que impede o symlink pendurado é o que cria o inode órfão.**
A troca de nome não toca no inode antigo — é daí que vem a garantia de que o link nunca
aponta para nada, e é daí que vem o fd que segue servindo bytes de um arquivo já podado
(§10.10). A propriedade que dá a garantia é a que produz o hazard, e não há como ter uma
sem a outra: um relink que apagasse o inode antigo eliminaria o órfão e introduziria a
janela pendurada, além de matar leitores no meio da leitura.

⇒ o §10.10 não é defeito da rotação. É o preço da atomicidade dela, e o que faltava era
**enxergá-lo** — que é o que a perna (b) passou a fazer.

⚠️ Sexta afirmação plausível do dia — de uma de nós — derrubada por **uma** consulta ao
código, e esta ia entrar no registro como fato operacional. Nenhuma das seis veio de
concordância; todas de alguém rodar a consulta em vez de aceitar a frase.


---

## §10.21 — O corpus servido não tinha cópia em disco (2026-09-09 15:25Z)

Achado ao verificar a premissa de uma pergunta da sessão par — ela queria apontar o
wrapper do guarda de coorte para "o corpus recuperado de 03/09". Fui ver onde esse
arquivo vivia.

> ⛔ **ERRATA (2026-09-09 14:53Z) — AS DUAS FRASES ABAIXO SÃO FALSAS.** Ficam à vista,
> tachadas, com o mecanismo do erro. Ver *Errata* no fim desta seção.

~~**Varredura por sha256 em todo o disco** (`find / -xdev -type f -size +500M`, comparando
cada um): **zero** arquivos com `23378a9e…`. O corpus que o ensaio serve desde 03/09
17:30 existia **exclusivamente** como o inode apagado mantido pelo `fd 26` do pid 546151.~~

⇒ Qualquer restart do `nox-mem-api` — deploy, OOM, `systemctl` de outra sessão, reboot —
destruiria permanentemente **o corpus sobre o qual todos os vereditos do ensaio foram
computados**. E o §10.19 estabelece que o conteúdo era inalcançável por SQL enquanto
estivesse só no `fd`: a única via era `cat`.

Cópia feita antes de qualquer discussão, porque a discussão não sobrevive à perda:

```
/var/backups/nox-mem/p2-corpus-servido/servido-e20260903T060001Z.db
sha256  23378a9ea83cd27d0360cfe148207167aee30a376f29ef89d4bcfae415d04131   (== fd 26)
1,2G · modo 0400 · 67.187 chunks · abre por SQL
```

Localização escolhida por exclusão: **não** em `/var/lib/nox-mem/epochs/` (o
`pruneEpochs(3)` a apagaria como se fosse epoch velho) e **não** em `/var/tmp` (limpeza
periódica). Ler `/proc/PID/fd/26` não perturba o serving. 26G livres depois.

### O que isto destrava e o que denuncia

**Destrava:** o corpus do ensaio passa a ser **auditável** — 67.187 chunks consultáveis
por SQL contra os 19 designados, o que era impossível ontem. Toda análise que dependia de
"o corpus servido" e só podia usar `current.db` como proxy agora tem o objeto real.

**Denuncia:** um número já publicado ficou sem lastro. A sessão par reportou
`recuperado (bytes == fd): GREEN canal-alcancavel pool=108 nunca_servidos=0` — medição
que exige SQL, sobre um arquivo que **não existia** no disco quando eu varri. Ou havia
cópia temporária já removida, ou o número veio de outra fonte. Perguntado a ela; até a
resposta, `pool=108` é **não-reproduzível**, e é justificativa do PR #484.

~~⚠️ **A lição operacional:** … Passaram-se **32 h** entre saber disso e alguém
copiar.~~ ⛔ **TAMBÉM FALSO** — a cópia foi feita em 08/09 15:01:05Z, no mesmo dia da
descoberta. Quem não sabia dela era eu.

### Errata (2026-09-09 14:53Z): o arquivo existia, e o defeito é a varredura

A sessão par apontou, e verifiquei:

```
-rw-r--r-- 1 root root 1254526976 Sep  8 15:01 /var/lib/nox-mem/p2/corpus-SERVING-REAL-e20260903-recuperado.db
mtime = 2026-09-08 15:01:05.803665541 +0000   fs = /   sha = 23378a9ea83cd27d…
```

**24 h antes da minha varredura, no mesmo filesystem, mesmo sha, mesmo tamanho.** As
três frases tachadas acima são falsas.

**Por que a varredura não o viu — e é pior que o erro:** o pipeline
`find / -xdev … | while read … sha256sum` leva **mais que os 120 s** do timeout da
ferramenta. Ele foi mandado para segundo plano, o arquivo de saída tinha **só a linha de
cabeçalho** quando eu o li, e eu tratei a ausência de linhas `ACHADO` como **negativa
concluída**. A tarefa depois reportou `exit 0` e eu nunca reli.

Rodada de novo, agora **contando o que examina**:

```
  ACHADO: /var/backups/nox-mem/p2-corpus-servido/servido-e20260903T060001Z.db
  ACHADO: /var/lib/nox-mem/p2/corpus-SERVING-REAL-e20260903-recuperado.db
  arquivos examinados: 31   com o sha alvo: 2
```

⇒ a mesma varredura, **quando termina**, acha os dois. A minha não tinha **contador** nem
**controle positivo**, então *"examinei 0 arquivos e não achei"* e *"examinei todos e não
achei"* produziam **saída idêntica**. É a formulação da par, e ela generaliza:

> **Varredura que conclui ausência precisa de controle positivo** — um arquivo que ela
> **deveria** achar. Sem isso, "não achei" e "não procurei onde estava" são
> indistinguíveis pela saída.

E é a minha própria família do dia inteiro, agora aplicada ao meu instrumento de
verificação: ausência de dado lida como dado sobre ausência. A diferença é que esta
entrou no registro do paper como **afirmação positiva**, que é a versão agravada (§10.18).

### O que a errata NÃO derruba

**A cópia continua justificada, e a par concorda:** `/var/lib/nox-mem/p2/` não é lugar
protegido — não tem modo restritivo, está no caminho de scripts do p2, e nada garante que
sobreviva a limpeza. Uma segunda cópia `0400`, fora do escopo do `pruneEpochs(3)` e fora
de `/var/tmp`, é estritamente melhor. O que precisava de errata é a **afirmação**, não a
decisão.

### E uma retratação que eu devo à sessão par

Com base nessa varredura eu escrevi que o `pool=108 nunca_servidos=0` dela estava
*"sem lastro"* e *"não-reproduzível"*, e perguntei de onde teria saído. **Retiro.** Ele
vinha de `--corpus /var/lib/nox-mem/p2/corpus-SERVING-REAL-e20260903-recuperado.db`, que
estava no disco o tempo todo. Pus em dúvida a evidência dela com base numa medição que
**nunca rodou** — e a assimetria importa: eu tinha o ônus, porque a afirmação negativa
era minha.

---

## §10.22 — Desfecho: decisão explícita, janela elegível e o desligamento armado

### A decisão, literal

Toto, 2026-09-09 14:38 BRT:

> **"encerra 20/09 mesmo, e desliga a dose depois"**

É a **primeira instrução explícita** sobre o desfecho. O que existia antes era o §10.14,
que funda a reversão numa **medição** e cita uma pergunta retórica dele
(*"prolonga ne? melhor nao acha?"*) — registro honesto de uma inferência, não de uma
ordem. As duas coisas agora existem separadas, e o §10.14 permanece como o que era.

O segundo membro (*"desliga a dose depois"*) é item novo: eu o havia formulado como
pergunta em aberto porque **muda o que os 6 agentes recebem** e nenhuma leitura dos
registros anteriores o cobria.

### A janela elegível — as duas pontas são epochs PARCIAIS

Computada em `measurement/janela-elegivel.py`, artefato em
`measurement/out/JANELA-ELEGIVEL-2026-09-09.json` (⚠️ o caminho dizia `out/…` até
2026-09-21; o ficheiro sempre esteve em `measurement/out/`, e a `auditoria-da-cadeia`
acusava-o como **inexistente** — que é o diagnóstico errado para um ponteiro partido). Premissas todas **medidas**, não presumidas:

| premissa | valor | fonte |
|---|---|---|
| primeira linha `p2_outcome` em `active` | `2026-09-01T10:37:01.943Z` | `p2-serving.ndjson` |
| `created_at` dos 19 designados | `2026-08-21 22:51:23`, **idêntico nos 19** | corpus servido preservado |
| janela do sub-pool global | 30 d, relógio de **request** | `dist/api/brief.js:470` |
| expiração | **`2026-09-20 22:51:23Z`** | `created_at + 30d`, computado no corpus |
| fronteira de epoch | `09:00Z` | `epochInicioISO`, `brief-outcome.ts` |

| classe | epochs | observação |
|---|---:|---|
| **inteiros** | **18** | `2026-09-02` … `2026-09-19` |
| parcial inicial | 1 | `2026-09-01`: **22,38 h de 24** (93,26%) — o active entrou 1h37m depois da fronteira |
| parcial final | 1 | `2026-09-20`: **13,86 h de 24** (57,74%) — os designados expiram 13h51m dentro do epoch |
| total | **20** | de **234** pré-registrados = **8,5%** |

⚠️ Os dois parciais ficam registrados **separadamente**, não arredondados para dentro
nem para fora. Um epoch de exposição **mista** — alvo alcançável em parte dele — não é o
mesmo objeto que um de exposição uniforme, e fundir os dois é a família do número certo
atribuído à população errada. Quem analisar decide se os usa; o que não pode é não saber
que são diferentes.

### O desligamento

Armado, não executado: `43 9 21 9 *` UTC (a VPS roda `Etc/UTC`, medido — não presumido),
isto é **2026-09-21 09:43Z**. Script em
`measurement/implantacao/desliga-dose-p2.sh`, instalado em
`/root/.openclaw/scripts/p2/`, sha `9830e743b3d946b4`.

**O procedimento não é invenção minha:** está escrito no próprio `zz-p2-active.conf`,
seção *Rollback* — *"rm this file, systemctl daemon-reload, restart nox-mem-api. Effect:
NOX_P2_OUTCOME falls back to shadow (p2s2-shadow.conf), no brief gets treatment, and
everything already served stays on the record."* Duas diferenças deliberadas: **move em
vez de apagar** (o drop-in é o registro do que foi armado; apagá-lo apaga a prova) e
pré-condições com recibo.

**Por que 09:43Z e não meia-noite,** e por que depois e não antes da saturação:

- o mesmo drop-in avisa que a fronteira é 09:00Z e que reiniciar antes dela resolve o
  epoch do dia **anterior**. O epoch de 09-20 fecha em 09-21 09:00Z;
- a saturação de 09-21 corre às 09:12Z e levou **927 s** medidos — ela reporta o último
  epoch parcial e precisa do estado do ensaio **intacto**. Desligar antes dela mediria a
  janela de ontem com a dose de hoje.

**Pré-condições, cada uma com recibo em `$STATUS` e no NDJSON:**

| perna | aborta se | por quê |
|---|---|---|
| 1 | a janela ainda está aberta | desligamento antecipado **trunca** epoch elegível — dano irreversível, pior que atraso |
| 2 | o drop-in já saiu, ou `OUTCOME != active` | idempotência: o one-shot dispara todo 21/09 |
| 3 | a cópia do corpus servido falta ou tem sha divergente | **o restart derruba o fd**, e até 09/09 15:25Z ele era a única cópia (§10.21) |
| 4 | `mv`, `daemon-reload` ou `restart` falham | o recibo diz onde o drop-in ficou |
| 5 | o `OUTCOME` não caiu para `shadow`, ou a API não responde | *conferir o efeito, não presumi-lo* — `systemctl is-active` já conviveu com drop-in silenciosamente desabilitado (lição de 19/08, no próprio drop-in) |

**Verificado a seco, hoje, sem tocar em nada:** rodar agora dá
`YELLOW … motivo=janela-ainda-aberta-faltam-279h`, com o drop-in no lugar e
`OUTCOME=active` intactos. Duas mutações: cópia do corpus ausente ⇒ `RED
corpus-servido-sem-copia-ABORTANDO-restart` **com o drop-in preservado**; `OUTCOME` já
`shadow` ⇒ `GREEN ja-desligado`. O `$STATUS` de produção foi salvo e restaurado.

`NOX_P2_SHADOW_W=2.0` já vem de `p2s2-shadow.conf`, logo o guarda de saturação segue
funcionando depois da troca — sem RED crônico por variável ausente.

### ⚠️ Pendência que o desligamento NÃO resolve

Depois de 2026-09-21 há **cinco** guardas de cron reportando sobre um ensaio encerrado, e
**três** deles já estão cronicamente vermelhos (`composicao` com `agent_fresh=285`,
`corpus-alinhado` com o fd, e `designados` que passará a 0/19 **por desenho**, porque
expiraram). Alarme perpetuamente vermelho sobre pergunta encerrada é o que ensina a
ignorar alarme — e é o defeito que o §10.17 inteiro tratou. Aposentar ou reformular os
cinco é decisão separada, não coberta por *"faz os 3"*.


---

## §10.23 — Aposentadoria dos guardas, acoplada ao desligamento

Toto, 2026-09-09 14:46 BRT: **"aposenta os guardas junto no 21"**. Implementado dentro do
`desliga-dose-p2.sh`, condicionado ao desligamento ter dado GREEN.

### Por que não é só tirar linhas do cron

O `morning-report.sh` chama `p2_gatilho <rótulo> <status> <idade_max_h>` por guarda, e
essa função dá **YELLOW** quando o arquivo de status falta (`sem status`) ou envelheceu
além do teto (`gatilho parado?`). Parar os crons sem tocar no report trocaria **três REDs
crônicos por seis YELLOWs crônicos** — ruído por ruído, com o propósito invertido.
Verificado: com o report editado a saída volta a `all green`, com uma linha `⚪`
informativa.

**As seis chamadas ficam comentadas, não apagadas**, com marca datada
(`#APOSENTADO-2026-09-21 …`). Duas razões: o bloco de *regra do teto de idade* logo acima
referencia cada guarda pelo nome e a calibragem se perderia; e silêncio sobre algo que era
vigiado e deixou de ser é o defeito que custou seis dias no §10.10. A ausência **aparece**,
sem contar como RED nem YELLOW.

### A ordem foi escolhida por qual falha é menos pior

| ordem | falha deixa | veredito |
|---|---|---|
| report → cron | guardas rodando e o report **afirmando** que foram aposentados | silencioso e **falso** |
| **cron → report** | o report reclamando de guarda parado | ruidoso e **honesto** |

Escolhida a segunda. E o arquivo novo é **pré-gerado e conferido hoje**, guardado em
`/root/.openclaw/paper2/aposentadoria/` (**não** em `/var/tmp`, que some em 11 dias), de
modo que o único passo restante em 21/09 é um `install`.

### Pré-condição que protege terceiros

`REPORT_SHA_ESPERADO` está pinado. Se alguém editar o `morning-report.sh` entre hoje e
21/09, instalar a minha versão **apagaria a edição dessa pessoa** — então a aposentadoria
inteira aborta e os guardas ficam. ⚠️ Consequência a comunicar: **qualquer edição do
report antes de 21/09 exige regerar a versão staged**, senão o recibo sai
`YELLOW dose-desligada-mas-guardas-NAO-aposentados`.

### Verificação em sandbox, sem tocar produção

Variante gerada por **substituição exata em Python, não `sed`** — o delimitador `#`
colide com o literal `# p2-` no próprio script, e a primeira tentativa quebrou em
silêncio produzindo um "teste" que não exercitava a função. As 17 âncoras são conferidas
por contagem (`==1`) antes de aplicar; âncora que não casa aborta a geração.

| caso | resultado |
|---|---|
| caminho feliz | `GREEN`, cron p2 **7 → 0**, total 63 → 56, report instalado com o sha certo, drop-in movido |
| report divergiu | `YELLOW dose-desligada-mas-guardas-NAO-aposentados`, e **o cron não foi tocado** |
| zero linhas p2 no cron | `GREEN`, `guardas=0 cron-linhas=56->56`, report instalado |
| em produção, hoje | `YELLOW janela-ainda-aberta-faltam-278h`, com cron/report/drop-in/outcome **intactos** |

### Dois defeitos que o sandbox achou e a leitura não

1. **`recibo()` descartava `$3+`.** A linha saía só com `motivo=`, e `outcome=`,
   `dropin-arquivado-em=` e o resumo da aposentadoria (`guardas=`, `cron-linhas=`,
   `report-instalado=`, `backup=`) **desapareciam**. É o defeito que o §10.17 inteiro
   tratou — recibo sem o que foi medido — reaparecendo no script escrito **depois** dele.
2. **`nenhuma-linha-p2-no-cron` abortava.** Zero linhas não é erro: é a parte do cron já
   feita, e o report podia continuar precisando de edição. O recibo dizia
   *"guardas NÃO aposentados"* sobre guardas que já não existiam — veredito certo pelo
   motivo errado.

Nenhum dos dois apareceria por leitura: os dois são sobre o que o script **produz**. É a
terceira via da tabela do §10.19, agora aplicada por mim ao meu próprio script.

### O `p2-coorte` sai da conta por outro caminho

A sessão par implantou o #484 no meio disto (7 linhas p2 no cron, 6ª chamada no report) e
lhe deu uma perna própria: `[ "$OUT" = active ] || morre GREEN
ensaio-encerrado-dose-desligada`. Sem ela, o desligamento das 09:43Z deixaria o guarda
dela `RED corpus-nao-e-o-servido` **a cada hora, para sempre**. A aposentadoria remove a
linha do cron de todo modo — a perna dela é a segunda camada, não a redundante: se
alguém rearmar o cron depois, ela ainda cala o alarme.

O padrão vale para os outros e fica registrado como precedente implantado: **GREEN cujo
motivo diz "a pergunta não se aplica mais"** — nem silêncio, nem vermelho.

`desliga-dose-p2.sh` sha `5179ea30c605b36e3e299a6c7e69fe2b026f37e2fd11278c0f740cda03a3e97f`.


---

## §10.24 — O censo que o corolário obriga: a classe está viva em dois outros sítios

A sessão par formulou o corolário que fecha as duas ocorrências independentes do §10.17
(o recibo dela de 4 chaves e o meu `recibo()` descartando `$3+`, ambos em código escrito
**depois** do §10.17):

> A correção é **local por construção**. O que generaliza não é o conserto — é o
> **hábito de conferir a saída**. Ao fechar defeito de classe, a última ação não é o
> commit do fix: é o **censo dos outros sítios da mesma forma**. Sem o censo, o fix é
> verdadeiro e a frase *"está resolvido"* é falsa.

Registrar isso sem **rodar** o censo seria o próprio defeito, então rodei. Sete wrappers
do p2 anexam ao **mesmo** `gatilhos.ndjson`, cada um com seu `tag`. Distribuição real das
395 linhas:

| tag | chaves | linhas |
|---|---:|---:|
| `p2_gatilho_composicao` | 7 | 313 |
| `p2_gatilho_designados` | 10 / 11 | 28 / 1 |
| **`p2_gatilho_corpus_alinhado`** | **4** | **27** |
| **`p2_gatilho_heartbeat`** | **4** | **9** |
| `p2_gatilho_saturacao` | 12 / 11 / 13 | 7 / 2 / 1 |
| `p2_gatilho_coorte` | 12 / 4 | 3 / 2 |
| `p2_restart_realinha` | 4 | 2 |

⇒ **a forma de 4 chaves está viva em QUATRO sítios**: `corpus_alinhado` (27 linhas),
`heartbeat` (9), `restart_realinha` (2) e o `coorte` antes do conserto dela (2). A sessão
par consertou **um de quatro**.

> ⚠️ **A primeira versão desta frase dizia "dois sítios" e "um de três"** — e a tabela
> logo acima, escrita por mim no mesmo minuto, já trazia `p2_restart_realinha | 4 | 2`.
> Número certo na tabela, contagem errada na prosa: a família
> `a-correct-number-carried-by-a-wrong-sentence`, quarta vez no dia, e a única que
> **releitura** não pegaria porque os dois artefatos são meus e concordam entre si em
> tudo menos no total. Quem pegou foi a par recontando do zero. As contagens variáveis dentro de um tag são
versões do mesmo dia (o `saturacao` 11/12/13 são as minhas v1/v2/v3; o `coorte` 4/12 é o
antes e depois do conserto dela), não heterogeneidade de defeito.

⚠️ **E os dois sondadores que eu escrevi para este censo eram INVÁLIDOS**, os dois na
direção de acusar:

1. *"a função descarta `$3+`?"* medido por **contagem de palavras** depois do nome da
   função. Palavras dentro de aspas contam como argumentos separados, e nenhum
   `emitir GREEN "motivo=… campo=…"` passa mais de dois argumentos. O sondador acusou
   **11 emissores** e não sustenta nenhum.
2. *"o wrapper enterra em `linha_status`?"* por `grep` no **wrapper**, quando quem emite a
   linha é o **gatilho**. Deu "campos estruturados" para `corpus_alinhado` e `heartbeat`,
   que são justamente os dois que emitem 4 chaves.

A única parte confiável do censo é a tabela acima, que sai do **artefato emitido** e não
de leitura de fonte. É a lição do dia aplicada ao instrumento que a verifica: sondador
grosseiro produz veredito confiante, e a saída real desmente os dois.

**Não consertei os dois sítios**, e a razão é explícita: eles se aposentam em 21/09
(§10.23), e mexer em wrapper de produção agora, para um defeito de forma num ensaio que
fecha, é escopo que ninguém pediu. O que fica é o **requisito** para o que os substituir:

> A suíte precisa de um caso que **olhe o artefato emitido** — não o fonte, não a linha
> impressa. As duas suítes passavam verdes com e sem o defeito porque **nenhum caso abria
> o NDJSON**.

---

## §10.25 — A perna de auto-aposentadoria: onde entrou, onde não, e uma previsão medida como falsa

A sessão par implantou a perna *"o ensaio acabou, não há o que vigiar"* nos quatro guardas
que ela mantém (`composicao`, `designados`, `corpus-alinhado`, `heartbeat`), com 12
asserções — 3 por wrapper, incluindo o **par A/B completo**: A o caminho de encerramento
(stub `outcome=shadow`), B o caminho normal (tem de **seguir** para o guarda). Sem o B,
uma perna que engolisse tudo passaria em A. Rodados os quatro em produção depois de
implantar: os quatro vereditos inalterados, zero caindo no caminho novo — inerte hoje,
como tem de ser.

### A previsão que motivava urgência é falsa, e medi antes de aplicar

Ela previu que, depois de o `desliga-dose-p2.sh` arquivar o `zz-p2-active.conf`, as vars
`NOX_P2_*` sumiriam do unit e os wrappers passariam a `RED designacao-ausente-no-unit` —
"vermelho enganoso causado pelo próprio arquivamento". Medido:

| drop-in | vars |
|---|---|
| `p2-designation.conf` | `NOX_P2_DESIGNATION`, `NOX_P2_DESIGNATION_SHA256` |
| `p2s2-shadow.conf` | `NOX_P2_OUTCOME`, `NOX_P2_SERVING_LOG`, `NOX_P2_SHADOW_W` |
| **`zz-p2-active.conf`** (o arquivado) | `NOX_P2_ASSIGNMENT`, `NOX_P2_ASSIGNMENT_SHA256`, `NOX_P2_OUTCOME` |

⇒ **`DESIGNATION` sobrevive** — vem de outro drop-in, que não é tocado. O
`run-saturacao.sh` pós-arquivamento passa as linhas 59-61 (`DESIG`), pula 73-75
(`ASSIGNMENT`, dentro do ramo `active`, e o modo será `shadow`) e satisfaz 77
(`SHADOW_W`, sobrevive). **Roda normal em shadow, não RED.** O mesmo para o
`run-designados.sh` dela.

O `RED designacao-ausente-no-unit` do mutante dela é, com alta probabilidade, **artefato
do stub**: um `systemctl` stubado que devolve apenas `NOX_P2_OUTCOME=shadow` deixa `DESIG`
vazio **no stub**, não na realidade. É a família do dia migrada para a fixture — *o
cenário testado não reproduz o estado sobre o qual se conclui*.

⚠️ **A regra de ordenação dela continua válida por outro motivo:** qualquer pré-condição
que possa disparar antes da perna transforma um estado-final-esperado em alarme. O
princípio se sustenta com a instância errada removida.

### Por que o `run-saturacao.sh` fica sem a perna, com a razão à vista

Autorização existe (Toto, 2026-09-09 14:46: *"aposenta os guardas junto no 21"*). O
impedimento é risco, não mandato:

**O `run-saturacao.sh` é o guarda que reporta os últimos epochs da janela elegível**,
inclusive o parcial de 20/09 — o último dado do ensaio. Editá-lo a 11 dias do fim arrisca
exatamente a medição sobre a qual o ensaio fecha, e o ganho é **nulo** enquanto a
aposentadoria (§10.23) remove o cron dele.

O único caminho em que a lacuna importa é a aposentadoria **abortar** (alguém editou o
report), e aí os sete ficam de pé: os quatro dela dirão `GREEN ensaio-encerrado` e o meu
dará um veredito válido sobre uma dose que não é mais servida — enganoso, inofensivo e
visível no report.

⇒ Lacuna **documentada**, não omitida: a perna entra depois de 21/09, se e quando alguém
rearmar o cron. É a mesma razão pela qual todo o resto parou hoje — não se mexe no
instrumento nos últimos dias da janela que ele mede.

### Terceira instância do dia da mesma sonda

O `grep -q 'NOX_P2_OUTCOME'` dela concluiu que o `run-saturacao.sh` **tinha** a perna. Ele
lê a var, sim — como `MODO`, para repassar ao guarda (linha 54). A sonda respondeu
**presença-de-nome** em vez da pergunta feita. Somado aos meus dois sondadores do §10.24,
são **três instrumentos diferentes, no mesmo dia, todos medindo o fonte para responder
pergunta sobre comportamento** — e os três escritos *depois* de a lição estar registrada.

---

## §10.26 — A janela elegível classificava por RELÓGIO e reportava como exposição servida

**Enunciado (sessão par, PR #497, verificado aqui por via independente):** a delimitação
da janela elegível classificava cada epoch por **sobreposição de relógio** (active no ar ×
designados frescos) e reportava o resultado como **exposição entregue**. Corrigido para
classe composta com censo de entrega: **15 inteiras + 3 parciais + 1 vazia**, projetando
09-11…09-19 cheios — não as "18 inteiras + 2 parciais" do artefato anterior.

### Verificado no artefato anterior, campo por campo

| epoch | o que o artefato dizia | o que o serving diz |
|---|---|---|
| 2026-09-01 | `parcial`, `exposto_h=22.38` | 630 de 672 sob a dose designada |
| **2026-09-02** | **`inteiro`, `fracao_exposta=1.0`, `exposto_h=24.0`** | **0 briefs** |
| 2026-09-03 | `inteiro`, `exposto_h=24.0` | 441 de 672 |
| 2026-09-20 | `parcial`, `exposto_h=13.86` | futuro |

O modo mais nítido de dizer está num campo só: **`inteiros_de: "2026-09-02"`**. A faixa de
epochs "inteiros" **começava no epoch que nunca foi servido.**

### Três mecanismos, e nenhum é "conta errada"

1. **O defeito morava no NOME do campo.** `exposto_h` lê-se como exposição entregue, e o
   docstring dizia *"fração do epoch em que a dose foi servida"* — mas o valor era
   sobreposição de relógio. **Nome errado em artefato é pior que frase errada em prosa**,
   porque viaja no JSON e todo consumidor herda a leitura sem ter como suspeitar.

2. **A classe errada vinha da AUSÊNCIA do dado, não de um valor errado.** Sem perna de
   entrega, `inteiro` era o *default*. É a regra 9 com o sinal invertido: não um guarda
   calado por não ter o dado, mas um guarda **afirmando a classe mais forte** por não o ter.

3. **Não faltava medição, faltava cruzamento.** O fato do 09-02 estava medido ao lado desde
   08/09, no `INCIDENT-2026-09-02-epoch-perdido.md`. Dois artefatos no mesmo diretório, um
   certo e um errado, e a análise ia consumir o errado.

### O que o conserto ganhou, e o que ainda erra

Ganhou: censo separado com procedência (host, caminho, sha256, linhas), três vias de
contagem declaradas, `classe_janela × classe_entrega ⇒ unidade` com as duas metades
preservadas, aborto sem censo, epoch ausente do censo é `vazio` e nunca `cheio` por
omissão, e perna `em_curso` para epoch cujo fim não chegou. O artefato novo não projeta:
marca futuro como `futuro`, o que é mais honesto que a prosa que o resume.

⚠️ **Defeito residual medido aqui em 2026-09-10:** o campo `servidos` **não filtra por
`modo`**. Para 2026-09-01 ele conta **672** e declara `classe_entrega=cheio`, quando
**630** foram servidos em `active` sob a dose designada (w=4,0) e **42** ainda em `shadow`
(w=2,0). O veredito final do epoch continua `parcial`, mas chega pela perna do **relógio**
— então a perna de **entrega** está errada exatamente no único epoch em que ela podia ser
testada. Medido: 09-01 é o **único** epoch de modo misto na janela.

> Guarda cuja perna correta é encoberta por outra perna correta não tem teste que a
> alcance. Um caso, e ele é o caso.

### A mutação tinha duas metades e só uma estava escrita

Registro da sessão par, porque é a mesma família do meu `grep -c`, no fim desta seção: a mutação
M2 dela nasceu falsa porque a **sonda** era 09-02, esperando `vazia` — que é o veredito que
o original **já dá**. A perna de `vazio` precede a composição na cadeia `elif`, logo o ramo
mutado era inalcançável pela sonda. Mutante válido, compilando, aplicado, e testando nada.

Critério barato que pega a classe toda: **conferir que `espera != veredito_original` para
aquela sonda.** Resondada em 09-01 (relógio parcial + entrega cheia), onde o `or` promoveria
a inteira um epoch de exposição mista, a mutação morde.

### E o meu próprio grep absolveu por quebra de linha

No mesmo dia, corrigindo a errata do adendo de enquadramento, rodei `grep -c` pela frase
falsa para confirmar que ela saíra: **0** nos dois arquivos. Mas eu havia mantido a frase
**como citação** dentro do bloco de errata — o zero vinha de ela estar quebrada em duas
linhas, não de ter saído. **Mesmo `0` para "removida" e para "presente e invisível ao
grep".** Conferência válida exigiu normalizar espaço e exigir que a ocorrência estivesse
dentro do bloco de errata.

É o par simétrico do §10.20: lá o guarda não distinguia **afirmar de citar** e *acusava*;
aqui não distinguia e *absolvia*.

### Adendo — a sonda de uma mutação está acoplada aos DADOS, não só ao código

Consequência medida do conserto acima, e é uma classe de defeito que eu não tinha
registrada: **um conserto em qualquer lugar pode tornar uma mutação inerte sem ninguém a
tocar, e o relatório da corrida anterior continua a dizer que ela morde.**

A mutação M2 da sessão par troca `and` por `or` na composição
`unidade = inteira se (janela == inteiro) and (entrega == cheio)`. Antes do conserto da
perna de entrega, quem a discriminava era `2026-09-01`. Depois, não mais — verificado por
cálculo direto sobre o artefato em `e7dd3dcb`:

| epoch | `janela == inteiro` | `entrega == cheio` | `and` | `or` | |
|---|---|---|---|---|---|
| 09-01 **antes** do conserto | falso | **verdadeiro** | falso | verdadeiro | discriminava |
| 09-01 **depois** | falso | **falso** | falso | falso | **inerte** |
| 09-03 | verdadeiro | falso | falso | verdadeiro | **discrimina** |

Com as duas metades falsas, o `or` deixa de promover: a mutação passa e não prova nada. A
propriedade que separa `and` de `or` é **exatamente uma metade verdadeira** — e o conserto
mudou de qual epoch a tem.

Note que esta é a **segunda** troca de sonda da mesma mutação, e por motivo diferente da
primeira. A primeira foi hipótese errada (sondava `2026-09-02`, esperando o veredito que o
original já dá, num ramo inalcançável). Esta não teve hipótese errada nenhuma: os dados
mudaram debaixo de uma sonda que estava certa.

> **Comentar na mutação qual PROPRIEDADE dos dados a torna discriminante**, não só qual
> caso. "Relógio inteiro + entrega parcial" sobrevive ao conserto; "09-01" não. O caso
> muda; a propriedade é o que se procura de novo.

⇒ E o corolário operacional: **relatório de mutação tem prazo de validade que expira em
qualquer commit**, não só nos que tocam o guarda. Um `21/21` de ontem não é evidência sobre
o código de hoje se qualquer coisa mudou os dados que as sondas atravessam.

### O que o conserto da perna de entrega ganhou, e uma discrepância

Verificado no artefato de `e7dd3dcb`: `classe_entrega` de 09-01 passou de `cheio` para
`parcial`; `modo_misto` é campo próprio (`True` só em 09-01); `servidos_total` e `por_modo`
ficam preservados ao lado em vez de fundidos; e a `semantica` do artefato declara
explicitamente que `por_campo_epoch` é o **total e inclui `shadow`**. Unidades inalteradas:
6 inteiras, 2 parciais, 1 vazia, 1 em curso, 10 futuras = 20.

⛔ **ERRATA (2026-09-10) — O PARÁGRAFO ABAIXO ERA FALSO.** Fica à vista, tachado, com o
mecanismo do erro.

> ~~**Discrepância anotada:** o relato do conserto diz `motivo` → `motivos` (lista), com
> 09-01 parcial pelas duas pernas. O artefato em `e7dd3dcb` **não tem** campo `motivos` —
> os campos são `classe_entrega, classe_janela, epoch, esperado, fim, fracao_da_janela,
> horas_na_janela, inicio, modo_misto, por_modo, servidos, servidos_total, unidade`. Ou
> está no script e não é emitido, ou ficou de fora.~~

**O campo existia.** Em `e7dd3dcb`, dentro de `unidades_de_analise.parciais`:

```json
{"epoch": "2026-09-01", "motivos": ["relogio", "volume"],
 "servidos_active": 630, "servidos_total": 672, "modo_misto": true}
{"epoch": "2026-09-03", "motivos": ["volume"],
 "servidos_active": 441, "servidos_total": 441, "modo_misto": false}
```

A lista de campos que eu colei era a de **um objeto do vetor `epochs`** — e ali, de fato,
`motivos` não estava. Concluí sobre o **artefato** a partir das chaves de **um objeto
dentro dele**.

> **Ausência num caminho não é ausência no artefato.** Antes de reportar falta num JSON,
> listar as chaves de topo e procurar em todas.

⚠️ **O agravante:** as chaves de topo estavam **na minha própria saída**, duas horas antes —
`['censo_de_entrega', 'decisao', 'epochs', 'premissas_medidas', 'unidades_de_analise']`. Eu
imprimi o caminho que me corrigia, li a linha, e depois concluí ausência olhando só
`epochs`. Não faltava evidência; faltava usar a que eu já tinha no recibo. É a mesma forma
do §10.26 acima — *não faltava medição, faltava cruzamento* — cometida por mim ao registrar
essa exata lição.

E o registro `servidos_active: 630` estava nesse mesmo objeto: o split `active`/`total` que
eu media à mão já vinha declarado no artefato.

### O que sobrevive da minha objeção, e o que a par fez com ela

O **argumento** estava certo mesmo com a claim falsa: quem consome o artefato **itera
`epochs`**, que é a coisa natural a fazer, e um campo que só existe no resumo não protege o
leitor do vetor. Obrigar a derivar o motivo de `classe_janela` + `classe_entrega` é
informação recuperável-mas-não-declarada — o mecanismo exato pelo qual o `exposto_h` chegou
onde chegou.

Corrigido pela sessão par em `e88a8db`, e verificado aqui: cada registro de `epochs` agora
declara `motivos`, com três valores (`relogio` para janela parcial, `volume` para entrega
parcial, `vazio` para entrega zero), unidade inteira com lista vazia, e um caso que exige
que **epoch e resumo concordem** — porque duas declarações da mesma coisa em dois lugares é
a próxima forma de divergirem.

| | `e7dd3dcb` | `e88a8db` |
|---|---|---|
| `unidades_de_analise.parciais[].motivos` | presente | presente |
| `epochs[].motivos` | **ausente** | `["relogio","volume"]` em 09-01 |

⇒ Fica a distinção que eu deveria ter feito na primeira vez: **claim de ausência falsa,
objeção de desenho procedente.** Reportar as duas juntas fez a objeção parecer sustentada
pela claim, quando ela se sustenta sozinha.

---

## §10.27 — Eu publiquei uma tautologia como controle negativo que passa

**Retratação.** O PR #501, mergeado em 2026-09-10 14:19Z e retirado no mesmo dia,
afirmava um controle negativo intra-braço:

> ~~Brief de epoch de tratamento em que nenhum id designado aparece no conjunto
> **servido** não pode mexer. Medido: 2.908 briefs sem alcance, **0 movimentos**. Passa.~~

**Era tautológico.** Eu defini "servido" como `set(ids_controle) | set(ids_tratado)`, e
`ids_tratado` é **pós-dose**. Se a dose promove um designado, ele entra em `ids_tratado`
⇒ entra em "servido" ⇒ o brief cai no estrato "presente". O estrato "ausente" não pode
conter movimento **por construção**.

### O indício estava na minha própria saída

`presença em (controle ∪ tratado)` é **numericamente idêntica** a `presença em tratado`,
em todos os seis epochs:

| epoch | `presUniao` | `presT` |
|---|---:|---:|
| 09-01 | 189 | 189 |
| 09-04 | 185 | 185 |
| 09-05 | 184 | 184 |
| 09-06 | 144 | 144 |
| 09-08 | 187 | 187 |
| 09-09 | 193 | 193 |

Seis igualdades exatas. O critério **nunca dependeu do controle** — e a sessão par
identificou a via sem ver o meu código, reconhecendo o `144` de 09-06 como o `presT` dela.

### E a premissa estava invertida

Pelo critério **dose-independente** (presença no conjunto de controle), o estrato
"ausente" tem **118 movimentos**, não 0:

| epoch | w | `ausC` | mexeu | `presC` | mexeu | taxa em `presC` |
|---|---|---:|---:|---:|---:|---:|
| 09-01 | 4,0 | 453 | 12 | 177 | 10 | 5,6% |
| 09-04 | 2,0 | 513 | 26 | 159 | 9 | 5,7% |
| 09-05 | 2,0 | 514 | 26 | 158 | 7 | 4,4% |
| **09-06** | **7,5** | 548 | 20 | 124 | 18 | **14,5%** |
| 09-08 | 2,0 | 500 | 15 | 172 | 5 | 2,9% |
| 09-09 | 2,0 | 498 | 19 | 174 | **0** | **0,0%** |

Não é falha de instrumento — **é o mecanismo.** A dose age promovendo chunk que **não
estava** no baseline; ausência do controle é onde ela tem **mais** o que fazer, não menos.

> **Um estrato definido pelo desfecho não é controle.** O critério tem de ser
> computável **sem** olhar o resultado — aqui, `ids_controle` sozinho. Bastava perguntar
> *"este predicado usa alguma variável pós-tratamento?"*, e o `|` com `ids_tratado`
> responde sozinho.

### As taxas condicionais que eu reportei também caem

Reportei 26,4% para `w=7,5` contra 9,8–18,9% para `w=2`, "condicionado a a dose ter
alcance". Esse denominador era em parte **consequência do desfecho** — seleção sobre o
desfecho. A versão dose-independente dá 14,5% contra 0–5,7%, separação **maior**, mas com
variância dentro de `w=2` que vai de **zero** (09-09: 0 de 174) a 5,7%. Nada disso é
estimando primário.

### Não existe controle negativo intra-braço neste log, por três vias

| via | por que falha |
|---|---|
| epoch de controle tem `mexeu == 0` | os campos não existem lá (`sem_ids == n`) — regra 9 |
| presença de designado no servido | pós-dose ⇒ tautológico (esta seção) |
| `boost_by_id` vazio ⇒ `mexeu` 0 | estrato vazio: `sem_boost == 0` em 3.990 briefs |

O buraco fica **aberto e declarado**. A especificidade tem de vir de outra fonte — e a
que sobrevive é o **replay com designação-sham**, porque o viés do replay é
anticorrelacionado com o efeito e portanto **desaparece sob a nula**: o replay não pode
medir o efeito, mas pode falsificar a especificidade.

### O que fica versionado no lugar

`measurement/estratos-por-presenca-de-designado.py` — **caracterização, não controle**,
com o critério dose-independente, o aviso de que o estrato "ausente" ter movimento é o
esperado, e uma perna que **falha (exit 1)** se `presUniao != presT` em algum epoch, porque
isso significaria que a explicação desta retratação está errada.

⚠️ E o aviso do denominador sobrevive à correção: `presC` varia de 124 a 177 (razão
1,43×), a anomalia de 09-06 existe **também** nesta variável dose-independente — logo não
é causada pela dose — e continua **sem explicação**.

## §10.28 — O evento terminal do ensaio escreve num recibo que nada lê, e sai `exit 0` até no RED

**Achado em 2026-09-10, 11 dias antes do disparo.** Fui conferir as pré-condições do
`desliga-dose-p2.sh` — o `ONESHOT` do cron (`43 9 21 9`) que encerra o ensaio — e o que
apareceu não foi uma pré-condição frágil, foi a ausência de canal de entrega.

- Toda saída do script passa por `recibo()`, que grava a linha em
  `/var/lib/nox-mem/p2/status-desliga-dose.txt`, anexa ao NDJSON e **`exit 0`** — inclusive
  nos ramos RED. O veredito viaja no **arquivo**; o código de saída não o carrega.
- O `morning-report.sh` lê **seis** recibos p2: `composicao`, `coorte`, `corpus-alinhado`,
  `designados`, `heartbeat`, `saturacao`. O sétimo **não está na lista**. E o
  `/var/log/nox-p2-gatilhos.log` aparece apenas como destino de redirect nas linhas do
  cron, nunca como fonte de leitura em script algum.
- Evidência de que ninguém lê: um teste manual de **2026-09-09 17:42:31Z** deixou lá
  `YELLOW p2-desliga-dose motivo=janela-ainda-aberta-faltam-279h`. O morning report da
  manhã seguinte não o mencionou.

**O dano não é perder um alarme.** As pré-condições do script **abortam** o desligamento
quando falham. Se isso acontecer calado, o drop-in `zz-p2-active.conf` fica no lugar,
`NOX_P2_OUTCOME` segue `active`, e o ensaio **continua dosando depois do fim
pré-registrado** — contaminando a fronteira dos 234 epochs, que é exatamente o objeto do
§10.22.

### Por que o helper existente não serve

`p2_gatilho <rótulo> <arquivo> <idade_max_h>` marca YELLOW quando `idade > max`, com a
mensagem *"gatilho parado?"*. O status de um one-shot é velho **por desenho** depois de
disparar: um GREEN de 21/09 lido em 25/09 tem 96 h. Registrar o sétimo recibo pelo helper
produziria YELLOW todo dia — hoje inclusive, porque o resíduo de ontem tem ~21 h. **Recibo
de evento único não cabe em teste de idade.**

### A perna, e a mutação que a prende

Três ramos, não um limiar:

| ramo | predicado | veredito |
|---|---|---|
| 1 | agora < 2026-09-21T09:43Z | silêncio — não é devido |
| 2 | recibo presente | prefixo `GREEN*` passa; qualquer outro é RED |
| 3 | **recibo ausente E agora ≥ o prazo** | **RED** — o oneshot não rodou |

O ramo 3 existe porque, depois do prazo, *"recibo ausente"* e *"nada a fazer"* deixam de
ser o mesmo estado — a mesma classe do §10.9 e da regra 9 do `CLAUDE.md`.

Verificado em cinco casos contra o arquivo montado: `GREEN`+prazo passado → `RED=0`;
não-GREEN+prazo passado → `RED=1`; ausente+prazo passado → `RED=1`; ausente+prazo aberto →
`RED=0`; e **o resíduo YELLOW real de hoje** → `RED=0`, isto é, aplicar a perna **não muda o
report de hoje**. Mutação (apagar o ramo 3): mutante válido — 368→365 linhas, ocorrências de
`recibo AUSENTE` 1→0 — e o caso "ausente+prazo passado" cai de `RED=1` para `RED=0`, com a
assinatura de um contador **negativo** de horas restantes (`faltam -1h`).

### Estado, e o que ficou medido de bom

As demais pré-condições **passam hoje**, conferidas 11 dias antes em vez de descobertas na
hora: a cópia do corpus servido bate no sha esperado (`23378a9e…`, 1.254.526.976 B, modo
400), o drop-in existe, e `NOX_P2_OUTCOME=active`. E a idempotência do script é **por
estado, não por recibo** — `recibo()` sobrescreve com `>` e uma re-execução após sucesso
morre na pré-condição do drop-in já arquivado. Logo o resíduo YELLOW de ontem **não**
desarma o disparo de 21/09; seria sobrescrito.

**Fechado no mesmo dia, com autorização explícita.** A perna foi aplicada em produção em
2026-09-10; o hash do `morning-report.sh` saiu de `20a5b63fda32c93b` para
`4e515be61b5e49c2` (342 → 368 linhas), quebrando de propósito o congelamento acordado entre
as duas sessões — o cálculo foi que hash congelado é reversível e documentável, e dosagem
fora da janela não é. Espelhado no repo de infra no mesmo passe (`openclaw-vps#35`), senão
reabriria o drift de espelho que o `#34` acabara de fechar.

Verificado **depois** de aplicar, in situ, porque verificar o arquivo montado não é
verificar o arquivo instalado:

| verificação | resultado |
|---|---|
| diff contra o backup mode-400 | **1 hunk, 26 adições, 0 remoções** |
| `set -u` e inicialização das variáveis | `set -u` na linha 6; `RED`/`YELLOW`/`DETAILS` nascem nas 100–102, a perna está na 312 ⇒ sem risco de variável não-ligada |
| recibo real de hoje | `RED=0`, `DETAILS` vazio ⇒ o report de hoje **não muda** |
| prazo forçado ao passado | `RED=1`, acusando a linha YELLOW real |
| prazo passado **e** recibo ausente | `RED=1` com a mensagem do ramo 3 |

**O desvio, porém, não deixa de existir por ter sido consertado.** Durante os primeiros ~9
dias do ensaio — de 2026-09-01 a 2026-09-10 — o único evento terminal do desenho esteve sem
canal de entrega. Se o disparo tivesse sido antecipado por qualquer motivo nesse intervalo,
uma falha dele seria invisível. O conserto é posterior ao risco, não retroativo a ele.


---

## §10.29 — Desfecho EXECUTADO (2026-09-21): o realizado não é o projetado, e o aplicador staged teria apagado o instrumento

O §10.22 registrou a decisão e a janela **projetada**; o §10.23, a aposentadoria
**planeada**. Esta seção registra o que de facto aconteceu, e as três divergências.

### O desligamento correu como escrito

| evento | instante (UTC) | evidência |
|---|---|---|
| drop-in arquivado | `2026-09-21 09:43:05Z` | `…/desarmado/zz-p2-active.conf.desarmado-20260921T094305Z` |
| unit reiniciado | `09:43:06Z` | `ExecMainStartTimestamp` |
| recibo escrito | `09:43:12Z` | `status-desliga-dose.txt` |

`NOX_P2_OUTCOME=shadow` conferido no **env do processo** (`/proc/<MainPID>/environ`), não
no `.env` — a distinção do `[[feedback_dotenv_is_intent_process_env_is_state]]`. E o `fd`
26 realinhou para `e20260921T060001Z.db`: **fecha o §10.10**, aberto desde 03/09.

### Divergência 1 — a janela realizada é menor que a projetada

Recontada em 21/09 sobre `p2-serving.ndjson`, agrupando pela janela real
`[09:00Z, 09:00Z)` e **não** por dia de calendário:

| | projetado (09/09) | **realizado** |
|---|---:|---:|
| epochs inteiros (672/672) | 18 | **17** |
| parciais | 2 — `09-01`, `09-20` | **2 — `09-01`, `09-03`** |
| vazios | 0 | **1 — `09-02`** |

- `09-01`: 672 registos, mas **mistos** — 630 `active` (`w=4,0`) + 42 `shadow` (`w=2,0`);
  o `active` entrou 1h37 depois da fronteira. É o mesmo epoch de modo misto que o §10.26
  já apontara.
- `09-03`: **441/672** (65,6 %), `w=0`.
- `09-02`: **zero registos**. O §10.22 contava-o como inteiro; o incidente que o esvaziou
  está em `INCIDENT-2026-09-02-epoch-perdido.md` e **não** foi propagado à tabela da janela
  elegível. A projeção herdou um epoch que já não existia quando foi escrita.
- `09-20`, que se esperava **parcial** (13,86 h de exposição), registou **672/672** — e é
  **`w=0`**. Logo a expiração dos designados às `22:51:23Z` caiu dentro de um epoch de
  **controlo**, e não truncou dose nenhuma. É observação sobre o log; a admissibilidade do
  epoch é decisão da spec de análise, não desta seção.

Dose dos 17 inteiros: `w=0` em **7** (`09-07,10,11,13,17,18,20`) · `w=2` em **6**
(`09-04,05,08,09,16,19`) · `w=4` em **3** (`09-12,14,15`) · `w=7,5` em **1** (`09-06`).

### Divergência 2 — o one-shot abortou a aposentadoria, e estava certo

Recibo de 09:43:12Z: `YELLOW … APOSENTADORIA-ABORTADA report-divergiu sha=4e515be6…`
contra o esperado `20a5b63f…`. A pré-condição disparou porque **nós** editámos o
`morning-report.sh` em **2026-09-10 17:59** — é exatamente a mudança que o §10.28 descreve,
a perna que dá o recibo do evento terminal. O §10.28 previra isto por escrito (*"mexer no
report antes de 21/09 exige regerar a versão staged"*) e a regeração não foi feita.

🔑 **E a pré-condição não foi burocracia: instalar o staged era o dano.** O
`morning-report.p2-aposentado.sh` foi congelado em 09/09 e, por construção, **não contém a
perna de 10/09**. Instalá-lo comentaria os seis gatilhos *e apagaria o único canal que
reporta o desfecho do ensaio* — trocaria ruído por cegueira no evento terminal. A
aposentadoria foi portanto refeita **a partir do report vivo**, preservando a perna.

> **Aplicador staged e alvo divergem com o tempo; o hash detecta a divergência mas não diz
> de que lado está o valor.** Aqui o valor estava no alvo. Mesma forma de
> `[[feedback_a_versioned_mirror_of_an_applier_can_delete_what_matters]]`.

### Divergência 3 — o número projetado ia ser publicado como medido

A linha informativa do staged dizia, literalmente, `18 epochs inteiros + 2 parciais`:
números de 09/09 escritos num artefato que só seria lido a partir de 21/09. Substituída
pelo medido, com a proveniência na própria fonte (`p2-serving.ndjson`, janela
`[09:00Z,09:00Z)`). Cf. §10.26 e
`[[feedback_a_measured_ruler_can_go_stale_and_send_work_in_the_opposite_direction]]`.

### Estado final, verificado

Aposentadoria aplicada `13:33Z`; `morning-report.sh` passa a `012a1649dfa732d5…`.

| verificação | resultado |
|---|---|
| chamadas `p2_gatilho` ativas | **0** (6 comentadas com `#APOSENTADO-2026-09-21`) |
| definição da função `p2_gatilho()` | **preservada** |
| perna do `desliga-dose` (10/09) | **preservada**, 3 ocorrências |
| crons `scripts/p2/` | 7 → **0** (crontab 63 → 56 linhas) |
| `morning-report` ainda agendado | sim |
| dry-run **antes** do recibo novo | `exit 2` — **1 RED**, acusando o YELLOW |
| dry-run **depois** | `exit 0` — **`✅ all green`** |
| linha `⚪` no corpo entregue | **presente** (conferida imprimindo `BODY`, não inferida) |

O YELLOW original **não foi apagado**: o `.txt` é o canal do report e foi reescrito, mas o
recibo anterior ficou em `desliga-dose.ndjson`, que é append-only. Backups datados em
`/root/.openclaw/paper2/aposentadoria/`.

### Um defeito próprio, no aplicador

O script abortou a meio com `ABORTA: sobrou chamada ativa`, depois de já ter gravado a
edição. A edição estava **correta**; o predicado é que era frouxo:

```sh
grep -c '^p2_gatilho'   # deu 1 — e o 1 era a linha 247, a DEFINIÇÃO da função
```

Contar um símbolo pelo **nome** soma definição e chamadas. O par que fecha as duas pontas —
`^p2_gatilho[[:space:]]+"` → 0 e `^p2_gatilho\(\)` → 1 — e a perna que impede retomada
destrutiva (`linha informativa presente == 1`, senão uma segunda passagem duplicava-a).
Sobreviveu sem dano porque a ordem era *report primeiro, cron depois* e havia backup
datado, **não** porque o abort foi cuidadoso.

---

## §10.30 — Quarta família no painel do estudo vivo (2026-09-21) — desvio autorizado, com o que custou

⚠️ **Números de efeito abaixo são PARCIAIS** (lote-00 de 12) e serão fechados quando o
passe terminar. A decisão, o mecanismo e o parâmetro alterado não mudam.

### O que muda em relação ao registado

O §682 do `PREREG-DRAFT.md` travou o painel do estudo vivo em **três famílias alcançadas
por API** — `glm-5.2`, `grok-4.5`, `gemini-2.5-pro`. Esta corrida acrescenta uma quarta,
**`deepseek-v4-pro`**, por decisão explícita do Toto em 2026-09-21 ("pode colocar"),
tomada depois de lhe ser apresentado o trade-off.

### Por que — a fragilidade prevista ocorreu, e foi medida

O próprio §695 declarou o ponto fraco de três painelistas: *"a single abstention drops an
episode below the 3-verdict floor"*, medido em **8 de 300 (2,67%)** na calibração,
*"inside the 10% ceiling but fragile"*. E registou a mitigação, então impossível: *"seat a
fourth API family — not adopted here because it needs a credential that does not exist
yet"*. **A credencial passou a existir.**

Medido em campo no primeiro lote deste passe: **3 de 100 episódios (3,00%) abaixo do
piso**, e **100% das abstenções são do `xai`, todas por cota**. Não é conjetura sobre um
risco: é o modo de falha previsto, a ocorrer, na mesma ordem de grandeza da calibração.

### O parâmetro que teve de mudar, e a evidência que o obrigou

`MAX_TOKENS_OVERRIDE["deepseek"]` sobe de **1500 para 6000**. Motivo medido, não
suposto — com 1500, 1 de 3 chamadas devolvia:

```
status=missing  detail='resposta 200 sem texto — {"served":"deepseek-v4-pro","stop":"max_tokens",...}'
```

HTTP **200**, `stop_reason: max_tokens`, **zero blocos de texto**: o bloco de *thinking*
consome o orçamento inteiro antes do veredicto. É a armadilha que o próprio ficheiro já
documenta para o Gemini e para o zhipu; o teto de 1500 resolveu-a no piloto e **não basta
para os episódios deste corpus**. Com 6000: **12/12 ok, 0 missing, 0 quota**.

O passe do DeepSeek corre por **`run_panel_deepseek6k.py`**, cópia que difere do original
em **uma linha** — a do teto. O `run_panel.py` ficou **intocado** durante a corrida das
três famílias, para que o instrumento não mude a meio. **O prompt é o mesmo em todos os
passes: `5b22f02c…`**, idêntico ao travado no registo.

### Que espécie de painelista ele é — medido antes de ser admitido

Nos 12 episódios que as três famílias já tinham julgado, o DeepSeek concorda em **10/12**
na distinção `failure`/`not_failure`. Nos 2 divergentes **quem destoa é o `zhipu`**: xAI,
Google e DeepSeek dizem `failure`, o zhipu diz `not_failure`. Ou seja, a quarta família
**reforça a maioria já existente** em vez de criar uma nova — não desloca o veredito
majoritário em nenhum dos 12.

### Efeito (PARCIAL — lote-00)

| | sem DeepSeek | com DeepSeek |
|---|---:|---:|
| episódios abaixo do piso, no lote que ele cobriu | **3** | **0** |

Os 3 resgatados são exatamente os 3 em que o `xai` abstivera. Taxa de recuperação 3/3.

### O que isto NÃO autoriza

Não muda τ (segue **S1**), não muda a calibração (que continua assente em **cinco**
famílias, §699), não muda o prompt e não muda a regra de maioria. A comparação de
confiabilidade (κ/α) com o painel de três tem de ser recomputada com a quarta dentro, e a
análise **leave-one-family-out** passa a ter quatro folhas em vez de três. Um leitor tem
de conseguir ler o resultado com e sem o DeepSeek: ambos os conjuntos de vereditos ficam
versionados separadamente (`ensaio-20260921-lote-*.jsonl` contra
`ensaio-20260921-ds-lote-*.jsonl`), precisamente para que a sensibilidade seja calculável.

---

## §10.31 — ERRATA ao §10.29 e §10.30, após revisão adversarial (2026-09-21)

Duas vozes independentes (Kimi/Moonshot por casca adversarial com recibo `exit 0`;
segunda leitura em Fable) reviram o trabalho deste dia. **Seis correções**, todas a
afirmações minhas. O §10.29 e o §10.30 ficam como estão — este registo é append-only —
e o que vale é o que se lê aqui.

### (1) 🔴 `09-20` é parcial, não inteiro — e eu usei uma régua que não é a da spec

| | classificação |
|---|---|
| eu publiquei (§10.29, `D-2026-09-21`, HANDOFF, commit `c0e49c3`) | **17 inteiros + 2 parciais + 1 vazio** |
| **correto, pela régua da `SPEC-ANALISE-2026-09-10.md`** | **16 inteiros + 3 parciais + 1 vazio** |

A spec classifica `09-20` como **parcial por relógio, 13,86 h/24** (l.32) e fixa a regra
*"incluída, com offset; truncamento puro; o corte cai dentro do epoch, às 22:51:23Z"*
(l.92). Eu medi **volume de entrega** (672/672 registos de serving) e concluí «inteiro».
São réguas diferentes: a spec conta **exposição**, eu contei **entrega**. A
pré-registada é a que vale, e usá-la não era opcional.

Agravante: apresentei o resultado como *"bate exatamente com a spec"*. Coincidia no
total (19 com dado) e divergia na decomposição, que é o que decide se o epoch entra com
offset. **`09-20` ser `w=0` não anula o offset** — a spec conta exposição, não dose.

⚠️ E a tabela da spec **omite `09-10`**: soma 15+2+1+1 = 19 contra 20 alocados. Foi
escrita em 10/09 21:40, com esse epoch ainda aberto — nem confirmado nem projetado.
Com ele, as inteiras são **16**. A errata corrige o meu erro **e** fecha essa lacuna.

### (2) 🔴 Braço por DESIGNAÇÃO, não por moda dos dados

Derivei o braço de cada epoch como «a dose do modo `active` mais frequente». Isso é
**conditioning pós-randomização**: a moda é função de quando o `active` entrou. O braço
vem de `ASSIGNMENT-SERVING.json` (derivado de `ASSIGNMENT.json`, `assign_arms.py`, seed
do beacon round **31774052**).

**Confrontado agora: 0 divergências em 19 epochs.** A composição servida — 8 controlo /
11 tratamento (`w=0`×8, `w=2`×6, `w=4`×4, `w=7,5`×1) — não muda. Muda a **premissa**, e
é esta que vai ao paper. Isto é também a validação cruzada que o §10.29 alegou ter e não
tinha: comparar o meu censo com a tabela da spec não era segunda via, porque ambos saem
da mesma designação.

### (3) 🔴 «Zero inversões» é tautologia, não qualidade

O §10.30 apresenta «em 0 episódios ele inverte um veredito já decidido» como evidência de
que a 4.ª família não corrompe nada. **É estruturalmente impossível haver inversão**:
acrescentar um voto a painel ímpar sob maioria estrita só pode manter (3-0 → 3-1) ou
empatar (2-1 → 2-2). Uma moeda daria zero. A métrica com conteúdo é a concordância com
a maioria das três: **1111/1145 = 97,0%**.

### (4) 🔴 «100% das abstenções são do `xai`» é falso no corpus completo

Medido nos 1.195: **`xai` 26 abstenções + 6 cotas + 1 missing · `zhipu` 13 · `google`
11**. O «100%» era verdade no **lote-00** (100 episódios) e foi generalizado a 1.195 sem
ser remedido.

### (5) 🔴 Os dados NÃO «confirmam» τ=S1 — e a metade citada é a errada

O §10.29/§10.30 e o relato do dia dizem que a distribuição de severidade sustenta τ=S1.
Três defeitos: **τ está travado desde julho** sobre a calibração de **cinco** famílias
(PREREG §697-699) e um parâmetro travado não se «confirma» com dados do período de
desfecho — é post-hoc; o que chamei «concordância em S0 (57-69%)» são **taxas
marginais**, não concordância; e citei a fronteira **S1/S2**, que τ absorve, calando a
**S0/S1**, que τ **não** absorve e onde há um desvio de **12 pp** (`google` 42,3%
failure contra `zhipu` 30,4%).

### (6) 🔴 A explicação do saldo +7 → −8 era racionalização

Afirmei que o retry do `xai` «recuperou por outra via o que o DeepSeek resgatava». Os
conjuntos são **disjuntos**: os 7 do retry não estão entre os resgates dele. E o sinal
vem das **perdas** (28), não dos ganhos — creditando os 7 ao DeepSeek, 27 contra 28
continua negativo. A explicação mirava a variável errada.

**O saldo, com a regra publicada** (piso ≥3 vereditos substantivos; maioria estrita;
abstenção conta como ausente): **ganhos 20 · perdas 28 · saldo −8**. Uma das vozes
recomputou 16/28/−12; re-executado com o predicado acima, dá 20/28/−8. O sinal é o
mesmo nas duas contas; **a regra tinha de estar escrita** para não haver duas.

⚠️ «Perda» é rótulo meu e é impreciso: `pilot_replay.py` l.145-148 fixa que **2-2
resolve para `not_failure`** — *"a tie is not a majority. Conservative: it underestimates
failures"*. Não é indefinição, é **viés direcional para o nulo**. E o §10.30 afirma «não
muda a regra de maioria», o que é falso em efeito: a mediana inferior de 4 não é a de 3,
e é ela que alimenta a condição (i) com τ=S1.

### O que substitui a decisão do §10.30

A decisão de compor o painel **depois de contar empates nos vereditos do ensaio** é
post-hoc — a `SPEC-ANALISE` §9 diz que *"escolher o conjunto primário depois de ver o
número é a jogada post-hoc que esta spec existe para impedir"*. Fica registado como tal.

**O que passa a valer:** o DeepSeek entra como **substituto** apenas nos episódios sem
piso de 3 vereditos substantivos — a função que o PREREG §695 lhe atribui — e **nunca
como 4.º voto** onde os três responderam. Assim não gera empate nenhum, e o efeito dele
é o resgate, que é o que o §695 previa. O conjunto de 4 votos fica publicado como
**sensibilidade declarada**, com a regra de 2-2 nomeada.

### O predicado de processo zumbi mata escrita legítima (registo operacional)

Fora do âmbito do paper, mas medido no mesmo dia: o critério *"transcript parado E
escreve >20 MB em 8 s"* que usei na VPS **exclui o modo de falha que observei** (o zumbi
original tinha socket vivo e não escrevia nada) e **inclui trabalho legítimo** — o
próprio `run_panel.py` a escrever vereditos satisfaz 2,5 MB/s trivialmente, e matá-lo a
meio corromperia o ficheiro. O sinal está todo em «transcript parado»; a cláusula de
bytes só acrescenta erro. Corrigir para *stall timeout* calibrado contra a chamada
legítima mais longa, medido antes de adotado.

---

## §10.32 — Dois locks do pré-registro colidem em `Opportunity`; H1b fica INAVALIÁVEL

**Registado ANTES de computar qualquer estimativa da família H1a-c.** A decisão do Toto é
de 2026-09-21 16:14, tomada sobre os três ramos apresentados com os seus custos, e nenhum
número da família tinha sido produzido nessa altura. A ordem importa: escolher o estimando
depois de ver o desfecho é o que a `SPEC-ANALISE` §9 existe para impedir.

### A colisão

| lock | data | o que diz |
|---|---|---|
| `Opportunity` (§3, *Pilot metric definitions*) | **2026-07-29** | *"An **executed action `a`** … for which the serving snapshot at session start contained ≥ 1 failure episode `a_past` with `sig(a_past) = sig(a)`…"* |
| H1b (§1) | **2026-08-16** | *"An opportunity yields a repeat attempt if the **session** emits at least one action whose signature `sig()` equals that of `a_past` — whatever its outcome"* |

São **estimandos diferentes**. Sob o lock de julho a oportunidade **é** a ação, e a ação
carrega `sig(a_past)` por definição ⇒ **H1b = 1,0 por construção**, e o aninhamento
`H1c ⊆ H1b ⊆ H1a` — que o próprio §1 chama *"the nesting that makes the joint reporting
work"* — deixa de existir. Para H1b ter conteúdo, `Opportunity` teria de ser propriedade da
**sessão**, e aí o denominador muda para **toda** a família, não só para H1b.

Nenhum documento posterior resolve: a `SPEC-ANALISE-2026-09-10` **não menciona H1b uma única
vez**, e não existe artefato em `out/` que o tenha computado.

### A decisão, e por que esta e não a outra

**Vale o lock de 2026-07-29 — `Opportunity` é a AÇÃO.** Razão decisiva, e ela já está
escrita no próprio pré-registro: o §420 regista que **`r̂`, `p̂0` e o ICC foram todos
computados pelo replay sob o modelo do §3**, e que a construção então travada foi a que
*"keeps every locked number valid — the alternative constructions would have invalidated
them"*. Adotar a leitura de sessão agora invalidaria esses três números e, por dependência,
o `N_epochs` que o `sizing.py` deles derivou. O documento já enfrentou uma escolha análoga e
resolveu-a na mesma direção; esta decisão é consistente com esse precedente, não nova.

### Consequência declarada

**H1b passa para a lista de INAVALIÁVEIS da `SPEC-ANALISE` §8**, ao lado do TOST
braço×cobertura, da dose-resposta, do leave-one-agent-out e do contraste primeira/segunda
metade. Motivo a constar no paper: **colisão entre dois locks, não reconciliada antes do
fecho da janela** — não «não medimos», nem «deu não-significativo».

⚠️ **O que se perde, dito com clareza.** H1b era o membro da família que distinguia *"o
tratamento faz o agente **parar de tentar**"* de *"faz o agente tentar e **acertar**"* — o
próprio §1 chama a isto *"the substantive one for this paper"*. Essa distinção **não é
reportável** neste estudo. A perda é de **mecanismo**, não de potência: H1c já estava
declarado sem resultado possível no N realizado (§3 da spec, MDE saturado), logo nada aqui
piora o que já se sabia sobre detetabilidade.

### O que fica computável, e sob que definição

`H1` (densidade incondicional de falhas repetidas por hora de sessão) e `H1a` (taxa de
oportunidades elegíveis por hora de sessão) não dependem da leitura em disputa — ambos
assentam no lock de julho, que é o que vale. `H1c` é computável e será reportado com ponto,
IC e `n` por braço na mesma linha, acompanhado da declaração de subdimensionamento que o §6
da spec torna obrigatória.

---

## §10.33 — O denominador de exposição mede OCIOSIDADE; um epoch decide H1a

### O que o denominador mede, e o que se julga que mede

`H1` e `H1a` dividem por **horas de sessão**, computadas por `span_por_sessao`
(`pilot_replay.py` l.226) como `max(ts) − min(ts)` dos episódios da sessão. Isso é a
**distância entre o primeiro e o último episódio**, não tempo de trabalho: uma sessão que
age, adormece e volta seis horas depois conta seis horas de exposição.

**Medido na janela do ensaio:** dezanove epochs têm entre **0,32 e 0,97 h**; o `2026-09-14`
tem **7,13 h** — sozinho, **56%** de toda a exposição do braço de tratamento. A causa está
isolada numa sessão (`d37a5964…`) com **três** episódios: um às 13:52 e dois às 20:12, span
6,33 h. As sessões que de facto trabalharam nesse epoch fizeram 74, 65 e 56 episódios em
**9 a 10 minutos** cada.

⚠️ **O artefacto não é deste ficheiro.** A função é a do `pilot_replay`, logo o
`hours_per_epoch` do piloto (1,1144) carrega a mesma propriedade. Não é defeito introduzido
na análise do estudo; é uma propriedade da definição registada que só se manifesta quando
um epoch tem sessão esparsa.

### A decisão, e por que NÃO se troca o denominador

Decisão do Toto, 2026-09-21 16:20: **manter a definição travada**, com a perna de
sensibilidade reportada ao lado. Não é invenção — é o padrão que a `SPEC-ANALISE` §2 já
pré-compromete: *"a sensibilidade que os remove é reportada ao lado — divergência entre as
duas é reportada como está, **nunca adjudicada em favor de uma**"*.

Trocar o denominador por «trabalho efetivo» foi **recusado**: seria mudar definição travada
**depois** de ver que ela dá resultado incómodo, e invalidaria `r̂`, o ICC e o `N` do
`sizing.py`. Mandar `H1`/`H1a` para inavaliáveis foi recusado por deitar fora informação
que existe.

### O resultado, com as duas pernas

Bootstrap por **epoch inteiro**, 10.000 réplicas, seed `20260921` declarada; peso
Horvitz-Thompson do estrato B = **6,945** (5.556/800).

| | primário (travado) | sensibilidade (sem `09-14`) |
|---|---|---|
| horas trat. / ctrl | 12,70 / 5,16 | **5,57 / 5,16** |
| `H1` (repeats/h) | −14,62 · IC [−20,51; −4,79] · exclui zero | −9,74 · IC [−16,21; −2,99] · exclui zero |
| **`H1a`** (oport/h) | −143,92 · IC [−209,80; −15,34] · **exclui zero** | −63,04 · IC [−120,45; **+1,76**] · **contém zero** |
| `H1c` (repeats/oport) | −0,0199 · IC [−0,0560; +0,0086] · contém zero | −0,0244 · IC [−0,0619; +0,0051] · contém zero |

🔴 **`H1a` inverte de conclusão com a remoção de um epoch.** Um epoch cuja exposição vem de
uma sessão de três episódios é a diferença entre «exclui zero» e «contém zero». O número
**não suporta peso**, e é esta linha — não a do primário — que o leitor tem de ver.

⚠️ **E um IC que exclui zero em `H1` não é achado.** `H1` foi **retirada de primária em
2026-08-30** por exigir **955%** de efeito (`DESIGN-REVISION-2026-08-30.md` l.196,
*"impossível por construção"*). Um intervalo que exclui zero numa hipótese declarada
indetetável é sinal de artefacto no denominador, não de efeito — e com 9 e 11 epochs o
bootstrap por cluster tem poucos graus de liberdade e produz intervalo otimista.

### O que o estudo entrega

**`H1c`: 0,0696 no tratamento contra 0,0896 no controlo, diferença −0,0199, IC
[−0,0560; +0,0086] — contendo zero nas duas pernas.** É o desfecho estável, e é o que o §3
da spec previra: **não detetável**, com MDE saturado em 100%. Vai acompanhado da declaração
de subdimensionamento que o §6 torna obrigatória, e **ausência de significância não é
evidência de ausência de efeito**.

Artefacto: `ITT-2026-09-21.json` (fora do repo, com os episódios). Instrumento:
`estimador_itt.py` — **composição**, não reimplementação: importa `carregar_verdicts`,
`carregar_episodios` e `span_por_sessao` do `pilot_replay`, e o braço vem de
`ASSIGNMENT-SERVING.json`, nunca inferido dos dados.

---

## 10.34 — Itens 5 e 7 do §6: a correlação braço×cobertura troca de SINAL ao tirar o parcial, e o `n=1` no topo da dose é sorteio inteiro, não truncamento (2026-09-21)

Fecham os dois últimos dos sete reportáveis do `SPEC-ANALISE-2026-09-10 §6`.

### Item 5 — M10: correlação braço × cobertura, reportada INCONDICIONALMENTE

A trava original (PREREG 5) pedia um TOST de equivalência; o `§8` da spec já o
declara **não avaliável no K realizado** — o que não é o mesmo que «equivalência
não estabelecida». Reporta-se então a correlação e o seu IC, com as pernas
declaradas:

| perna | K | r | IC95 (bootstrap por epoch, 10 000) | |
|---|---:|---:|---|---|
| primária — todos | 19 | **+0,1130** | [−0,4773; +0,5088] | contém zero |
| sem `09-20` (o parcial de 13,86 h) | 18 | **−0,1871** | [−0,5704; +0,3353] | contém zero |
| sem os dois parciais | 17 | −0,1114 | [−0,5114; +0,4518] | contém zero |
| sem `09-14` (perna do ITT) | 18 | +0,0837 | [−0,5180; +0,4932] | contém zero |

⚠️ **O sinal troca.** `09-20` é controlo e tem cobertura de 14,6% contra ~28% em
todos os outros — é o epoch de 13,86 h, e a cobertura baixa é artefacto do
relógio, não do braço. Ele sozinho puxa `r` de −0,19 para +0,11. As quatro pernas
contêm zero e o IC tem meia-largura ~0,5 em todas: **a K=19 esta correlação não
distingue nada**, e é isso que há para dizer. Reportar só a primária teria vendido
um sinal que é de um epoch truncado.

Cobertura por epoch, para o leitor: 14,6% (`09-20`) e depois 21,4%–31,8%, sem
padrão por braço. Correlação com a **dose** (`w`, não o braço binário): −0,0521.

### Item 7 — o `n=1` em `w=7,5`: 1% truncamento, 99% sorteio

Dos 20 epochs designados na janela, a alocação saiu `control 9 · w2 6 · w4 4 ·
w7,5 1`. **O frame não importa aqui**: `09-02` (o que nunca foi servido) era
`control`, logo `w7,5 = 1` nos 20 designados e nos 19 realizados.

Decomposição, contra o défice total de **−2,333** face ao desenho:

| perna | valor | quota |
|---|---:|---:|
| esperado pelo desenho (20 × 39/234) | 3,333 | — |
| **truncamento** — condicionar nas datas realizadas | **+0,023** | **1,0 %** |
| **sorteio** — da média condicional ao realizado | **−2,357** | **101,0 %** |

Medido em **2 000 sementes** sobre as **mesmas datas**, com o `assign_arms.py`
publicado (`build_epochs("2026-09-01", 234)` + `assign`): média condicional
**3,357**, moda **3** (25,3%), `P(n=1) = 10,15%`, `P(n≤1) = 11,95%`. A média de
`control` condicional é 9,991 contra 9 realizado — a truncatura também não
desloca esse.

⚠️ **A truncatura não explica o défice.** A intuição de que parar em 20 de 234
epochs enviesaria contra a dose de topo é falsa por construção: a estratificação
é `(metade do calendário) × (dia útil|fim-de-semana)`, e os 20 primeiros dias caem
todos em `h1`, onde a alocação já é balanceada — condicionar move a esperança em
**+0,023**, e no sentido contrário ao que a intuição previa. O `n=1` é uma cauda
de ~10%, e nada mais.

Isto **concorda** com a medição anterior da spec (23/300 = 7,67%, moda 3–4): o
IC95 daquela proporção sobre 300 sementes é [4,7%; 10,7%], e 10,15% cai dentro.
Duas medições com frames diferentes, mesmo resultado — o que aqui é novo é a
**separação** das duas causas, que a spec afirmava sem a medir.

Artefacto: `ITEM7-DOSE-TOPO-2026-09-21.json` (fora do repo, com a distribuição
inteira das 2 000 sementes).

### Estado do §6

Os sete reportáveis estão fechados: 1–4 em 10.32/10.33, **5 e 7 aqui**, 6 na
decomposição de cobertura por assinatura de 10.33. Nenhum conjunto primário foi
escolhido depois de ver número — as pernas de sensibilidade estavam declaradas na
spec de 10-09, dez dias antes do fecho da janela.
