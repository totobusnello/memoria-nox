#!/usr/bin/env node
/**
 * replay-oportunidade.mjs — item 1 do PROTOCOL-CALIBRATION-2026-08-27.
 *
 * Replay do canal de boost do Paper 2 exercitando o CÓDIGO REAL de serving
 * (`buildBriefDiverse` importada do `dist`), não uma reconstrução. Existe porque
 * toda medição de "oportunidade" feita até 27/08 mediu ORDENAÇÃO sobre um pool
 * reimplementado, e o §4 de DEVIATIONS-FOR-PAPER.md declara isso como defeito
 * aberto: nada fazia replay de `interleaveFresh`, `pickDedup`, `pinned`,
 * near-dup nem do corte do `LIMIT 400`.
 *
 * Cinco modos. `dose` é condição de no-go; `porque` é teste falsificável da
 * derivação formal do §5 do manuscrito:
 *
 *   ancora  reproduz a âncora publicada (pool 108, 55 do estudo, 44 grupos,
 *           0 nunca-servidos, posição 0) usando `fetchFreshCandidates` REAL.
 *           Divergência aqui é achado, não erro do script.
 *   campo   replay dos briefs do log da janela fechada, comparando
 *           churn/would_enter/would_leave com o que a PRODUÇÃO registrou.
 *           É a âncora mais forte disponível: valida o pipeline inteiro.
 *   gaps    censo de gap de `salience` DENTRO de estratos de `last_served` idêntico,
 *           por sub-pool (agente e global), com o pool montado pelo código real. O
 *           `0,0318` publicado é só do sub-pool GLOBAL; o do agente nunca foi medido.
 *   dose    varredura de `w` sobre estados reais. Se `w = 100.000` não move
 *           NADA em NENHUM estado, o canal não existe e o estudo morre aqui —
 *           o que é um resultado.
 *   porque  testa a Proposição 1 do §5 (o bônus permuta DENTRO de estrato de
 *           `last_served` e nunca atravessa) contra o que a produção registra:
 *           em todo estado que muda, cada id que ENTRA tem de compartilhar
 *           `last_served` com algum id que SAI. Uma entrada sem parceiro REFUTA
 *           a proposição e o modo aborta. Usa só `would_enter`/`would_leave` e o
 *           serve-state — nada de pool reconstruído (ver comentário no bloco).
 *
 * ─── O defeito de relógio que este script tem de contornar ─────────────────
 *
 * `src/api/brief.ts:645` filtra a população elegível com
 * `julianday('now') - julianday(COALESCE(source_date, created_at)) <= ?`.
 * O corte de idade usa o relógio do SQLite, NÃO o `nowMs` passado por
 * argumento. Consequência: o brief não é função pura de
 * (corpus, serve-state, nowMs) — a população elegível anda sozinha com o tempo
 * de parede. É a MESMA classe de defeito já documentada em três scripts de
 * medição, agora encontrada no código de PRODUÇÃO.
 *
 * O contorno é aritmético e exato, não é fake-clock: como o predicado é
 * `agora − data <= K`, o instante de corte é `agora − K`. Para reproduzir o
 * corte de `T_REF − K₀` basta usar `K = K₀ + (agora − T_REF)`. Mesmo predicado,
 * mesmo instante de corte. Aplicado aos DOIS knobs (`freshMaxAgeDays` e
 * `freshGlobalMaxAgeDays`), porque :809 e :845 sobrescrevem o primeiro pelo
 * segundo no sub-pool global.
 *
 * ─── Nada tem default ──────────────────────────────────────────────────────
 *
 * Corpus e serve-state são obrigatórios por caminho explícito. A lição é de
 * 27/08: a primeira remediação usou o DB vivo como corpus quando a produção
 * serve o snapshot de epoch, e o número saiu plausível e errado.
 *
 * Uso:
 *   node replay-oportunidade.mjs --modo ancora \
 *     --raiz /root/.openclaw/workspace/tools/nox-mem \
 *     --corpus /var/lib/nox-mem/epochs/e20260826T060003Z.db \
 *     --vivo   /root/.openclaw/workspace/tools/nox-mem/nox-mem.db \
 *     --t-ref  '2026-08-26T20:35:00Z' \
 *     --excluir-briefs sondas.txt
 */

import Database from "better-sqlite3";
import { createHash } from "node:crypto";
import { readFileSync, existsSync, mkdirSync, rmSync } from "node:fs";
import { join, resolve } from "node:path";
import { randomUUID } from "node:crypto";

// ─── args, todos explícitos ────────────────────────────────────────────────

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("--")) throw new Error(`argumento solto: ${a}`);
    const k = a.slice(2);
    if (["sem-assert","manter-tmp","so-churn"].includes(k)) { o[k] = true; continue; }
    const v = argv[++i];
    if (v === undefined || v.startsWith("--")) throw new Error(`--${k} sem valor`);
    if (k === "w") (o.w ??= []).push(Number(v));
    else o[k] = v;
  }
  return o;
}

const A = args(process.argv);
const exigir = (k) => {
  const v = A[k];
  if (v === undefined || v === "") {
    console.error(`FALTA --${k} (este script não tem default para nada)`);
    process.exit(2);
  }
  return v;
};

const MODO = exigir("modo");
if (!["ancora", "campo", "dose", "gaps", "porque", "canal"].includes(MODO)) {
  console.error(`--modo inválido: ${MODO}`); process.exit(2);
}
const RAIZ = resolve(exigir("raiz"));
const CORPUS = resolve(exigir("corpus"));
const VIVO = resolve(exigir("vivo"));
const CORTE = A.corte ?? "estrito";
if (!["estrito", "inclusivo", "rowid"].includes(CORTE)) {
  console.error(`--corte inválido: ${CORTE} (estrito|inclusivo|rowid)`); process.exit(2);
}
/**
 * ─── `--granularidade`: o teto é propriedade do algoritmo ou do FORMATO? ────
 *
 * O comparador é lexicográfico em `(last_served, −salience)` e o bônus só age
 * DENTRO de um empate da coordenada dominante (Proposição 1, modo `porque`).
 * Logo o teto de alcançabilidade não é função do comparador sozinho: é função
 * de quantos empates o formato de `served_at` produz. E a resolução de
 * `served_at` é herdada do `datetime('now')` do SQLite — ninguém a escolheu
 * como parâmetro de desenho.
 *
 * Truncar `served_at` é o contrafactual que separa as duas coisas. É
 * COARSENING: só funde estratos, nunca divide ⇒ o teto tem de ser monótono
 * não-decrescente em `seg → min → hora → dia`. Essa monotonia é o autoteste do
 * instrumento: se ela quebrar, o defeito é do script, não do achado.
 *
 * ⚠️ Truncar SEM repor os zeros seria um viés silencioso, não uma coarsening:
 * `"2026-08-28 10:52"` é PREFIXO de `"2026-08-28 10:52:12"`, e prefixo ordena
 * antes. Um estrato truncado passaria à frente de um não-truncado do mesmo
 * minuto em vez de empatar com ele. Por isso trunca-e-repõe.
 *
 * ⚠️ Aplicado DEPOIS do corte do serve-state, nunca antes: truncar primeiro
 * moveria linhas através do próprio corte.
 *
 * Cirúrgico por um fato verificado no fonte, não por suposição: `served_at`
 * tem UM consumidor vivo. O outro (`serveCounts`, janela de novelty-penalty)
 * está exportado e testado, mas **nenhum caminho de produção o chama** — é o
 * resto do mecanismo A, que o tune de 06-26 substituiu por cobertura
 * (`brief.ts:588`). Logo truncar não contamina contagem de janela nenhuma.
 */
const GRAN = A.granularidade ?? "seg";
const GRAN_LEN = { seg: 19, min: 16, hora: 13, dia: 10 }[GRAN];
if (GRAN_LEN === undefined) {
  console.error(`--granularidade inválida: ${GRAN} (seg|min|hora|dia)`); process.exit(2);
}
/** "2026-08-28 10:52:12" → "2026-08-28 10:52:00" (repõe, não encurta). */
const truncaPad = (s) => s.slice(0, GRAN_LEN) + "1970-01-01 00:00:00".slice(GRAN_LEN);

// ─── o que o dist tem de fornecer, e o que ele NÃO exporta ─────────────────

const DIST = join(RAIZ, "dist");
const brief = await import(join(DIST, "api", "brief.js"));
const div = await import(join(DIST, "api", "brief-diversity.js"));
const p2 = await import(join(DIST, "paper2", "brief-outcome.js"));

for (const [nome, v] of Object.entries({
  buildBriefDiverse: brief.buildBriefDiverse,
  fetchFreshCandidates: brief.fetchFreshCandidates,
  scopePatterns: brief.scopePatterns,
  DIVERSITY_DEFAULTS: div.DIVERSITY_DEFAULTS,
  boostsParaCandidatos: p2.boostsParaCandidatos,
  carregarDesignados: p2.carregarDesignados,
  P2_DELTA_CUT: p2.P2_DELTA_CUT,
})) if (v === undefined) { console.error(`dist não exporta ${nome}`); process.exit(2); }

/**
 * `GLOBAL_FRESH_PATTERNS`, `FRESH_CANDIDATE_POOL` e `interleaveFresh` NÃO são
 * exportados. Os dois primeiros são replicados aqui — e é exatamente o ponto
 * onde uma cópia silenciosamente desatualizada mentiria. Então não se confia na
 * cópia: extrai-se o literal do FONTE e compara-se. Guarda que só verifica
 * presença é decoração; esta compara valor e aborta.
 */
const FONTE = readFileSync(join(RAIZ, "src", "api", "brief.ts"), "utf8");

function literalDoFonte(re, rotulo) {
  const m = FONTE.match(re);
  if (!m) { console.error(`não achei ${rotulo} em src/api/brief.ts`); process.exit(2); }
  return m[1];
}
const PAT_FONTE = literalDoFonte(
  /const GLOBAL_FRESH_PATTERNS = (\[[^\]]*\]);/, "GLOBAL_FRESH_PATTERNS");
const GLOBAL_FRESH_PATTERNS = ["memory/entities/%", "memory/lessons.md"];
if (JSON.parse(PAT_FONTE.replace(/'/g, '"')).join("|") !== GLOBAL_FRESH_PATTERNS.join("|")) {
  console.error(`GLOBAL_FRESH_PATTERNS divergiu do fonte: ${PAT_FONTE}`);
  process.exit(2);
}
const POOL_FONTE = Number(literalDoFonte(
  /const FRESH_CANDIDATE_POOL = (\d+);/, "FRESH_CANDIDATE_POOL"));
const FRESH_CANDIDATE_POOL = 400;
if (POOL_FONTE !== FRESH_CANDIDATE_POOL) {
  console.error(`FRESH_CANDIDATE_POOL divergiu: fonte=${POOL_FONTE}`); process.exit(2);
}

/**
 * Auditoria do relógio: os três sítios de `'now'` no caminho do brief. Dois têm
 * de ficar INERTES no replay, e o terceiro é o que o offset corrige. Se o fonte
 * ganhar um quarto, isto acusa em vez de deixar passar.
 */
const SITIOS = FONTE.split("\n")
  .map((l, i) => [i + 1, l])
  .filter(([, l]) => /julianday\('now'\)|datetime\('now'/.test(l));
const ESPERADOS = new Set([293, 372, 571, 645]);
const inesperados = SITIOS.filter(([n]) => !ESPERADOS.has(n));
if (inesperados.length) {
  console.error("sítio de relógio NOVO no caminho do brief — replay não é fiel:");
  for (const [n, l] of inesperados) console.error(`  :${n} ${l.trim()}`);
  process.exit(2);
}

// ─── T_REF e o offset de idade ─────────────────────────────────────────────

function msDe(iso) {
  const t = Date.parse(iso.includes("T") ? iso : iso.replace(" ", "T") + "Z");
  if (Number.isNaN(t)) throw new Error(`instante inválido: ${iso}`);
  return t;
}

/** cfg com o corte de idade transladado para `tRefMs`. Ver cabeçalho. */
function cfgEm(tRefMs) {
  const base = { ...div.DIVERSITY_DEFAULTS, mode: "active" };
  const desloc = (Date.now() - tRefMs) / 86400000;
  if (desloc < 0) throw new Error("T_REF no futuro: o offset de idade só translada para trás");
  return {
    ...base,
    freshMaxAgeDays: base.freshMaxAgeDays + desloc,
    freshGlobalMaxAgeDays: base.freshGlobalMaxAgeDays + desloc,
    _offset_dias: desloc,
  };
}

// ─── sondas: exclusão por brief_id ENUMERADO, nunca por corte de tempo ─────

const SONDAS = (() => {
  const f = A["excluir-briefs"];
  if (!f) {
    console.error("FALTA --excluir-briefs <arquivo com um brief_id por linha>.");
    console.error("Passe um arquivo vazio para declarar 'nenhuma sonda a excluir'.");
    process.exit(2);
  }
  const ids = readFileSync(resolve(f), "utf8").split("\n")
    .map((s) => s.trim()).filter((s) => s && !s.startsWith("#"));
  const ruins = ids.filter((s) => !/^[0-9a-f-]{36}$/.test(s));
  if (ruins.length) { console.error(`brief_id malformado: ${ruins.join(", ")}`); process.exit(2); }
  return ids;
})();

/**
 * Serve-state derivado: só `brief_log`, só `served_at <= T_REF`, sem as sondas.
 * O corpus NUNCA é copiado nem escrito — é aberto readonly. `brief_log` não
 * pode sair do vivo (achado A3), e não há como filtrar dentro da query real,
 * então filtra-se a TABELA. Em /var/tmp, nunca /tmp: cópia descartável em tmpfs
 * come RAM.
 */
function serveStateDerivado(vivoRO, tRefMs, dir, idMax = null) {
  const p = join(dir, "serve-state.db");
  const d = new Database(p);
  d.exec(`CREATE TABLE brief_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chunk_id INTEGER NOT NULL,
            scope TEXT, agent TEXT,
            served_at TEXT NOT NULL DEFAULT (datetime('now')),
            brief_id TEXT);
          CREATE INDEX idx_brief_log_chunk ON brief_log(chunk_id, served_at);
          CREATE INDEX idx_brief_log_brief ON brief_log(brief_id);`);
  const corte = new Date(tRefMs).toISOString().slice(0, 19).replace("T", " ");
  const filtro = SONDAS.length
    ? ` AND (brief_id IS NULL OR brief_id NOT IN (${SONDAS.map(() => "?").join(",")}))`
    : "";
  /**
   * ⚠️ `served_at` tem resolução de SEGUNDO e cada brief insere ~10 linhas
   * DEPOIS de compor. Com `<=`, o serve-state de um brief contém as linhas que
   * ele mesmo acabou de servir (e as dos briefs irmãos do mesmo segundo — o cron
   * dispara 6 agentes em 1-2 s). Isso faz os chunks recém-servidos parecerem "já
   * servidos" e destrói justamente os estratos de `last_served` que o boost
   * desempata. `--corte estrito` (default) usa `<`, excluindo o segundo inteiro;
   * `inclusivo` usa `<=`. O preço do estrito é perder linhas gravadas ANTES no
   * mesmo segundo: com resolução de segundo não há corte exato, e a escolha tem
   * de ser declarada em vez de herdada.
   */
  const op = CORTE === "inclusivo" ? "<=" : "<";
  const linhas = idMax === null
    ? vivoRO.prepare(
        `SELECT id, chunk_id, scope, agent, served_at, brief_id FROM brief_log
          WHERE served_at ${op} ?${filtro}`,
      ).all(corte, ...SONDAS)
    : vivoRO.prepare(
        `SELECT id, chunk_id, scope, agent, served_at, brief_id FROM brief_log
          WHERE id < ?${filtro}`,
      ).all(idMax, ...SONDAS);
  const ins = d.prepare(
    "INSERT INTO brief_log (chunk_id, scope, agent, served_at, brief_id) VALUES (?,?,?,?,?)");
  d.transaction(() => {
    for (const l of linhas) ins.run(l.chunk_id, l.scope, l.agent, l.served_at, l.brief_id);
  })();
  /**
   * Coarsening, depois do corte. Com `--granularidade seg` isto TEM de ser
   * no-op byte a byte: é o teste de mutação do `truncaPad`, e ele roda em toda
   * execução, não só quando alguém lembra.
   */
  let reescritas = 0;
  let estratos;
  {
    const sel = d.prepare("SELECT id, served_at FROM brief_log");
    const upd = d.prepare("UPDATE brief_log SET served_at = ? WHERE id = ?");
    d.transaction(() => {
      for (const l of sel.all()) {
        const t = truncaPad(l.served_at);
        if (t !== l.served_at) { upd.run(t, l.id); reescritas++; }
      }
    })();
    if (GRAN === "seg" && reescritas > 0) {
      throw new Error(
        `truncaPad NÃO é identidade em granularidade nativa: reescreveu ${reescritas} ` +
        `linhas. O padding está errado e TODA granularidade grosseira estaria também.`);
    }
    estratos = {
      chunks_com_serve: d.prepare(
        "SELECT COUNT(*) c FROM (SELECT chunk_id FROM brief_log GROUP BY chunk_id)").get().c,
      estratos_distintos: d.prepare(
        "SELECT COUNT(DISTINCT m) c FROM (SELECT MAX(served_at) m FROM brief_log GROUP BY chunk_id)").get().c,
      maior_estrato: d.prepare(
        "SELECT MAX(c) c FROM (SELECT COUNT(*) c FROM (SELECT chunk_id, MAX(served_at) m FROM brief_log GROUP BY chunk_id) GROUP BY m)").get().c,
    };
  }
  const total = idMax === null
    ? vivoRO.prepare(`SELECT COUNT(*) c FROM brief_log WHERE served_at ${op} ?`).get(corte).c
    : vivoRO.prepare("SELECT COUNT(*) c FROM brief_log WHERE id < ?").get(idMax).c;
  return { db: d, path: p, linhas: linhas.length, descartadas: total - linhas.length,
           corte, op, idMax, granularidade: GRAN, linhas_reescritas: reescritas, ...estratos };
}

// ─── provedor de boost: replica brief.ts:957 ───────────────────────────────

/**
 * Produção monta o provedor em `src/api/brief.ts:957` com o handle VIVO (não o
 * corpus): `p2_verdict` e o gate de maturidade vivem no vivo. Aqui é igual, e o
 * acumulador da união das ≥2 invocações também — é o que prova o que o código
 * FEZ contra o que a regra DIZ.
 */
function provedorEm(vivoRO, w, tRefMs, env) {
  const inicio = p2.epochInicioMs(p2.epochInicioISO(tRefMs));
  const emitidos = new Map();
  const fn = (cands) => {
    const m = p2.boostsParaCandidatos(vivoRO, cands, w, inicio, env);
    for (const [id, b] of m) emitidos.set(id, b);
    return m;
  };
  return { fn, emitidos, inicioEpochMs: inicio };
}

// ─── execução ──────────────────────────────────────────────────────────────

/**
 * `/var/tmp`, nunca `/tmp`: cópia descartável de DB em tmpfs come RAM. `--tmp-base`
 * existe para o gatilho poder apontar para outro volume sem editar este arquivo.
 */
const TMP = join(A["tmp-base"] ?? "/var/tmp", `replay-oportunidade-${randomUUID()}`);
mkdirSync(TMP, { recursive: true });
const limpar = () => { if (!A["manter-tmp"]) try { rmSync(TMP, { recursive: true, force: true }); } catch {} };
process.on("exit", limpar);

const corpus = new Database(CORPUS, { readonly: true, fileMustExist: true });
const vivoRO = new Database(VIVO, { readonly: true, fileMustExist: true });
try {
  const sv = await import("sqlite-vec");
  sv.load(corpus);
} catch { /* FTS responde; o brief não usa o caminho semântico */ }

const ENV = {
  ...process.env,
  NOX_P2_DESIGNATION: A.designacao ? resolve(A.designacao) : process.env.NOX_P2_DESIGNATION,
  NOX_P2_DESIGNATION_SHA256: A["designacao-sha256"] ?? process.env.NOX_P2_DESIGNATION_SHA256,
};
const desig = p2.carregarDesignados(ENV);
if (!desig.ok) {
  console.error(`designação não carregou: ${desig.motivo ?? "?"} — sem ela o boost é vazio e o replay não mede nada`);
  process.exit(2);
}

const sha = (p) => createHash("sha256").update(readFileSync(p)).digest("hex");
const proc = {
  gerado_em: new Date().toISOString(),
  modo: MODO,
  corte_serve_state: CORTE,
  granularidade_last_served: GRAN,
  corpus: CORPUS,
  corpus_sha256_primeiros_1MB: createHash("sha256")
    .update(readFileSync(CORPUS).subarray(0, 1 << 20)).digest("hex"),
  vivo: VIVO,
  designacao: ENV.NOX_P2_DESIGNATION,
  designacao_sha256: ENV.NOX_P2_DESIGNATION && existsSync(ENV.NOX_P2_DESIGNATION)
    ? sha(ENV.NOX_P2_DESIGNATION) : null,
  designados: desig.ids.size,
  sondas_excluidas: SONDAS,
  fonte_brief_ts_sha256: createHash("sha256").update(FONTE).digest("hex"),
};

/** Composição do pool de cobertura GLOBAL pelo caminho real. */
function poolGlobal(tRefMs, serveDb, provedor) {
  const cfg = cfgEm(tRefMs);
  const pool = brief.fetchFreshCandidates(
    corpus, GLOBAL_FRESH_PATTERNS,
    { ...cfg, freshMaxAgeDays: cfg.freshGlobalMaxAgeDays },
    tRefMs, serveDb, provedor,
  );
  return { pool, cfg };
}

const estudo = new Set(vivoRO.prepare(
  `SELECT DISTINCT chunk_id FROM p2_verdict
    WHERE chunk_id IS NOT NULL AND severity IN ('S1','S2')`,
).all().map((r) => r.chunk_id));

const saida = { procedencia: proc };
let falhou = false;

if (MODO === "ancora") {
  const tRefMs = msDe(exigir("t-ref"));
  const sv = serveStateDerivado(vivoRO, tRefMs, TMP);
  const { pool, cfg } = poolGlobal(tRefMs, sv.db, undefined);
  /**
   * ⚠️ `ordenarCobertura` DESCARTA `lastServedMs` do objeto devolvido
   * (`({ lastServedMs: _drop, ...c })`), então a chave de estrato NÃO está no
   * pool retornado — agrupar por ela dá um grupo só, silenciosamente. A chave é
   * recuperada do serve-state com a MESMA query que o código usa (`MAX`), que é
   * também a chave que `measurement/gap-defs.mjs` usou na âncora publicada.
   */
  const ls = sv.db.prepare("SELECT MAX(served_at) m FROM brief_log WHERE chunk_id = ?");
  const chaveDe = new Map(pool.map((c) => [c.row.id, ls.get(c.row.id).m ?? null]));
  const grupos = new Set(pool.map((c) => String(chaveDe.get(c.row.id))));
  const obs = {
    t_ref: new Date(tRefMs).toISOString(),
    offset_idade_dias: cfg._offset_dias,
    serve_state: { linhas: sv.linhas, descartadas_por_sonda: sv.descartadas, corte: sv.corte },
    pool: pool.length,
    estudo_no_pool: pool.filter((c) => estudo.has(c.row.id)).length,
    grupos_last_served: grupos.size,
    nunca_servidos: pool.filter((c) => chaveDe.get(c.row.id) === null).length,
    posicao_primeiro_estudo: pool.findIndex((c) => estudo.has(c.row.id)),
  };
  /**
   * ⚠️ A âncora depende da configuração de sondas, e a tupla citada no
   * PROTOCOL-CALIBRATION-2026-08-27 ("pool 108, 55/55, 44 grupos,
   * nunca-servidos 0" + "sondas excluídas por brief_id") é INTERNAMENTE
   * INCONSISTENTE: `44 grupos` é a figura CONTAMINADA, que vem junto com
   * `posicao 3`. Descontaminada, a tabela de REMEDIATION-2026-08-27 §1 dá
   * `43 / 0`. Nenhuma configuração produz `44 / 0`.
   *
   * As duas colunas ficam aqui declaradas e a seleção é pela lista de exclusão,
   * não por escolha. Rodar os dois modos é o teste de que a harness é SENSÍVEL à
   * exclusão — se as duas configurações dessem o mesmo número, a exclusão seria
   * decoração.
   */
  const ANCORAS = {
    com_sondas: { pool: 108, estudo_no_pool: 55, grupos_last_served: 44, nunca_servidos: 0, posicao_primeiro_estudo: 3 },
    sem_sondas: { pool: 108, estudo_no_pool: 55, grupos_last_served: 43, nunca_servidos: 0, posicao_primeiro_estudo: 0 },
  };
  const ancora = SONDAS.length ? ANCORAS.sem_sondas : ANCORAS.com_sondas;
  obs.configuracao = SONDAS.length ? "sem_sondas" : "com_sondas";
  const diverge = Object.entries(ancora).filter(([k, v]) => obs[k] !== v);
  saida.ancora = { publicada: ancora, observada: obs, divergencias: Object.fromEntries(diverge) };
  if (diverge.length) {
    falhou = true;
    console.error("⚠️ ÂNCORA NÃO REPRODUZIDA pelo caminho real:");
    for (const [k, v] of diverge) console.error(`   ${k}: publicada=${v} observada=${obs[k]}`);
    console.error("   Isto é achado, não bug do script: a âncora foi medida sobre um pool");
    console.error("   REIMPLEMENTADO (measurement/gap-defs.mjs). Divergir é a diferença entre");
    console.error("   ordenação e seleção — exatamente o defeito que o item 1 existe para medir.");
  }
}

if (MODO === "campo" || MODO === "dose" || MODO === "porque" || MODO === "canal") {
  const LOG = resolve(exigir("log-campo"));
  const briefs = readFileSync(LOG, "utf8").split("\n").filter((l) => l.trim())
    .map((l) => JSON.parse(l))
    .filter((r) => r.tag === "p2_outcome" && r.ids_controle?.length === 10);
  const limite = A.limite ? Number(A.limite) : briefs.length;
  let alvo = A["so-churn"] ? briefs.filter((r) => r.churn > 0) : briefs;
  if (A["so-ts"]) {
    alvo = alvo.filter((r) => r.ts === A["so-ts"]);
    if (alvo.length === 0) { console.error(`nenhum brief com ts=${A["so-ts"]}`); process.exit(2); }
  }
  if (A["so-ts-file"]) {
    const set = new Set(readFileSync(resolve(A["so-ts-file"]), "utf8").split("\n")
      .map((x) => x.trim()).filter((x) => x && !x.startsWith("#")));
    const antes = alvo.length;
    alvo = alvo.filter((r) => set.has(r.ts));
    if (alvo.length !== set.size) {
      console.error(`⚠️ --so-ts-file lista ${set.size} ts mas ${alvo.length} casaram no log (de ${antes})`);
      process.exit(2);
    }
  }
  const doses = MODO === "dose" ? (A.w ?? [2, 100000]) : [null];

  /**
   * ─── Modo `canal`: ATRIBUIÇÃO diferencial, porque o log não a registra ────
   *
   * `brief_log` não tem coluna de origem, então "o chunk X foi servido" não diz
   * por qual canal. A revisão adversarial de 29/08 mostrou que isso derruba
   * tanto o guarda antigo quanto a explicação nova: os mesmos serves são
   * compatíveis com "a cobertura continuou servindo" e com "a cobertura parou e
   * o pool principal serviu tudo". Regra que exclui não atribui.
   *
   * O teste que decide não precisa de coluna nova: rodar o MESMO estado duas
   * vezes pelo código real, uma com `freshSlots` de produção e outra com
   * `freshSlots = 0`, e diferenciar. O que desaparece quando o canal é desligado
   * É, por construção, o que o canal entregou. Nada é reconstruído.
   *
   * ⚠️ Só vale se os dois braços forem idênticos em TUDO menos `freshSlots` —
   * mesmo corpus, mesmo serve-state podado, mesmo instante, sem boost nos dois.
   */

  /**
   * Um serve-state só, no T_REF MÁXIMO, e poda monótona descendo pelos briefs:
   * copiar 573 mil linhas por brief seria o custo dominante e não compraria nada.
   * A ordem decrescente torna cada poda um DELETE do que já não pode ser visto.
   */
  const ordenados = alvo.slice(0, limite).slice()
    .sort((a, b) => (a.ts < b.ts ? 1 : a.ts > b.ts ? -1 : 0));
  if (ordenados.length === 0) { console.error("nenhum brief selecionado"); process.exit(2); }
  /**
   * ⚠️ Corte `rowid`: a única regra EXATA disponível, e a razão de existir.
   * `served_at` tem resolução de segundo e o cron dispara 6 agentes dentro de
   * 1-2 s, então há estados verdadeiros — "depois do cipher, antes do forge, no
   * mesmo segundo" — que NENHUM corte temporal expressa. `brief_log.id` é
   * `AUTOINCREMENT`: é a ordem de inserção que o timestamp perdeu. O brief é
   * localizado no log por (agent, segundo, os 10 chunk_id que ele serviu) e o
   * corte passa a ser `id < min(id das próprias linhas)`.
   *
   * Se a identificação falhar (brief não achado, ou ambígua), cai para o corte
   * temporal declarado e MARCA a linha — nunca finge exatidão que não tem.
   */
  /**
   * Localização do brief no `brief_log` por GRUPO de `brief_id`, não por
   * contagem. A primeira versão exigia exatamente 10 linhas em
   * (agent, segundo) — e falhava em 31 de 350 porque o `nox` dispara DUAS vezes
   * no mesmo segundo (ex. 08:52:04.242 e .948): as 20 linhas das duas casavam e
   * a contagem rejeitava. Aqui agrupa-se por `brief_id` e escolhe-se o grupo
   * cujo conjunto de `chunk_id` é IGUAL a `ids_controle` — que é a assinatura do
   * brief, e é única.
   */
  const gruposNoSegundo = vivoRO.prepare(
    `SELECT brief_id, MIN(id) mi, GROUP_CONCAT(chunk_id) ids FROM brief_log
      WHERE served_at IN (?,?,?) AND COALESCE(agent,'') = ? AND brief_id IS NOT NULL
      GROUP BY brief_id`,
  );
  const idDoBrief = (r) => {
    if (r.ids_controle.length !== 10) return null;
    const seg = (dt) => new Date(dt).toISOString().slice(0, 19).replace("T", " ");
    const t = msDe(r.ts);
    const alvo = r.ids_controle.slice().sort((a, b) => a - b).join(",");
    const cands = gruposNoSegundo.all(seg(t), seg(t + 1000), seg(t + 2000), r.agent ?? "")
      .filter((g) => String(g.ids).split(",").map(Number).sort((a, b) => a - b).join(",") === alvo);
    return cands.length === 1 ? cands[0].mi : null;
  };

  const idMaxTopo = CORTE === "rowid" ? idDoBrief(ordenados[0]) : null;
  const sv = serveStateDerivado(vivoRO, msDe(ordenados[0].ts), TMP, idMaxTopo);
  /**
   * Estratos de `last_served` vêm do SERVE-STATE podado, nunca do banco vivo: o
   * vivo inclui serves POSTERIORES ao estado que se replica, e estrato errado
   * inverte a classificação inteira do modo `porque`.
   */
  const lsPorque = MODO === "porque"
    ? sv.db.prepare("SELECT MAX(served_at) m FROM brief_log WHERE chunk_id = ?")
    : null;
  const podar = sv.db.prepare(CORTE === "inclusivo"
    ? "DELETE FROM brief_log WHERE served_at > ?"
    : CORTE === "rowid"
      ? "DELETE FROM brief_log WHERE id >= ?"
      : "DELETE FROM brief_log WHERE served_at >= ?");

  const res = [];
  for (const r of ordenados) {
    const tRefMs = msDe(r.ts);
    let idProprio = null;
    if (CORTE === "rowid") {
      idProprio = idDoBrief(r);
      if (idProprio === null) {
        res.push({ ts: r.ts, agent: r.agent, erro: "brief não localizado no brief_log por (agent, segundo, 10 ids) — corte rowid impossível" });
        continue;
      }
      podar.run(idProprio);
    } else {
      podar.run(new Date(tRefMs).toISOString().slice(0, 19).replace("T", " "));
    }
    const params = { scope: r.scope, agent: r.agent ?? undefined, n: r.ids_controle.length, format: "json" };

    /**
     * ─── Modo `porque`: teste FALSIFICÁVEL da Proposição 1 do §5 ─────────────
     *
     * A proposição diz: o comparador é lexicográfico em `(last_served, −salience)`
     * e o bônus entra só na coordenada subordinada, logo ele permuta DENTRO de um
     * estrato de `last_served` e nunca atravessa estratos.
     *
     * Consequência DIRETAMENTE observável, sem reconstruir nada: em todo estado em
     * que o conjunto servido muda, cada id que ENTRA tem de compartilhar
     * `last_served` com algum id que SAI. Se um id entrar vindo de um estrato em
     * que ninguém saiu, a proposição está falsa.
     *
     * ⚠️ Esta é a SEGUNDA versão deste modo. A primeira classificava cada estado
     * pela posição do designado num pool que ELA MESMA montava (`poolGlobal` +
     * estratos + corte). Resultado: 25 "alcançáveis" contra 17 que de fato mexem,
     * e — decisivo — apenas 1 dos 17 caía na classe. `interleaveFresh` e
     * `FRESH_CANDIDATE_POOL` não são exportados, então aquele pool era uma
     * RECONSTRUÇÃO, e 24 violações do pressuposto de prefixo eram o sintoma. Testar
     * uma derivação sobre um pipeline reconstruído não testa nada — é a lição de
     * 27/08 aplicada ao próprio instrumento que ia verificá-la.
     *
     * Esta versão usa apenas `would_enter`, `would_leave` (que a produção registra)
     * e o `last_served` do serve-state podado. Nada é montado.
     */
    if (MODO === "canal") {
      const cfg = cfgEm(tRefMs);
      const params2 = { ...params };
      let comCob, semCob;
      try {
        comCob = brief.buildBriefDiverse(corpus, params2, cfg, tRefMs, sv.db, undefined);
        semCob = brief.buildBriefDiverse(
          corpus, params2, { ...cfg, freshSlots: 0 }, tRefMs, sv.db, undefined);
      } catch (e) {
        res.push({ ts: r.ts, agent: r.agent, erro: String(e && e.message || e) });
        continue;
      }
      const A_ = comCob.alt.items.map((i) => i.id);
      const B_ = semCob.alt.items.map((i) => i.id);
      const setB = new Set(B_);
      const daCobertura = A_.filter((id) => !setB.has(id));
      res.push({
        ts: r.ts, agent: r.agent,
        fresh_slots_producao: cfg.freshSlots,
        servido_com_cobertura: A_,
        servido_sem_cobertura: B_,
        atribuido_a_cobertura: daCobertura,
        n_atribuido: daCobertura.length,
      });
      continue;
    }
    if (MODO === "canal") {
    const ok = res.filter((x) => !x.erro);
    const lote = new Set((A["ids-lote"]
      ? readFileSync(resolve(A["ids-lote"]), "utf8").split(/\s+/).filter(Boolean).map(Number)
      : []));
    const atrib = ok.flatMap((x) => x.atribuido_a_cobertura);
    const uniq = [...new Set(atrib)];
    const doLote = uniq.filter((id) => lote.has(id));
    saida.canal = {
      estados: ok.length, erros: res.length - ok.length,
      fresh_slots: ok[0]?.fresh_slots_producao ?? null,
      slots_atribuidos_a_cobertura: atrib.length,
      chunks_distintos_da_cobertura: uniq.length,
      ids_da_cobertura: uniq.sort((a, b) => a - b),
      lote_declarado: lote.size,
      do_lote_atribuidos_a_cobertura: doLote.length,
      ids_do_lote_na_cobertura: doLote.sort((a, b) => a - b),
      /**
       * A pergunta que a refutação deixou em aberto, agora respondível: se ZERO
       * chunks do lote aparecem atribuídos à cobertura, então a cobertura PAROU
       * — e a predição original estava certa, com os serves observados vindo do
       * pool principal. Se aparecem, a cobertura seguiu servindo.
       */
      veredito: lote.size === 0 ? "sem --ids-lote, nada a concluir sobre o lote"
        : doLote.length === 0
          ? "COBERTURA PAROU para o lote — os serves observados vieram de outro canal"
          : "COBERTURA SEGUIU servindo o lote",
    };
    if (ok.length === 0) {
      falhou = true;
      console.error("⛔ nenhum estado replayado — nada a atribuir.");
    }
    // guarda: desligar o canal TEM de mudar alguma coisa em algum estado; se não
    // mudar em nenhum, ou `freshSlots` não é o knob, ou o pool está vazio, e nos
    // dois casos a atribuição não mediu o que diz medir.
    if (ok.length > 0 && atrib.length === 0) {
      console.error("⚠️ desligar freshSlots não mudou NENHUM estado. Ou o pool de");
      console.error("   cobertura está vazio nesses instantes, ou o knob não é esse.");
      console.error("   Zero aqui NÃO é 'a cobertura não serviu o lote' — é 'não medi'.");
      saida.canal.veredito = "NAO MEDIDO — desligar o canal não mudou nada em estado nenhum";
    }
    saida.canal.detalhe = res;
  } else if (MODO === "porque") {
      const cfg = cfgEm(tRefMs);
      const wAbs = A.w ? Number(A.w[0]) : 100000;
      const pv = provedorEm(vivoRO, wAbs, tRefMs, ENV);
      let out;
      try {
        out = brief.buildBriefDiverse(corpus, params, cfg, tRefMs, sv.db, pv.fn);
      } catch (e) {
        res.push({ ts: r.ts, agent: r.agent, erro: String(e && e.message || e) });
        continue;
      }
      const d = out.diffP2;
      const est = (id) => String(lsPorque.get(id).m ?? null);
      const entra = (d?.would_enter ?? []).map((id) => ({ id, estrato: est(id) }));
      const sai = (d?.would_leave ?? []).map((id) => ({ id, estrato: est(id) }));
      const estratosQueSaem = new Set(sai.map((x) => x.estrato));
      const semParceiro = entra.filter((x) => !estratosQueSaem.has(x.estrato));
      res.push({
        ts: r.ts, agent: r.agent, rowid_corte: idProprio, w: wAbs,
        churn: d ? d.churn : 0,
        entra, sai,
        /** Zero é o que a proposição exige. Qualquer valor > 0 a refuta. */
        entradas_sem_saida_no_mesmo_estrato: semParceiro.length,
        detalhe_violacao: semParceiro,
        boosts_emitidos: pv.emitidos.size,
      });
      continue;
    }

    for (const w of doses) {
      const dose = w ?? r.w;
      const pv = provedorEm(vivoRO, dose, tRefMs, ENV);
      let out;
      try {
        out = brief.buildBriefDiverse(corpus, params, cfgEm(tRefMs), tRefMs, sv.db, pv.fn);
      } catch (e) {
        res.push({ ts: r.ts, w: dose, erro: String(e && e.message || e) });
        continue;
      }
      const d = out.diffP2;
      const item = {
        ts: r.ts, agent: r.agent, w: dose,
        boosts_emitidos: pv.emitidos.size,
        rowid_corte: idProprio,
        churn: d ? d.churn : null,
        would_enter: d ? d.would_enter : null,
        would_leave: d ? d.would_leave : null,
      };
      /**
       * O conjunto de CONTROLE é gravado sempre, não só no modo `campo`. Motivo
       * concreto (28/08): no teste de granularidade, 3 estados deixam de mexer
       * ao engrossar o estrato, e sem o controle de cada granularidade não dá
       * para distinguir "o designado já entrou sozinho" de "o designado saiu de
       * contenção" — duas leituras opostas do mesmo churn=0.
       */
      item.ids_controle_replay = out.alt.items.map((i) => i.id);
      if (w === null) {
        item.producao = { churn: r.churn, would_enter: r.would_enter, would_leave: r.would_leave, boosts: Object.keys(r.boost_by_id).length };
        /**
         * Fidelidade do CONTROLE é pergunta ANTERIOR à do boost: se `alt` já
         * divergir de `ids_controle`, a divergência de churn é a jusante de um
         * defeito de replay, não evidência sobre o canal. Sem esta coluna, um
         * churn que bate por coincidência (controle errado + tratado errado)
         * passaria por fidelidade.
         */
        item.bate_controle =
          JSON.stringify(item.ids_controle_replay) === JSON.stringify(r.ids_controle);
        item.controle_producao = r.ids_controle;
        item.bate_churn = item.churn === r.churn;
        item.bate_entra = JSON.stringify((item.would_enter ?? []).slice().sort()) === JSON.stringify(r.would_enter.slice().sort());
      }
      res.push(item);
    }
  }
  sv.db.close();

  if (MODO === "canal") {
    const ok = res.filter((x) => !x.erro);
    const lote = new Set((A["ids-lote"]
      ? readFileSync(resolve(A["ids-lote"]), "utf8").split(/\s+/).filter(Boolean).map(Number)
      : []));
    const atrib = ok.flatMap((x) => x.atribuido_a_cobertura);
    const uniq = [...new Set(atrib)];
    const doLote = uniq.filter((id) => lote.has(id));
    saida.canal = {
      estados: ok.length, erros: res.length - ok.length,
      fresh_slots: ok[0]?.fresh_slots_producao ?? null,
      slots_atribuidos_a_cobertura: atrib.length,
      chunks_distintos_da_cobertura: uniq.length,
      ids_da_cobertura: uniq.sort((a, b) => a - b),
      lote_declarado: lote.size,
      do_lote_atribuidos_a_cobertura: doLote.length,
      ids_do_lote_na_cobertura: doLote.sort((a, b) => a - b),
      /**
       * A pergunta que a refutação deixou em aberto, agora respondível: se ZERO
       * chunks do lote aparecem atribuídos à cobertura, então a cobertura PAROU
       * — e a predição original estava certa, com os serves observados vindo do
       * pool principal. Se aparecem, a cobertura seguiu servindo.
       */
      veredito: lote.size === 0 ? "sem --ids-lote, nada a concluir sobre o lote"
        : doLote.length === 0
          ? "COBERTURA PAROU para o lote — os serves observados vieram de outro canal"
          : "COBERTURA SEGUIU servindo o lote",
    };
    if (ok.length === 0) {
      falhou = true;
      console.error("⛔ nenhum estado replayado — nada a atribuir.");
    }
    // guarda: desligar o canal TEM de mudar alguma coisa em algum estado; se não
    // mudar em nenhum, ou `freshSlots` não é o knob, ou o pool está vazio, e nos
    // dois casos a atribuição não mediu o que diz medir.
    if (ok.length > 0 && atrib.length === 0) {
      console.error("⚠️ desligar freshSlots não mudou NENHUM estado. Ou o pool de");
      console.error("   cobertura está vazio nesses instantes, ou o knob não é esse.");
      console.error("   Zero aqui NÃO é 'a cobertura não serviu o lote' — é 'não medi'.");
      saida.canal.veredito = "NAO MEDIDO — desligar o canal não mudou nada em estado nenhum";
    }
    saida.canal.detalhe = res;
  } else if (MODO === "porque") {
    const n = res.filter((x) => !x.erro).length;
    const comChurn = res.filter((x) => !x.erro && x.churn > 0);
    const viol = res.filter((x) => (x.entradas_sem_saida_no_mesmo_estrato ?? 0) > 0);
    saida.porque = {
      estados: n, erros: res.filter((x) => x.erro).length,
      w_absurdo: res.find((x) => x.w)?.w ?? null,
      estados_com_mudanca: comChurn.length,
      ids_que_entram: comChurn.reduce((a, x) => a + x.entra.length, 0),
      /**
       * O teste da Proposição 1. Zero é o que ela exige: toda entrada acontece
       * dentro de um estrato em que houve saída. Qualquer violação a refuta, e
       * nesse caso a derivação NÃO vai para o paper.
       */
      entradas_sem_saida_no_mesmo_estrato: viol.reduce(
        (a, x) => a + x.entradas_sem_saida_no_mesmo_estrato, 0),
      estados_violando: viol.length,
      proposicao_1_sobrevive: viol.length === 0,
      detalhe: res,
    };
    if (viol.length > 0) {
      falhou = true;
      console.error(`⛔ PROPOSIÇÃO 1 REFUTADA em ${viol.length} estados: id entrou vindo`);
      console.error("   de estrato onde ninguém saiu ⇒ o bônus atravessou estrato.");
    }
    } else if (MODO === "campo") {
    const n = res.filter((x) => !x.erro).length;
    const okC = res.filter((x) => x.bate_churn).length;
    const okE = res.filter((x) => x.bate_entra).length;
    saida.campo = {
      log: LOG, briefs_no_log: briefs.length, replayados: n,
      erros: res.filter((x) => x.erro).length,
      bate_churn: okC, bate_entra: okE,
      bate_controle: res.filter((x) => x.bate_controle).length,
      fidelidade_churn: n ? okC / n : null,
      detalhe: res,
    };
    if (n === 0 || okC !== n) {
      falhou = true;
      console.error(`⚠️ FIDELIDADE PARCIAL: ${okC}/${n} briefs reproduzem o churn da produção.`);
      console.error("   Sem 100% aqui, nenhum número derivado deste replay sustenta N, poder ou estimando.");
    }
  } else {
    const porW = new Map();
    for (const x of res) {
      if (x.erro) continue;
      const a = porW.get(x.w) ?? { w: x.w, estados: 0, mexeu: 0, churn_total: 0, boosts: 0 };
      a.estados++; a.churn_total += x.churn ?? 0; a.boosts = Math.max(a.boosts, x.boosts_emitidos);
      if ((x.churn ?? 0) > 0) a.mexeu++;
      porW.set(x.w, a);
    }
    const tab = [...porW.values()].sort((a, b) => a.w - b.w);
    saida.dose = { log: LOG, estados: alvo.slice(0, limite).length, tabela: tab, detalhe: res };
    const absurda = tab.filter((t) => t.w >= 100000);
    const moveu = absurda.some((t) => t.mexeu > 0);
    saida.dose.controle_positivo = {
      doses_absurdas: absurda.map((t) => t.w),
      mexeu_em_algum_estado: moveu,
      veredito: absurda.length === 0 ? "NÃO EXECUTADO — passe --w 100000"
        : moveu ? "PASSA — o canal existe e responde à dose"
        : "NO-GO — dose absurda não move nada; o canal não existe",
    };
    if (absurda.length && !moveu) {
      falhou = true;
      console.error("⛔ NO-GO: w >= 100.000 não movimentou nenhum estado.");
      console.error("   O comparador de cobertura é lexicográfico e `salience` é a coordenada");
      console.error("   subordinada: dose absurda sem efeito não é ruído, é prova de que o");
      console.error("   parâmetro não está na coordenada que decide. Isto é um RESULTADO.");
    }
  }
}

if (MODO === "gaps") {
  const tRefMs = msDe(exigir("t-ref"));
  /**
   * Obrigatório e sem default: o maior `w_min` é resultado do `--modo dose`, e um
   * default aqui seria exatamente o cache sem invalidação que este bloco documenta.
   */
  const W_MIN_MAX = Number(exigir("w-min-max"));
  if (!Number.isFinite(W_MIN_MAX) || W_MIN_MAX <= 0) {
    console.error("--w-min-max precisa ser um número positivo (vem do artefato de dose)");
    process.exit(2);
  }
  const agentes = exigir("agentes").split(",").map((x) => x.trim()).filter(Boolean);
  const sv = serveStateDerivado(vivoRO, tRefMs, TMP);
  const cfg = cfgEm(tRefMs);
  const ls = sv.db.prepare("SELECT MAX(served_at) m FROM brief_log WHERE chunk_id = ?");

  /**
   * Definição de par: **adjacentes DENTRO do estrato de `last_served` idêntico**. É a
   * única das três testadas em 27/08 que reproduz o `DELTA-CUT-MEASUREMENT-2026-08-26`
   * na 9ª decimal, e é a semanticamente certa: `salience` só decide dentro de empate.
   * As outras duas (adjacentes na ordenação global; todos os pares no estrato) ficam
   * fora de propósito — ver REMEDIATION-2026-08-27.md §2.
   */
  function censo(pool, soEstudo) {
    const chave = new Map(pool.map((c) => [c.row.id, ls.get(c.row.id).m ?? null]));
    const estratos = new Map();
    for (const c of pool) {
      const k = String(chave.get(c.row.id));
      if (!estratos.has(k)) estratos.set(k, []);
      estratos.get(k).push(c);
    }
    const gaps = [];
    let zeros = 0, pares = 0;
    for (let i = 0; i + 1 < pool.length; i++) {
      const a = pool[i], b = pool[i + 1];
      if (String(chave.get(a.row.id)) !== String(chave.get(b.row.id))) continue;
      if (soEstudo && !estudo.has(a.row.id) && !estudo.has(b.row.id)) continue;
      pares++;
      const d = Math.abs(a.salience - b.salience);
      if (d < 1e-12) zeros++; else gaps.push(d);
    }
    gaps.sort((x, y) => x - y);
    const q = (p) => (gaps.length ? gaps[Math.min(gaps.length - 1, Math.floor(p * gaps.length))] : null);
    return {
      pool: pool.length,
      estratos: estratos.size,
      nunca_servidos: pool.filter((c) => chave.get(c.row.id) === null).length,
      pares_no_estrato: pares,
      zeros,
      positivos: gaps.length,
      gap_min: gaps[0] ?? null,
      gap_p50: q(0.5),
      gap_p90: q(0.9),
      gap_max: gaps.at(-1) ?? null,
      /** `w` que vence o maior gap deste sub-pool, por severidade. */
      w_para_gap_max: gaps.length
        ? { S1: gaps.at(-1) / (p2.P2_DELTA_CUT * 0.5), S2: gaps.at(-1) / (p2.P2_DELTA_CUT * 1.0) }
        : null,
    };
  }

  const porAgente = {};
  for (const ag of agentes) {
    const pats = brief.scopePatterns("global", ag);
    const pl = brief.fetchFreshCandidates(corpus, pats, cfg, tRefMs, sv.db, undefined);
    porAgente[ag] = {
      patterns: pats,
      todos_os_pares: censo(pl, false),
      /**
       * ⚠️ Quando `pool` é 0 aqui, NÃO é que os patterns não casem: em
       * `T_REF = 2026-08-26 20:35Z` havia 265 (nox), 6.001 (cipher) e 3.011 (atlas)
       * chunks em `sessions/<agente>/%` passando o piso de importance, e **zero**
       * passando a janela de `freshMaxAgeDays = 7`. O sub-pool do agente está vazio
       * por IDADE. Consequência: `interleaveFresh([], global) === global`, e o canal
       * inteiro é o sub-pool global.
       */
    };
  }
  const poolG = brief.fetchFreshCandidates(
    corpus, GLOBAL_FRESH_PATTERNS,
    { ...cfg, freshMaxAgeDays: cfg.freshGlobalMaxAgeDays }, tRefMs, sv.db, undefined);
  const glob = {
    /**
     * DUAS colunas, e a distinção não é cosmética: `gap-defs.mjs` (de onde vem o
     * `0,031808734967844865` publicado) só conta pares em que ao menos um chunk é do
     * estudo. Mas o boost move o designado para além de quem estiver acima dele, seja
     * do estudo ou não — logo a coluna que limita o mecanismo é `todos_os_pares`.
     * Comparar a publicada com a não-filtrada seria comparar contagem filtrada com
     * não-filtrada, que é defeito conhecido desta linha de trabalho.
     */
    todos_os_pares: censo(poolG, false),
    so_pares_com_chunk_do_estudo: censo(poolG, true),
  };

  saida.gaps = {
    t_ref: new Date(tRefMs).toISOString(),
    offset_idade_dias: cfg._offset_dias,
    definicao_de_par: "adjacentes dentro do estrato de last_served idêntico",
    serve_state: { linhas: sv.linhas, corte: sv.corte, op: sv.op },
    sub_pool_global: glob,
    sub_pool_agente: porAgente,
    /**
     * O que este modo veio testar, e o veredito é NEGATIVO para a calibração do item 7.
     *
     * O gatilho foi calibrado com `0,031808734967844865` e margem 1,35x contra
     * `Δ_cut = 0,043`. Duas coisas o invalidam, e a segunda no nível da grandeza:
     *
     * 1. aquele máximo é da coluna FILTRADA (só pares com chunk do estudo). Sem filtro,
     *    no mesmo pool e no mesmo instante, o máximo é maior;
     * 2. e nenhuma das duas colunas limita o mecanismo, porque o boost precisa vencer a
     *    DISTÂNCIA até os 2 slots de cobertura, não o PASSO até o vizinho.
     *
     * ⚠️ A primeira versão deste bloco DIGITAVA `7.5` como o maior `w_min` observado, e
     * afirmava em prosa que "2 dos 17 estados só viram em w = 7,5". As duas coisas
     * ficaram FALSAS quando o grid fino (23 doses) mostrou máximo 4,4 — a coincidência
     * com o topo da banda registrada era resolução de grid, não achado. Era prosa
     * afirmando resultado calculado dentro do próprio instrumento que existe para
     * impedir isso. Agora o valor vem de `--w-min-max`, exigido por este modo, e o
     * artefato de dose é a única fonte dele.
     */
    calibracao_do_item_7: {
      gap_max_publicado_filtrado: 0.031808734967844865,
      gap_max_observado_filtrado: glob.so_pares_com_chunk_do_estudo.gap_max,
      gap_max_observado_sem_filtro: glob.todos_os_pares.gap_max,
      w_min_max_fonte: A["w-min-max"] ? "argumento --w-min-max" : null,
      w_min_max_observado: W_MIN_MAX,
      boost_S1_no_w_min_max: W_MIN_MAX * p2.P2_DELTA_CUT * 0.5,
      razao_boost_sobre_passo_adjacente: glob.todos_os_pares.gap_max
        ? (W_MIN_MAX * p2.P2_DELTA_CUT * 0.5) / glob.todos_os_pares.gap_max
        : null,
      passo_adjacente_cota_a_distancia:
        W_MIN_MAX * p2.P2_DELTA_CUT * 0.5 <= (glob.todos_os_pares.gap_max ?? 0),
    },
  };
  sv.db.close();
}

console.log(JSON.stringify(saida, null, 2));
if (A.out) {
  const fs = await import("node:fs");
  fs.writeFileSync(resolve(A.out), JSON.stringify(saida, null, 2) + "\n");
}
process.exit(falhou && !A["sem-assert"] ? 1 : 0);
