#!/usr/bin/env python3
"""Strip a Q4-comparison run output (runner.py format) down to what scoring needs.

The original per-query outputs written by `eval/q4-comparison/runner.py` carry
third-party text: the benchmark question (`query`) and the retrieved passage
(`results[].text`), both taken from LoCoMo (CC BY-NC 4.0) and LongMemEval (MIT).
This dataset is released under CC BY 4.0, so that text is removed. What remains is
enough to recompute every retrieval metric: question id, dataset, category labels,
gold chunk ids, retrieved chunk ids in rank order with their scores, latency, error.

Transform (deterministic, documented field by field):
  kept     meta (scanned: no absolute path, no host); question_id; dataset; category
           (the run-time label, as stored); gold_chunk_ids; k; latency_ms; error;
           results[].id; results[].score; results[].source;
           results[].sessoes_varridas / sessoes_com_erro (Zep run: sessions swept /
           failed per query); results[].topics_seen / retrieval_method (EverOS run:
           candidate hits returned by the service per query, retrieval mode)
  added    native_category: LoCoMo integer category or LongMemEval question_type,
           read from the dataset file by question_id (needed for §6.4);
           metrics: ndcg@10, recall@10, rr, computed with scripts/aggregate.py
  removed  query (question text); results[].text (passage text);
           results[].topic_name (EverOS-generated summary of the passage)

Anyone holding an original output and the two dataset files can re-run this
transform and compare the result byte for byte with the file in this dataset:

    python3 scripts/strip_outputs.py ORIGINAL.json OUT.json \
        --locomo locomo10.json --longmemeval longmemeval_oracle.json \
        --original-label eval/q4-comparison/output/rc4/nox_mem.json
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from aggregate import ndcg_at_k, recall_at_k, reciprocal_rank  # noqa: E402

K = 10
KEEP_Q = ("question_id", "dataset", "category", "gold_chunk_ids", "k")
KEEP_R = ("id", "score", "source", "sessoes_varridas", "sessoes_com_erro",
          "topics_seen", "retrieval_method")
DROP_R = ("text", "topic_name")
DROP_Q = ("query",)
FORBIDDEN = re.compile(r"(/Users/|/home/|/root/|[A-Za-z]:\\\\|\b\d{1,3}(\.\d{1,3}){3}\b|\.local\b|srv\d+)")


def native_maps(locomo: Path, lme: Path) -> tuple[dict[str, int], dict[str, str]]:
    loc = {}
    for s in json.loads(locomo.read_text(encoding="utf-8")):
        for i, qa in enumerate(s["qa"]):
            loc[f"{s['sample_id']}::q{i}"] = int(qa["category"])
    lm = {r["question_id"]: r["question_type"] for r in json.loads(lme.read_text(encoding="utf-8"))}
    return loc, lm


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def strip(payload: dict, loc: dict, lm: dict) -> dict:
    meta = payload["meta"]
    if FORBIDDEN.search(json.dumps(meta)):
        raise SystemExit(f"meta carries a path or host-like string: {meta}")
    out_q = []
    for q in payload["queries"]:
        unknown = set(q) - set(KEEP_Q) - set(DROP_Q) - {"results", "latency_ms", "error"}
        if unknown:
            raise SystemExit(f"unexpected query field(s) {unknown} in {q.get('question_id')}")
        r_out = []
        for r in q.get("results") or []:
            unk = set(r) - set(KEEP_R) - set(DROP_R)
            if unk:
                raise SystemExit(f"unexpected result field(s) {unk}")
            r_out.append({k: r[k] for k in KEEP_R if k in r})
        qid = q["question_id"]
        if q["dataset"] == "locomo":
            native = loc[qid]
        elif q["dataset"] == "longmemeval":
            native = lm[qid]
        else:
            raise SystemExit(f"unknown dataset {q['dataset']}")
        gold = set(q.get("gold_chunk_ids") or [])
        ids = [str(r.get("id") or "") for r in r_out]
        err = q.get("error")
        if err not in (None, "") and FORBIDDEN.search(str(err)):
            raise SystemExit(f"error string carries a path or host: {qid}")
        rec = {k: q[k] for k in KEEP_Q if k in q}
        rec["native_category"] = native
        rec["results"] = r_out
        rec["latency_ms"] = q.get("latency_ms")
        rec["error"] = err
        rec["metrics"] = {
            "ndcg@10": ndcg_at_k(ids, gold, K) if gold else None,
            "recall@10": recall_at_k(ids, gold, K) if gold else None,
            "rr": reciprocal_rank(ids, gold) if gold else None,
        }
        out_q.append(rec)
    return {"meta": meta, "queries": out_q}


def dump(obj: dict, stripped_from: dict) -> str:
    """One query per line: diff-friendly and deterministic."""
    head = json.dumps({"meta": obj["meta"], "stripped_from": stripped_from}, ensure_ascii=False)
    lines = ",\n".join(json.dumps(q, ensure_ascii=False) for q in obj["queries"])
    return head[:-1] + ', "queries": [\n' + lines + "\n]}\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("original")
    ap.add_argument("out")
    ap.add_argument("--locomo", required=True)
    ap.add_argument("--longmemeval", required=True)
    ap.add_argument("--original-label", required=True,
                    help="repository-relative path recorded in stripped_from.original_path")
    a = ap.parse_args()
    src = Path(a.original)
    loc, lm = native_maps(Path(a.locomo), Path(a.longmemeval))
    obj = strip(json.loads(src.read_text(encoding="utf-8")), loc, lm)
    sf = {"original_path": a.original_label, "original_sha256": sha256(src),
          "original_bytes": src.stat().st_size, "transform": "scripts/strip_outputs.py"}
    Path(a.out).write_text(dump(obj, sf), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
