# nox-mem Section 6 evidence: per-query outputs for the cross-system comparison

Version 1.0.0. DOI: [DOI withheld for review]

This record holds the per-query retrieval outputs behind Section 6 ("Cross-System
Comparison") of the technical report *nox-mem: Pain-Weighted Hybrid Memory for LLM Agents*,
version 1.0.6 (DOI `[DOI withheld for review]`; all versions: `[DOI withheld for review]`), together
with the scripts that score them. `verify_dataset.py` runs 135 checks of values printed in
Section 6 against the paper: 116 numbers recomputed from the files here alone (115 figures
and one run duration), 13 yes/no statements and 3 strings (two version pins and a
timestamp) read from them, and 3 differences recomputed from figures the paper prints for a
run whose outputs were not retained (X01 to X03). All 135 match version 1.0.6. The numbers that
per-query outputs cannot support are listed below, each with the reason. Version 1.0.6 corrected
the scorer, and versions up to 1.0.5 used the earlier rule; see *Scorer correction in report
version 1.0.6*.

The report is a preprint and has not been peer reviewed. The code that produced these runs is
at [repository withheld for review] (harness: `eval/q4-comparison/`).

The record contains no benchmark text. Questions and retrieved passages come from LoCoMo
(CC BY-NC 4.0) and LongMemEval (MIT), and they were removed from every output (see
*Licences and what was removed*). What remains is enough to score every run: question id,
dataset, category labels, gold chunk ids, retrieved chunk ids in rank order with their scores,
per-query latency and error.

---

## Quick start

```sh
unzip nox-mem-section6-evidence-1.0.0.zip
cd nox-mem-section6-evidence-1.0.0
python3 verify_dataset.py
```

Python 3.9 or later, standard library only. The script writes nothing. It exits 0 only if:

1. every file matches `SHA256SUMS` and no unlisted file is present;
2. the per-query metrics stored in each output equal the metrics recomputed from its ids,
   and each lies in [0, 1];
3. each shipped `_aggregate.json` is reproduced by `scripts/aggregate.py` from the stripped
   outputs, to 1e-12 (for the 2026-09-10 runs it is the aggregate the harness wrote at run
   time; for rc4 and its ablation it was regenerated with the corrected scorer);
4. each of the 135 Section 6 values, recomputed, equals the printed value at the
   printed precision (yes/no statements and strings exactly).

It prints one row per number (id, section, quantity, paper value, recomputed value, status),
followed by the list of numbers it cannot recompute. With
`--manuscript path/to/paper-tecnico-nox-mem.md` it also checks that the sentence or table row
each number is quoted from occurs verbatim in Section 6 of that file, and prints the version the
file declares. Use the source of version 1.0.6; the source of 1.0.5 fails the quote check on
the values the correction changed. The manuscript source is in the code repository under
`paper/`.

The check fails when the data change. Three mutations were tried on a copy before release.
Changing one digit of one score fails the `SHA256SUMS` check. Replacing one retrieved id (with
that query's stored metrics and `SHA256SUMS` regenerated to match) fails the aggregate check and
the Section 6 cells it touches, among them the §6.3.2 LoCoMo cell (R03: 0.4947 against the
printed 0.4952). Putting back the scorer used up to report version 1.0.5 (with `SHA256SUMS`
regenerated) fails the stored metrics of the 3 affected queries in both Mem0 files, which then
score above 1, the two rc4 aggregates, and checks R17, A05 and E10.

---

## Runs

| directory | run | systems | n | backs (paper) |
|---|---|---|---:|---|
| `runs/smoke-2026-05/` | superseded smoke runs, 2026-05-23 to 2026-05-25 | nox-mem, Mem0 (500-chunk cap), Zep | 20 each | §6.3 "Preliminary smoke", §6.3.1 (Zep smoke), §6.6 (capped smoke, Mem0 half), §6.7 |
| `runs/rc4-2026-06-29/` | rc4, embedding-matched (both arms on `gemini-embedding-001`, 3072 d) | nox-mem, Mem0 | 2,482 each | §6.3.2 table and confounds (a), (c), (e); §6.3.3 and §6.3.4 nox-mem and Mem0 rows; §6.4 table |
| `runs/rc4-ablation-2026-06-29/` | task-type ablation (nox-mem with a generic Gemini embedding; same Mem0 baseline) | nox-mem, Mem0 | 2,482 each | §6.3.2 "Task-type ablation"; §6.4 ablation figures; §6.5 principle 5 |
| `runs/2026-09-10/` | EverOS 1.3.1 and Zep 0.27.2 on the rc4 corpus and query set | EverOS, Zep | 2,482 each | §6.3.3, §6.3.4, §6.3.1 (EverOS hit count) |

**The canonical 2026-06-15 run is not here.** Its per-query outputs were not retained when the
benchmark pod was terminated, as §6.3 states. Its tables (n = 100 per dataset) cannot be
rescored from any artifact, and this record does not try. `verify_dataset.py` checks only the
arithmetic of the three deltas printed with them (X01 to X03).

The `mem0.json` of the ablation directory is the rc4 Mem0 output itself: both originals have
the same sha256 (`20fbe5eb…`), and the ablation compared the re-run nox-mem arm against it. It
is shipped in both directories so that each directory can be aggregated on its own.

---

## Files

| path | what it is |
|---|---|
| `README.md` | this file |
| `LICENSE.txt` | licence notice (CC BY 4.0) and the third-party note |
| `SHA256SUMS` | SHA-256 of every other file |
| `verify_dataset.py` | checks the 135 Section 6 values against the paper (see *Quick start*) |
| `runs/<run>/<system>.json` | stripped per-query outputs, one query per line (format below) |
| `runs/<run>/_aggregate.json`, `_aggregate.md` | the harness's aggregate: for `2026-09-10/`, the file written at run time, copied verbatim; for the two rc4 directories, regenerated from the original outputs with the corrected scorer (the run-time files are not shipped; their sha256 is in `PROVENANCE.json`, and only their Mem0 rows differ) |
| `corpus/offered_corpus_ids.tsv` | the 6,830 documents offered to every system, as `line, source_file, id`; 6,822 distinct ids, 8 of them naming two documents |
| `corpus/rc4-nox-hybrid.eval_chunks.ids.txt` | ids held by the nox-mem store of rc4 (6,822 rows), in insertion order |
| `corpus/rc4-nox-generic.eval_chunks.ids.txt` | ids held by the nox-mem store of the ablation (6,791 rows) |
| `corpus/rc4-mem0-chroma.rows.tsv` | one row per row of the preserved Mem0 Chroma store of rc4: row id, `created_at` (UTC), `chunk_id`, and whether the row carries a `text_lemmatized` metadata key |
| `evidence/rc4-run.redacted.log` | console log of the rc4 run (both arms) |
| `evidence/rc4-ablation-run.redacted.log` | console log of the ablation run |
| `PROVENANCE.json` | for each file: original repository path, original sha256 and size, whether the original is in the public code repository, and the transform applied; sha256 of the dataset source files |
| `MANIFESTO-LASTRO.json` | the repository's integrity manifest of the unversioned artifacts the paper cites (keys in Portuguese: `secao` section, `mede` what is measured, `estado` state), copied verbatim |
| `scripts/aggregate.py` | the harness's scorer (nDCG@10 binary relevance, R@10, MRR, latency percentiles), identical to `eval/q4-comparison/aggregate.py` in the repository as of report version 1.0.6 |
| `scripts/category_labeler.py` | the run-time category labeler, verbatim |
| `scripts/recompute-rc4-categories.repo-original.py` | the repository script that produced the §6.4 table, verbatim as of report version 1.0.6 (it reads repository paths; `verify_dataset.py` does the same computation on this record's files) |
| `scripts/strip_outputs.py` | the transform that produced `runs/` from the original outputs |

The two `.ids.txt` files and `rc4-mem0-chroma.rows.tsv` are id-only extracts of three SQLite
stores whose sha256 is recorded in `MANIFESTO-LASTRO.json` and `PROVENANCE.json`. Text, vectors
and lemmatized text were removed. The stores were read from byte-identical copies opened
immutable, and each copy's sha256 was checked against the manifest before and after the read.

The two logs are copies in which absolute local paths were replaced by `<repo>/` and
`<home>/`; nothing else was changed. The rc4 log is also in the code repository, unredacted
(`eval/q4-comparison/output/rc4-run.log`).

### Output format

Each `runs/<run>/<system>.json` is one JSON object, `{"meta": …, "stripped_from": …,
"queries": [ … ]}`, written with one query per line. `meta` is the run's own metadata,
unchanged. `stripped_from` names the original file and its sha256. Each query:

| field | meaning |
|---|---|
| `question_id` | LoCoMo `<sample_id>::q<index>` or LongMemEval `question_id` |
| `dataset` | `locomo` or `longmemeval` |
| `category` | the bucket label the harness wrote at run time (see the §6.4 note below) |
| `native_category` | LoCoMo's integer `category` (1 to 5) or LongMemEval's `question_type`, read from the dataset by question id |
| `gold_chunk_ids` | ids of the relevant chunks |
| `k` | 10 |
| `results` | retrieved items in rank order: `id`, `score`, `source`; Zep adds `sessoes_varridas` and `sessoes_com_erro` (sessions swept and sessions failed for that query; Portuguese field names kept as written by the harness); EverOS adds `topics_seen` (hits the service returned before truncation to k) and `retrieval_method` |
| `latency_ms` | wall clock around the adapter call |
| `error` | `null`, or the adapter's error |
| `metrics` | `ndcg@10`, `recall@10`, `rr` for this query, computed with `scripts/aggregate.py` |

`scripts/aggregate.py` reads these files unchanged. It writes `_aggregate.json` and
`_aggregate.md` into the directory it reads, so run it on a copy:

```sh
cp -r runs/rc4-2026-06-29 /tmp/rc4 && python3 scripts/aggregate.py --output-dir /tmp/rc4 --k 10
```

---

## Conventions used to compare with the paper

- A recomputed value is rounded half-up to the number of decimals the paper prints. Counts
  must match exactly.
- 95% intervals in §6.3.2 are `1.96 · SD / sqrt(n)` with the sample standard deviation
  (n − 1) of per-query nDCG@10. With the population SD the printed values are the same.
- **Two rounding paths appear in the paper, and each is checked by the path it used.** The
  §6.3.2, §6.3.3 and §6.3.4 differences (R17, R18, E13 to E15, Z08, A02) are differences of the
  printed four-decimal values. The §6.4 Δ column (C04, C09, C14, C19, C24) uses the unrounded
  means. They disagree in two places, both rounding ties at the third decimal:
  - §6.3.2 LoCoMo, printed **+0.055**: 0.4952 − 0.4407 = 0.0545, which rounds half-up to 0.055;
    the unrounded difference is 0.05446, which rounds to 0.054.
  - §6.4 single-hop, printed **+0.031**: the unrounded difference is 0.031499, which rounds to
    0.031; the printed values give 0.5922 − 0.5607 = 0.0315, which would round
    to 0.032.

  Neither changes a sign or an ordering.
- §6.4 buckets LoCoMo questions by their native integer category with the map the paper
  declares (1 multi-hop, 2 temporal, 3 open-domain, 4 single-hop, 5 adversarial) and keeps the
  LongMemEval map of `scripts/category_labeler.py`. The `category` field stored in the outputs,
  and the `_aggregate.md` files beside them, use the run-time map, which permutes LoCoMo's
  categories 1 to 4. The paper says so (§6.4, correction v1.0.3), and check C31 confirms that
  every stored LoCoMo label equals the run-time map applied to the native category, so the
  join by question id is the right one.
- "Gold-hit" (§6.3, §6.7) is the number of queries with at least one gold id in the top 10.
- Mem0's store at query time (R28 to R30) is the set of Chroma rows with `created_at` at or
  before the Mem0 arm's `meta.finished_at` (2026-06-29T14:57:04Z). Four rows were written at
  15:02 UTC, and their ids are the four ids of the 503 ingest errors in the run log (R32).

---

## Scorer correction in report version 1.0.6

Report versions up to 1.0.5 were scored with a `scripts/aggregate.py` that gave a relevant id
its gain at every rank where it appeared in the top 10, and recall@10 counted those occurrences.
A top 10 holding one relevant id twice could therefore score above 1. This happened only in the
rc4 Mem0 output (shared by the ablation directory): 20 of its 2,482 queries hold one id twice in
the top 10, all of them LongMemEval queries and each repeated id one of the 8 ids that name two
offered documents (Mem0 kept both documents of each pair, §6.3.2 (e)). In 3 of them the repeated
id is gold: `07741c44` and `07741c45` scored nDCG@10 1.5706 with recall@10 2.0, and `2ebe6c90`
scored 0.7479 with recall@10 1.5. No other output in this record repeats an id.

The scorer now cuts the retrieved list to the top 10 and credits each id once, at the rank of
its first occurrence. A later repeat keeps its slot and is not relevant, so the item at rank 11
never moves up. Under this rule the three queries score 0.9197, 0.9197 and 0.4838, each with
recall@10 1.0. MRR cannot change, since the first relevant occurrence is always a first
occurrence. Report version 1.0.6 prints the values this rule gives, and this record checks them:

| check | quantity | 1.0.5 (earlier rule) | 1.0.6 |
|---|---|---:|---:|
| R07 | rc4 Mem0 LongMemEval nDCG@10 | 0.4061 | 0.4030 |
| R08 | its 95% half-width | 0.036 | 0.035 |
| R11, A05 | rc4 Mem0 overall nDCG@10 | 0.4337 | 0.4331 |
| R17 | LongMemEval difference, nox-mem minus Mem0 | +0.119 | +0.123 |
| E10 | rc4 Mem0 R@10 | 0.5852 | 0.5842 |
| C13 | §6.4 temporal, Mem0 | 0.4570 | 0.4565 |
| C14 | §6.4 temporal difference | +0.093 | +0.094 |
| C18 | §6.4 adversarial, Mem0 | 0.2955 | 0.2930 |
| C19 | §6.4 adversarial difference | +0.142 | +0.144 |

Every change lowers Mem0, the comparison arm. No nox-mem, EverOS or Zep value changes, nor any
LoCoMo value, MRR or latency, and no ordering, sign or yes/no check changes. Version 1.0.6 also
rewrites the §6.3.2 (e) sentence that said scoring by id meant "a collision cannot mis-score a
retrieval", and replaces the 1.0.5 sentence "The per-query outputs are not distributed" with a
pointer to this record. The unstripped originals of rc4 and of the ablation remain
undistributed.

In this record the correction touches `scripts/aggregate.py`, the stored metrics of the 3 queries
in both `mem0.json` files, the two rc4 `_aggregate.*` pairs, the paper values in
`verify_dataset.py`, and the §6.4 script copy. The 2026-09-10 aggregate regenerated under the
new rule is byte-identical to the run-time file shipped here.

---

## What this record cannot recompute

These Section 6 numbers are not backed by any output here. `verify_dataset.py` prints the same
12 groups.

| § | numbers | why not |
|---|---|---|
| 6.3 | canonical 2026-06-15 tables (nox-mem, Mem0, agentmemory, both datasets); raw-union 0.4173; 14.6% off-dataset; Mem0 LoCoMo coverage ~95% | per-query outputs not retained when the pod was terminated; only the arithmetic of the printed deltas is checked (X01 to X03) |
| 6.6 | nox-mem capped smoke: 0.0466 FTS5-only, 0.0918 hybrid, 0.1835 LoCoMo-only | that run's output file was overwritten in place by the 2026-05-24 full-corpus smoke, which is the file shipped here (S01); the Mem0 half is recomputed (S07 to S09) |
| 6.3.1 | EverOS index: 6,822 documents retained, 4 `DuplicateDocumentError`, no id missing, no failed write is a gold document | counted on the live EverOS store after its final sync; that store is not in this record. The offered side (6,830 documents, 6,822 ids, 8 colliding ids) is recomputed (R24 to R26) |
| 6.3.1 | EverOS `rerank_n = 50`, `top_k_cap = 100` | service configuration; E18 recomputes its observable consequence, 50 hits on every one of the 2,482 queries |
| 6.3.2 (a) | mem0ai 2.0.10 at run time; the two 2.x strings absent from the 0.1.114 source distribution (positive controls in 23 and 21 files); 2.0.10 rejecting the 0.1.x call shape | needs the PyPI source distributions of mem0ai 0.1.114 and 2.0.10, which are not redistributed here. The two run-side strings are recomputed: the warning in the run log (R37) and `text_lemmatized` on 6,830 of 6,830 store rows (R36) |
| 6.3.2 (c) | the query affected by the four back-filled chunks misses its gold even when the chunk is present; zero aggregate effect | needs a re-query with the chunk present; R40 recomputes that exactly one query is affected |
| 6.3.2 (e) | EverOS also retained 6,822 (a different run, cited as an external datum) | same store as the 6.3.1 EverOS index row |
| 6.3.3 | §5.1.7 cross-encoder figures, 22 M vs 4 B parameters ("180-fold") | Section 5 measurements and model cards |
| 6.3.3, 6.3.4 | standalone nox-mem hybrid p50 529 and ~940 ms | Section 5 measurements (§5.7) |
| 6.3.4 | 46 distinct sessions among the 47 failures; 35 timeouts, 8 OpenAI 500s, 4 `Bad file descriptor` | the outputs record how many sessions failed per query (Z16 = 47) but not which session or why; the breakdown was classified on the run's console log, which is in neither the code repository nor this record |
| 6.8 | Table 2 (services, mandatory keys) | read from each project's source and documentation |
| 6.9 | Mem0 PID-limit exhaustion (three times), ~5% LoCoMo vectors lost, Letta ~16 min/query | operational observations on the canonical pod, with no archived artifact |

---

## Further observations from these files

Recorded here so that a reader of the files does not have to find them alone. Only the first
is also stated in the paper.

- **Ablation run log.** `evidence/rc4-ablation-run.redacted.log` records 5 embedding errors
  (504) at ingest and 33 dense-search errors (504) at query time. On a dense-search error the
  adapter fuses the FTS5 list alone for that pass (`eval/q4-comparison/adapters/nox_mem.py`);
  the log does not say which queries were affected. The ablation store holds 6,791 of the
  6,822 ids; its gold coverage, 99.03%, is what the paper declares (A08, A09). Report version
  1.0.6 states the coverage and the 33 query-time errors in §6.3.2, and says that for this reason
  the ablation's 0.34 pp difference does not isolate or bound the task-type contribution.
- **Zep per-query failures.** Of the 2,482 queries, 2,437 lost no session, 43 lost one and 2
  lost two (47 in total, Z16). The adapter's default abort threshold is 1% of the sessions
  swept (`ZEP_MAX_ERRO_SESSAO`, default 0.01, i.e. more than 5.1 of 510); the run's `meta` does
  not record the value in force.
- **Version fields.** The nox-mem `meta.version` of every run reads
  `git-sha (resolve at runtime via git rev-parse HEAD)`: the placeholder was never resolved, so
  the nox-mem code version of these runs is not recorded in the outputs. The Mem0 `meta.version`
  of rc4 (`mem0ai==0.1.114`) is the adapter's declared pin, which §6.3.2 (a) discusses. The
  EverOS `meta` records no model, dimension or reranker (§6.3.3 (c)).

---

## Licences and what was removed

LoCoMo is released under CC BY-NC 4.0 (https://github.com/snap-research/locomo, `LICENSE.txt`)
and LongMemEval under MIT (https://github.com/xiaowu0162/LongMemEval; the dataset card of
`xiaowu0162/longmemeval-cleaned` on Hugging Face also declares MIT). A CC BY 4.0 record cannot
carry LoCoMo text, which may not be used commercially, so no text from either dataset is
included. From each original output, `scripts/strip_outputs.py` removed:

- `query`, the question text;
- `results[].text`, the retrieved passage;
- `results[].topic_name` (EverOS only), a short summary EverOS generated from the passage.

It added `native_category` and `metrics`, and it rejects an output whose `meta` or error
strings carry an absolute path or a host-like string. Every other field is kept as written.

The datasets' identifiers and category labels stay, because scoring needs them. To read a
question or a passage, obtain the datasets from their authors. The two files the harness read
are byte-identical to the upstream releases:

| file | sha256 | source |
|---|---|---|
| `locomo10.json` | `79fa87e90f04081343b8c8debecb80a9a6842b76a7aa537dc9fdf651ea698ff4` | `data/locomo10.json` in `snap-research/locomo` |
| `longmemeval_oracle.json` | `821a2034d219ab45846873dd14c14f12cfe7776e73527a483f9dac095d38620c` | `longmemeval_oracle.json` in `xiaowu0162/longmemeval-cleaned` |

Holders of an original output can check the strip. Run

```sh
python3 scripts/strip_outputs.py ORIGINAL.json OUT.json \
  --locomo locomo10.json --longmemeval longmemeval_oracle.json \
  --original-label <repository path from PROVENANCE.json>
```

and compare `OUT.json` with the shipped file byte for byte. The originals of the smoke runs and
of the 2026-09-10 runs are in the public code repository (`PROVENANCE.json`,
`versioned_in_github_repo: true`). Re-stripping `eval/q4-comparison/output-2026-09-10/zep.json`
with the upstream dataset files gives a byte-identical `runs/2026-09-10/zep.json`. The rc4 and
ablation originals are not in the repository (its `.gitignore` excludes run outputs as too
large to commit); their sha256 is in `MANIFESTO-LASTRO.json` and `PROVENANCE.json`.

This record is released under CC BY 4.0 (`LICENSE.txt`). The Python scripts are also available
under MIT in the code repository.

---

## Citation

[Author] (2026). *nox-mem Section 6 evidence: per-query outputs for the cross-system
comparison* (Version 1.0.0) [Data set]. [data repository]. [DOI withheld for review]

It supplements: [Author] (2026). *nox-mem: Pain-Weighted Hybrid Memory for LLM Agents*
(Version 1.0.6). [data repository]. [DOI withheld for review]
