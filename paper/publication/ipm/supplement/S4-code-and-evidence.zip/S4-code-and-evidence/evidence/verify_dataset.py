#!/usr/bin/env python3
"""Recompute, from this dataset alone, every Section 6 number of the nox-mem paper
that per-query outputs can support, and compare it with the printed value.

    python3 verify_dataset.py                     # checks files + numbers
    python3 verify_dataset.py --manuscript PATH   # also checks that every quoted
                                                  # paper string occurs in §6 of PATH

The printed values in the table below are those of paper version 1.0.6
(DOI [DOI withheld for review]). Scoring rule (scripts/aggregate.py): cut the retrieved
list to the top 10, then credit each id once, at the rank of its first occurrence; a
later repeat keeps its slot and is not relevant, and the list is not re-padded. Paper
versions up to 1.0.5 were scored with a rule that credited a repeated relevant id at
every occurrence. That changed nine printed values (all Mem0 scores or margins against
Mem0); see README, "Scorer correction in paper version 1.0.6".

Exit 0 only if (1) every file listed in SHA256SUMS matches and no unlisted file is
present, (2) the stored per-query metrics equal the recomputed ones and lie in [0, 1],
(3) each shipped _aggregate.json is reproduced by scripts/aggregate.py from the
stripped outputs, and (4) every number in the table below equals the paper's printed
value at the paper's printed precision. Numbers that per-query outputs cannot support
are listed at the end with the reason; they do not affect the exit code.

The 135 checks are 119 numeric values (115 numbers and one run duration recomputed from
the files, and X01-X03, three differences recomputed from figures the paper prints for a
run whose outputs were not retained), 13 yes/no statements and 3 strings (two version
pins and a timestamp).

With --manuscript, the version the manuscript declares is printed next to the version
these values come from; a different version is reported, and the quote check decides.

Standard library only (Python >= 3.9). Nothing is written to disk.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE / "scripts"))
from aggregate import ndcg_at_k, recall_at_k, reciprocal_rank, score_system  # noqa: E402

K = 10
PAPER_VERSION = "v1.0.6"
RUNS = HERE / "runs"
OLD_MAP = {1: "single-hop", 2: "multi-hop", 3: "temporal", 4: "open-domain", 5: "adversarial"}
DECLARED_MAP = {1: "multi-hop", 2: "temporal", 3: "open-domain", 4: "single-hop", 5: "adversarial"}
CATS = ("single-hop", "multi-hop", "temporal", "adversarial", "open-domain")

failures: list[str] = []


def fail(msg: str) -> None:
    failures.append(msg)


# ----------------------------------------------------------------------------- files
def check_sums() -> int:
    sums = HERE / "SHA256SUMS"
    if not sums.exists():
        fail("SHA256SUMS missing")
        return 0
    listed = {}
    for line in sums.read_text().splitlines():
        if line.strip():
            h, name = line.split(None, 1)
            listed[name.strip()] = h
    for name, h in listed.items():
        p = HERE / name
        if not p.is_file():
            fail(f"SHA256SUMS lists {name}, which is absent")
            continue
        if hashlib.sha256(p.read_bytes()).hexdigest() != h:
            fail(f"sha256 mismatch: {name}")
    present = {str(p.relative_to(HERE)) for p in HERE.rglob("*") if p.is_file()
               and "__pycache__" not in p.parts and p.name != ".DS_Store"}
    extra = present - set(listed) - {"SHA256SUMS"}
    if extra:
        fail(f"files not listed in SHA256SUMS: {sorted(extra)}")
    return len(listed)


def load(run: str, name: str) -> dict:
    return json.loads((RUNS / run / name).read_text(encoding="utf-8"))


def ids(q: dict) -> list[str]:
    return [str(r.get("id") or "") for r in q.get("results") or []]


def check_stored_metrics(payload: dict, label: str) -> int:
    n = 0
    for q in payload["queries"]:
        gold = set(q.get("gold_chunk_ids") or [])
        if not gold:
            continue
        got = (ndcg_at_k(ids(q), gold, K), recall_at_k(ids(q), gold, K), reciprocal_rank(ids(q), gold))
        m = q["metrics"]
        if (m["ndcg@10"], m["recall@10"], m["rr"]) != got:
            fail(f"{label} {q['question_id']}: stored per-query metrics differ from recomputed")
        if not all(0.0 <= x <= 1.0 for x in got):
            fail(f"{label} {q['question_id']}: a per-query metric lies outside [0, 1]: {got}")
        n += 1
    return n


def repeats(payload: dict) -> tuple[int, int]:
    """Queries whose top 10 holds one id twice, and how many of them repeat a gold id."""
    rep = [q for q in payload["queries"] if len(ids(q)[:K]) != len(set(ids(q)[:K]))]
    return len(rep), sum(1 for q in rep if any(ids(q)[:K].count(g) > 1 for g in q["gold_chunk_ids"]))


def close(a, b, path: str, label: str) -> None:
    if isinstance(a, dict):
        for k in a:
            if k in ("version",):
                continue
            if k not in b:
                fail(f"{label}: {path}.{k} missing in recomputed aggregate")
                continue
            close(a[k], b[k], f"{path}.{k}", label)
    elif isinstance(a, float) or isinstance(b, float):
        if not math.isclose(float(a), float(b), rel_tol=0, abs_tol=1e-12):
            fail(f"{label}: {path} shipped {a} != recomputed {b}")
    elif a != b:
        fail(f"{label}: {path} shipped {a!r} != recomputed {b!r}")


def check_aggregate(run: str) -> int:
    shipped = load(run, "_aggregate.json")
    n = 0
    for s in shipped["systems"]:
        fname = {"nox-mem": "nox_mem.json", "mem0": "mem0.json", "evermind": "evermind.json",
                 "zep": "zep.json"}[s["system"]]
        close(s, score_system(load(run, fname), shipped["k"]), s["system"], f"{run}/_aggregate.json")
        n += 1
    return n


# ----------------------------------------------------------------------------- helpers
def q4(x: float) -> Decimal:
    """The paper's printed four-decimal value."""
    return Decimal(repr(x)).quantize(Decimal("0.0001"), ROUND_HALF_UP)


def ci95(xs: list[float]) -> float:
    return 1.96 * statistics.stdev(xs) / math.sqrt(len(xs))


def per_query(payload: dict, dataset: str | None = None) -> list[float]:
    return [q["metrics"]["ndcg@10"] for q in payload["queries"]
            if (dataset is None or q["dataset"] == dataset) and q["metrics"]["ndcg@10"] is not None]


def mean(xs):
    return statistics.fmean(xs)


def bucket(q: dict) -> str:
    if q["dataset"] == "locomo":
        return DECLARED_MAP[int(q["native_category"])]
    return q.get("category") or "uncategorized"


def cats(payload: dict) -> dict[str, list[float]]:
    out: dict[str, list[float]] = defaultdict(list)
    for q in payload["queries"]:
        if q.get("error") in (None, "") and q["gold_chunk_ids"]:
            out[bucket(q)].append(q["metrics"]["ndcg@10"])
    return out


def ts(s: str) -> datetime:
    return datetime.strptime(s.replace("Z", "").replace("T", " ")[:19], "%Y-%m-%d %H:%M:%S")


# ----------------------------------------------------------------------------- data
SM = {n: load("smoke-2026-05", n + ".json") for n in ("nox_mem", "mem0", "zep")}
RC = {n: load("rc4-2026-06-29", n + ".json") for n in ("nox_mem", "mem0")}
AB = {n: load("rc4-ablation-2026-06-29", n + ".json") for n in ("nox_mem", "mem0")}
NT = {n: load("2026-09-10", n + ".json") for n in ("evermind", "zep")}
AGG = {"rc4n": score_system(RC["nox_mem"], K), "rc4m": score_system(RC["mem0"], K),
       "abn": score_system(AB["nox_mem"], K), "abm": score_system(AB["mem0"], K),
       "ev": score_system(NT["evermind"], K), "zp": score_system(NT["zep"], K),
       "smn": score_system(SM["nox_mem"], K), "smm": score_system(SM["mem0"], K)}


def dsm(key: str, ds: str) -> float:
    return AGG[key]["per_dataset"][ds]["ndcg@k"]


def gold_hit(p: dict) -> int:
    return sum(1 for q in p["queries"] if set(q["gold_chunk_ids"]) & set(ids(q)[:K]))


C = HERE / "corpus"
offered = [l.split("\t")[2] for l in (C / "offered_corpus_ids.tsv").read_text().splitlines()[1:]]
off_count = Counter(offered)
colliding = {i for i, c in off_count.items() if c > 1}
nox_store = set((C / "rc4-nox-hybrid.eval_chunks.ids.txt").read_text().split())
nox_store_rows = len((C / "rc4-nox-hybrid.eval_chunks.ids.txt").read_text().split())
gen_store = set((C / "rc4-nox-generic.eval_chunks.ids.txt").read_text().split())
chroma = [l.split("\t") for l in (C / "rc4-mem0-chroma.rows.tsv").read_text().splitlines()[1:]]
mem0_finish = ts(RC["mem0"]["meta"]["finished_at"])
at_query = [r for r in chroma if ts(r[1]) <= mem0_finish]
backfill = [r for r in chroma if ts(r[1]) > mem0_finish]
log = (HERE / "evidence" / "rc4-run.redacted.log").read_text(encoding="utf-8")
log_503 = [l.split("'")[1] for l in log.splitlines() if "ingest error chunk" in l and "503" in l]
all_gold_rc4 = set().union(*(set(q["gold_chunk_ids"]) for q in RC["nox_mem"]["queries"]))
gold_gen = set().union(*(set(q["gold_chunk_ids"]) for q in AB["nox_mem"]["queries"]))
CN, CM, CA = cats(RC["nox_mem"]), cats(RC["mem0"]), cats(AB["nox_mem"])
zq = NT["zep"]["queries"]

# ----------------------------------------------------------------------------- table
# (id, section, quantity, paper value, rule, quotes in the manuscript, recompute)
# rule: "num" compares at the paper's printed precision (half-up);
#       "bool"/"str" compare exactly; "min" compares a duration in whole minutes.
N: list[tuple] = []


def add(i, sec, what, paper, rule, quotes, fn):
    N.append((i, sec, what, paper, rule, quotes if isinstance(quotes, list) else [quotes], fn))


# --- superseded smoke runs (2026-05-23/25), n=20 -------------------------------------
add("S01", "6.3, 6.7", "nox-mem smoke nDCG@10 (n=20)", "0.4509", "num", "nDCG@10 = 0.4509",
    lambda: AGG["smn"]["overall"]["ndcg@k"])
add("S02", "6.3, 6.7", "nox-mem smoke gold-hit (queries with a gold id in top-10)", "13", "num", "gold-hit 13/20",
    lambda: gold_hit(SM["nox_mem"]))
add("S03", "6.3, 6.7", "nox-mem smoke queries", "20", "num", "gold-hit 13/20", lambda: len(SM["nox_mem"]["queries"]))
add("S04", "6.7", "Mem0 smoke nDCG@10 (500-chunk cap)", "0.1315", "num", "nDCG@10 = 0.1315",
    lambda: AGG["smm"]["overall"]["ndcg@k"])
add("S05", "6.7", "Mem0 smoke p50 latency (ms)", "263", "num", "p50 = 263 ms", lambda: AGG["smm"]["latency_ms"]["p50"])
add("S06", "6.7", "Mem0 smoke gold-hit", "3", "num", "gold-hit 3/20", lambda: gold_hit(SM["mem0"]))
add("S07", "6.6", "mem0@500 nDCG@10", "0.1315", "num", "against mem0@500 at 0.1315",
    lambda: AGG["smm"]["overall"]["ndcg@k"])
add("S08", "6.6", "mem0@500 LoCoMo-only nDCG@10", "0.2631", "num", "(LoCoMo-only 0.2631)",
    lambda: dsm("smm", "locomo"))
add("S09", "6.6", "mem0@500 LongMemEval queries scoring 0 (of 10)", "10", "num",
    "zeroes the 10 LongMemEval queries",
    lambda: sum(1 for q in SM["mem0"]["queries"] if q["dataset"] == "longmemeval" and q["metrics"]["ndcg@10"] == 0))
add("S10", "6.3.1", "Zep smoke queries", "20", "num", "holds 20 queries, 20 with results, 0 errors",
    lambda: len(SM["zep"]["queries"]))
add("S11", "6.3.1", "Zep smoke queries with results", "20", "num", "holds 20 queries, 20 with results, 0 errors",
    lambda: sum(1 for q in SM["zep"]["queries"] if q["results"]))
add("S12", "6.3.1", "Zep smoke queries with an error", "0", "num", "holds 20 queries, 20 with results, 0 errors",
    lambda: sum(1 for q in SM["zep"]["queries"] if q.get("error")))
add("S13", "6.3.1", "Zep smoke meta.version names zep-python 1.5.0 and zep 0.27.2", "yes", "bool",
    "`zep-python==1.5.0` + `ghcr.io/getzep/zep:0.27.2`",
    lambda: "zep-python==1.5.0" in SM["zep"]["meta"]["version"] and "zep:0.27.2" in SM["zep"]["meta"]["version"])

# --- rc4 embedding-matched (2026-06-29), §6.3.2 ---------------------------------------
for i, (lab, key, ds, val, ci, quote) in enumerate([
        ("nox-mem LongMemEval", "nox_mem", "longmemeval", "0.5255", "0.033", "0.5255 ± 0.033"),
        ("nox-mem LoCoMo", "nox_mem", "locomo", "0.4952", "0.017", "0.4952 ± 0.017"),
        ("nox-mem overall", "nox_mem", None, "0.5013", "0.015", "0.5013 ± 0.015"),
        ("Mem0 LongMemEval", "mem0", "longmemeval", "0.4030", "0.035", "0.4030 ± 0.035"),
        ("Mem0 LoCoMo", "mem0", "locomo", "0.4407", "0.017", "0.4407 ± 0.017"),
        ("Mem0 overall", "mem0", None, "0.4331", "0.016", "0.4331 ± 0.016")]):
    add(f"R{2*i+1:02d}", "6.3.2", f"rc4 {lab} nDCG@10", val, "num", quote,
        (lambda k=key, d=ds: mean(per_query(RC[k], d))))
    add(f"R{2*i+2:02d}", "6.3.2", f"rc4 {lab} 95% CI half-width (1.96*SD/sqrt(n))", ci, "num", quote,
        (lambda k=key, d=ds: ci95(per_query(RC[k], d))))
Q32 = "n=2,482: 1,982 LoCoMo + 500 LongMemEval"
add("R13", "6.3.2", "rc4 LoCoMo queries", "1,982", "num", Q32, lambda: len(per_query(RC["nox_mem"], "locomo")))
add("R14", "6.3.2", "rc4 LongMemEval queries", "500", "num", Q32, lambda: len(per_query(RC["nox_mem"], "longmemeval")))
add("R15", "6.3.2", "rc4 queries, both arms", "2,482", "num", Q32,
    lambda: len(per_query(RC["mem0"])) if len(per_query(RC["mem0"])) == len(per_query(RC["nox_mem"])) else -1)


def disjoint() -> bool:
    ok = True
    for d in ("longmemeval", "locomo", None):
        a, b = per_query(RC["nox_mem"], d), per_query(RC["mem0"], d)
        ok &= mean(a) - ci95(a) > mean(b) + ci95(b)
    return ok


add("R16", "6.3.2", "nox-mem / Mem0 95% CIs disjoint on both datasets and overall", "yes", "bool",
    "intervals are disjoint on both datasets and overall", disjoint)
add("R17", "6.3.2", "Delta LongMemEval nox-mem - Mem0 (printed 4-dp values)", "+0.123", "num",
    "LongMemEval +0.123, LoCoMo +0.055", lambda: q4(dsm("rc4n", "longmemeval")) - q4(dsm("rc4m", "longmemeval")))
add("R18", "6.3.2", "Delta LoCoMo nox-mem - Mem0 (printed 4-dp values; unrounded gives 0.054)", "+0.055", "num",
    "LongMemEval +0.123, LoCoMo +0.055", lambda: q4(dsm("rc4n", "locomo")) - q4(dsm("rc4m", "locomo")))
add("R19", "6.3.2 (a)", "rc4 Mem0 queries carrying an error", "0", "num",
    "`error: null` on all 2,482 queries and `n_errors: 0`",
    lambda: sum(1 for q in RC["mem0"]["queries"] if q.get("error") not in (None, "")))
add("R20", "6.3.2 (a)", "rc4 Mem0 meta.n_errors", "0", "num", "`error: null` on all 2,482 queries and `n_errors: 0`",
    lambda: RC["mem0"]["meta"]["n_errors"])
add("R21", "6.3.2 (a)", "rc4 Mem0 meta.version", "mem0ai==0.1.114", "str", '`meta.version = "mem0ai==0.1.114"`',
    lambda: RC["mem0"]["meta"]["version"])
add("R22", "6.3.2", "rc4 gold ids absent from the offered corpus", "0", "num",
    "every gold chunk exists in the corpus on both datasets", lambda: len(all_gold_rc4 - set(offered)))
add("R23", "6.3.2", "rc4 gold ids absent from the nox-mem store", "0", "num",
    "every gold chunk exists in the corpus on both datasets", lambda: len(all_gold_rc4 - nox_store))
add("R24", "6.3.2 (e), 6.9", "offered corpus documents", "6,830", "num",
    ["The offered corpus is 6,830 documents carrying 6,822 distinct ids",
     "the offered corpus is 6,830 documents carrying 6,822 distinct ids"], lambda: len(offered))
add("R25", "6.3.2 (e), 6.9", "offered corpus distinct ids", "6,822", "num",
    "The offered corpus is 6,830 documents carrying 6,822 distinct ids", lambda: len(off_count))
add("R26", "6.3.2 (e)", "ids naming two documents", "8", "num", "8 pairs of documents with *different text* share an id",
    lambda: len(colliding) if all(off_count[i] == 2 for i in colliding) else -1)
add("R27", "6.3.2 (e), 6.9", "nox-mem rc4 store rows (eval_chunks)", "6,822", "num",
    ["`cache/rc4-nox-hybrid.db` `eval_chunks` = 6,822", "all 6,822 retained by its eval loader"],
    lambda: nox_store_rows if nox_store_rows == len(nox_store) else -1)
add("R28", "6.3.2 (e)", "Mem0 store rows at query time (created_at <= run finish)", "6,826", "num",
    "held 6,826 rows (6,818 distinct ids) when the run queried it", lambda: len(at_query))
add("R29", "6.3.2 (e)", "Mem0 store distinct ids at query time", "6,818", "num",
    "held 6,826 rows (6,818 distinct ids) when the run queried it", lambda: len({r[2] for r in at_query}))
add("R30", "6.3.2 (e)", "Mem0 rows written after the run finished (back-fill)", "4", "num",
    "the 4 chunks lost to transient 503s were back-filled at 15:02 UTC", lambda: len(backfill))
add("R31", "6.3.2", "Mem0 ingest 503 errors in the run log", "4", "num",
    "Mem0's ingest log records 4 transient 503 errors", lambda: len(log_503))
add("R32", "6.3.2 (e)", "back-filled ids == the 4 ids of the logged 503s, all at 15:02 UTC", "yes", "bool",
    "back-filled at 15:02 UTC, after the run finished at 14:57:04 UTC",
    lambda: sorted(r[2] for r in backfill) == sorted(log_503) and all(r[1].startswith("2026-06-29 15:02") for r in backfill))
add("R33", "6.3.2 (e)", "rc4 Mem0 run finished_at", "2026-06-29T14:57:04Z", "str",
    "after the run finished at 14:57:04 UTC", lambda: RC["mem0"]["meta"]["finished_at"])
add("R34", "6.3.2 (e)", "Mem0 preserved store rows", "6,830", "num",
    "`embeddings` = 6,830 with 6,822 distinct `chunk_id`", lambda: len(chroma))
add("R35", "6.3.2 (e)", "Mem0 preserved store distinct chunk_id", "6,822", "num",
    "`embeddings` = 6,830 with 6,822 distinct `chunk_id`", lambda: len({r[2] for r in chroma}))
add("R36", "6.3.2 (a)", "Mem0 store rows carrying a text_lemmatized key", "6,830", "num",
    "`text_lemmatized` on 6,830 of 6,830 metadata rows", lambda: sum(int(r[3]) for r in chroma))
add("R37", "6.3.2 (a)", "run log carries mem0's 2.x chroma keyword-search warning", "yes", "bool",
    "the 'chroma' vector store does not support keyword search",
    lambda: "The 'chroma' vector store does not support keyword search" in log)
add("R38", "6.3.2 (e)", "rc4 queries with a gold id in a colliding pair", "10", "num", "10 of 2,482 queries (0.40%)",
    lambda: sum(1 for q in RC["nox_mem"]["queries"] if set(q["gold_chunk_ids"]) & colliding))
add("R39", "6.3.2 (e)", "same, percent of 2,482", "0.40", "num", "10 of 2,482 queries (0.40%)",
    lambda: 100 * sum(1 for q in RC["nox_mem"]["queries"] if set(q["gold_chunk_ids"]) & colliding) / 2482)
add("R40", "6.3.2 (c)", "rc4 queries whose gold includes a back-filled chunk", "1", "num", "affect one query",
    lambda: sum(1 for q in RC["mem0"]["queries"] if set(q["gold_chunk_ids"]) & {r[2] for r in backfill}))

# --- task-type ablation (2026-06-29/30), §6.3.2 ----------------------------------------
add("A01", "6.3.2", "ablation nox-mem overall nDCG@10 (generic task type)", "0.4979", "num",
    "0.5013 → 0.4979 (−0.34 pp)", lambda: AGG["abn"]["overall"]["ndcg@k"])
add("A02", "6.3.2", "ablation drop, pp (printed 4-dp values)", "0.34", "num", "0.5013 → 0.4979 (−0.34 pp)",
    lambda: (q4(AGG["rc4n"]["overall"]["ndcg@k"]) - q4(AGG["abn"]["overall"]["ndcg@k"])) * 100)
add("A03", "6.3.2", "ablation nox-mem LoCoMo", "0.4920", "num", "LoCoMo 0.4920 vs 0.4407", lambda: dsm("abn", "locomo"))
add("A04", "6.3.2", "ablation nox-mem LongMemEval", "0.5215", "num", "LongMemEval 0.5215 vs 0.4030",
    lambda: dsm("abn", "longmemeval"))
add("A05", "6.3.2", "ablation Mem0 baseline overall", "0.4331", "num", "still outperforms Mem0 (0.4331)",
    lambda: AGG["abm"]["overall"]["ndcg@k"])
add("A06", "6.3.2", "ablation Mem0 baseline is the rc4 Mem0 output (same original sha256)", "yes", "bool",
    "against the same Mem0 baseline",
    lambda: AB["mem0"]["stripped_from"]["original_sha256"] == RC["mem0"]["stripped_from"]["original_sha256"]
    and [q["metrics"] for q in AB["mem0"]["queries"]] == [q["metrics"] for q in RC["mem0"]["queries"]])
add("A07", "6.3.2, 6.4", "ablation nox-mem leads Mem0 in all five categories", "yes", "bool",
    ["and all five categories", "nox-mem still leads all five categories"],
    lambda: all(mean(CA[c]) > mean(CM[c]) for c in CATS))
add("A08", "6.3.2", "ablation store gold coverage, percent", "99.03", "num", "reached 99.03% gold coverage",
    lambda: 100 * len(gold_gen & gen_store) / len(gold_gen))
add("A09", "6.3.2", "ablation distinct gold ids absent from the store", "23", "num",
    "23 of 2,370 distinct gold chunks absent", lambda: len(gold_gen - gen_store))
add("A10", "6.3.2", "distinct gold ids", "2,370", "num", "23 of 2,370 distinct gold chunks absent", lambda: len(gold_gen))
add("A11", "6.5", "ablation margin >= +0.05 nDCG@10 on both datasets", "yes", "bool",
    "at least +0.05 nDCG@10 on both datasets",
    lambda: min(dsm("abn", d) - dsm("abm", d) for d in ("locomo", "longmemeval")) >= 0.05)

# --- EverOS 2026-09-10, §6.3.3 -----------------------------------------------------------
QE = "| **EverOS 1.3.1** (2026-09-10) | **0.6455** | **0.6585** | **0.5942** | 0.7629 | 0.6403 | 1,592 ms |"
add("E01", "6.3.3", "EverOS overall nDCG@10", "0.6455", "num", QE, lambda: AGG["ev"]["overall"]["ndcg@k"])
add("E02", "6.3.3", "EverOS LoCoMo nDCG@10", "0.6585", "num", QE, lambda: dsm("ev", "locomo"))
add("E03", "6.3.3", "EverOS LongMemEval nDCG@10", "0.5942", "num", QE, lambda: dsm("ev", "longmemeval"))
add("E04", "6.3.3", "EverOS R@10", "0.7629", "num", QE, lambda: AGG["ev"]["overall"]["recall@k"])
add("E05", "6.3.3", "EverOS MRR", "0.6403", "num", QE, lambda: AGG["ev"]["overall"]["mrr"])
add("E06", "6.3.3", "EverOS p50 latency (ms)", "1,592", "num", QE, lambda: AGG["ev"]["latency_ms"]["p50"])
QN = "| 0.6656 | 0.4749 | 515.6 ms"
add("E07", "6.3.3, 6.3.4", "nox-mem rc4 R@10", "0.6656", "num", QN, lambda: AGG["rc4n"]["overall"]["recall@k"])
add("E08", "6.3.3, 6.3.4", "nox-mem rc4 MRR", "0.4749", "num", QN, lambda: AGG["rc4n"]["overall"]["mrr"])
add("E09", "6.3.3, 6.3.4", "nox-mem rc4 p50 latency (ms)", "515.6", "num", QN, lambda: AGG["rc4n"]["latency_ms"]["p50"])
QM = "| 0.5842 | 0.4092 | 349.8 ms"
add("E10", "6.3.3, 6.3.4", "Mem0 rc4 R@10", "0.5842", "num", QM, lambda: AGG["rc4m"]["overall"]["recall@k"])
add("E11", "6.3.3, 6.3.4", "Mem0 rc4 MRR", "0.4092", "num", QM, lambda: AGG["rc4m"]["overall"]["mrr"])
add("E12", "6.3.3, 6.3.4", "Mem0 rc4 p50 latency (ms)", "349.8", "num", QM, lambda: AGG["rc4m"]["latency_ms"]["p50"])
QD = "(+0.163 LoCoMo, +0.069 LongMemEval, +0.144 overall)"
add("E13", "6.3.3", "Delta EverOS - nox-mem LoCoMo", "+0.163", "num", QD,
    lambda: q4(dsm("ev", "locomo")) - q4(dsm("rc4n", "locomo")))
add("E14", "6.3.3", "Delta EverOS - nox-mem LongMemEval", "+0.069", "num", QD,
    lambda: q4(dsm("ev", "longmemeval")) - q4(dsm("rc4n", "longmemeval")))
add("E15", "6.3.3", "Delta EverOS - nox-mem overall", "+0.144", "num", [QD, "attributing the 0.144 gap"],
    lambda: q4(AGG["ev"]["overall"]["ndcg@k"]) - q4(AGG["rc4n"]["overall"]["ndcg@k"]))
add("E16", "6.3.3", "EverOS queries / errors", "2,482", "num", "across 2,482 queries with zero errors",
    lambda: len(NT["evermind"]["queries"]) if NT["evermind"]["meta"]["n_errors"] == 0
    and not any(q.get("error") for q in NT["evermind"]["queries"]) else -1)
add("E17", "6.3.3", "EverOS meta.version", "everos==1.3.1", "str", "`everos==1.3.1`, n_queries 2,482, n_errors 0",
    lambda: NT["evermind"]["meta"]["version"])
add("E18", "6.3.1", "EverOS hits returned by the service = 50 on every query (topics_seen)", "yes", "bool",
    "every query in the sweep returns\nexactly 50 hits",
    lambda: all(r["topics_seen"] == 50 for q in NT["evermind"]["queries"] for r in q["results"])
    and all(q["results"] for q in NT["evermind"]["queries"]))
add("E19", "6.3.1", "EverOS retrieval method = hybrid on every hit", "yes", "bool", "under `method=hybrid`",
    lambda: {r["retrieval_method"] for q in NT["evermind"]["queries"] for r in q["results"]} == {"hybrid"})

# --- Zep 2026-09-10, §6.3.4 --------------------------------------------------------------
QZ = "| **Zep 0.27.2** (2026-09-10) | **0.4546** | **0.4793** | **0.3567** | 0.6108 | 0.4279 | **6,002 ms** |"
add("Z01", "6.3.4", "Zep overall nDCG@10", "0.4546", "num", QZ, lambda: AGG["zp"]["overall"]["ndcg@k"])
add("Z02", "6.3.4", "Zep LoCoMo nDCG@10", "0.4793", "num", QZ, lambda: dsm("zp", "locomo"))
add("Z03", "6.3.4", "Zep LongMemEval nDCG@10", "0.3567", "num", QZ, lambda: dsm("zp", "longmemeval"))
add("Z04", "6.3.4", "Zep R@10", "0.6108", "num", QZ, lambda: AGG["zp"]["overall"]["recall@k"])
add("Z05", "6.3.4", "Zep MRR", "0.4279", "num", QZ, lambda: AGG["zp"]["overall"]["mrr"])
add("Z06", "6.3.4", "Zep p50 latency (ms)", "6,002", "num", QZ, lambda: AGG["zp"]["latency_ms"]["p50"])
add("Z07", "6.3.4", "Zep p99 latency (ms)", "11,846", "num", "the p99 is 11,846 ms", lambda: AGG["zp"]["latency_ms"]["p99"])
add("Z08", "6.3.4", "Zep LoCoMo - LongMemEval spread", "0.123", "num", "below its own LoCoMo by 0.123",
    lambda: q4(dsm("zp", "locomo")) - q4(dsm("zp", "longmemeval")))
add("Z09", "6.3.4", "Zep LongMemEval is the lowest dataset cell of the four-system table", "yes", "bool",
    "lowest any system in this table records on either dataset",
    lambda: dsm("zp", "longmemeval") == min(dsm(k, d) for k in ("ev", "rc4n", "zp", "rc4m") for d in ("locomo", "longmemeval")))
add("Z10", "6.3.4", "Zep rank on overall nDCG@10 among EverOS, nox-mem, Zep, Mem0", "3", "num", "Zep ranks third",
    lambda: 1 + sorted([AGG[k]["overall"]["ndcg@k"] for k in ("ev", "rc4n", "zp", "rc4m")], reverse=True).index(AGG["zp"]["overall"]["ndcg@k"]))
add("Z11", "6.3.4", "Zep p50 / EverOS p50", "3.8", "num", "3.8× EverOS's 1,592 ms",
    lambda: AGG["zp"]["latency_ms"]["p50"] / AGG["ev"]["latency_ms"]["p50"])
add("Z12", "6.3.4", "Zep queries (n_errors 0, no per-query error)", "2,482", "num", "n = 2,482, with zero errors",
    lambda: len(zq) if NT["zep"]["meta"]["n_errors"] == 0 and not any(q.get("error") for q in zq) else -1)
add("Z13", "6.3.4", "Zep run wall time (meta started_at -> finished_at)", "4 h 13 min", "min", "in 4 h 13 min",
    lambda: (ts(NT["zep"]["meta"]["finished_at"]) - ts(NT["zep"]["meta"]["started_at"])).total_seconds() / 60)
add("Z14", "6.3.4", "Zep sessions swept per query (all queries)", "510", "num", "fans out to 510 sessions",
    lambda: ({r["sessoes_varridas"] for q in zq for r in q["results"]} or {-1}).pop()
    if len({r["sessoes_varridas"] for q in zq for r in q["results"]}) == 1 else -1)
add("Z15", "6.3.4", "Zep session sweeps (queries x sessions)", "1,265,820", "num", "1,265,820 session",
    lambda: sum(q["results"][0]["sessoes_varridas"] for q in zq))
add("Z16", "6.3.4", "Zep failed session sweeps", "47", "num", "47 failed in 46 distinct sessions",
    lambda: sum(q["results"][0]["sessoes_com_erro"] for q in zq))
add("Z17", "6.3.4", "failed sweeps, percent of all sweeps", "0.0037", "num", "0.0037%",
    lambda: 100 * sum(q["results"][0]["sessoes_com_erro"] for q in zq) / sum(q["results"][0]["sessoes_varridas"] for q in zq))
add("Z18", "6.3.4", "Zep meta.version names zep-python 1.5.0 and zep 0.27.2", "yes", "bool",
    "`zep-python==1.5.0` + `ghcr.io/getzep/zep:0.27.2`",
    lambda: "zep-python==1.5.0" in NT["zep"]["meta"]["version"] and "zep:0.27.2" in NT["zep"]["meta"]["version"])

# --- §6.4 per-category (declared LoCoMo map) ----------------------------------------------
P64 = {"single-hop": ("997", "0.5922", "0.5607", "+0.031", "0.5773"),
       "multi-hop": ("415", "0.3641", "0.3218", "+0.042", "0.3515"),
       "temporal": ("454", "0.5502", "0.4565", "+0.094", "0.5571"),
       "adversarial": ("524", "0.4370", "0.2930", "+0.144", "0.4573"),
       "open-domain": ("92", "0.2592", "0.2351", "+0.024", "0.2365")}
QAB = ("(adversarial 0.4573 vs 0.2930; temporal 0.5571 vs 0.4565; single-hop 0.5773 vs 0.5607; "
       "multi-hop 0.3515 vs 0.3218; open-domain 0.2365 vs 0.2351)")
for j, (c, (n, a, b, d, ab)) in enumerate(P64.items()):
    row = f"| {c} | {n} | **{a}** | {b} | {d} |"
    add(f"C{5*j+1:02d}", "6.4", f"{c} n", n, "num", row, (lambda c=c: len(CN[c]) if len(CN[c]) == len(CM[c]) else -1))
    add(f"C{5*j+2:02d}", "6.4", f"{c} nox-mem nDCG@10", a, "num", row, (lambda c=c: mean(CN[c])))
    add(f"C{5*j+3:02d}", "6.4", f"{c} Mem0 nDCG@10", b, "num", row, (lambda c=c: mean(CM[c])))
    add(f"C{5*j+4:02d}", "6.4", f"{c} Delta (unrounded means)", d, "num", row, (lambda c=c: mean(CN[c]) - mean(CM[c])))
    add(f"C{5*j+5:02d}", "6.4", f"{c} ablation nox-mem nDCG@10", ab, "num", QAB, (lambda c=c: mean(CA[c])))
add("C26", "6.4", "nox-mem leads Mem0 in every represented category (rc4)", "yes", "bool",
    "nox-mem leads every represented category", lambda: all(mean(CN[c]) > mean(CM[c]) for c in CATS))
add("C27", "6.4", "adversarial bucket: LoCoMo native adversarial (category 5)", "446", "num",
    "combines LoCoMo's 446 native adversarial queries with 78 LongMemEval `knowledge-update` queries",
    lambda: sum(1 for q in RC["nox_mem"]["queries"] if q["dataset"] == "locomo" and q["native_category"] == 5))
add("C28", "6.4", "adversarial bucket: LongMemEval knowledge-update", "78", "num",
    "combines LoCoMo's 446 native adversarial queries with 78 LongMemEval `knowledge-update` queries",
    lambda: sum(1 for q in RC["nox_mem"]["queries"] if q["dataset"] == "longmemeval"
                and q["native_category"] == "knowledge-update" and q["category"] == "adversarial"))
add("C29", "6.4", "numeric-typed queries in either dataset (< 10 => n/a)", "0", "num",
    "neither dataset contributes at least 10 numeric-typed queries",
    lambda: sum(1 for q in RC["nox_mem"]["queries"] if bucket(q) == "numeric"))
add("C30", "6.4", "open-domain queries from LongMemEval (LoCoMo-only bucket)", "0", "num",
    "open-domain, by contrast, is LoCoMo-only",
    lambda: sum(1 for q in RC["nox_mem"]["queries"] if q["dataset"] == "longmemeval" and bucket(q) == "open-domain"))
add("C31", "6.4", "stored run-time LoCoMo label == old map of the native category, all arms", "yes", "bool",
    "The run-time labeler and the `_aggregate.md` beside the outputs still use the old map",
    lambda: all(q["category"] == OLD_MAP[q["native_category"]] for p in (RC["nox_mem"], RC["mem0"], AB["nox_mem"])
                for q in p["queries"] if q["dataset"] == "locomo"))

# --- arithmetic on the paper's own canonical figures (outputs not retained) ----------------
QC = "nox-mem wins LongMemEval (+0.047 nDCG@10, +0.039 MRR) and Mem0 wins LoCoMo (+0.042 nDCG@10)"
add("X01", "6.3", "canonical LME nDCG Delta, from the printed table (0.5234-0.4764)", "+0.047", "num", QC,
    lambda: Decimal("0.5234") - Decimal("0.4764"))
add("X02", "6.3", "canonical LME MRR Delta, from the printed table (0.5494-0.5107)", "+0.039", "num", QC,
    lambda: Decimal("0.5494") - Decimal("0.5107"))
add("X03", "6.3", "canonical LoCoMo nDCG Delta, from the printed table (0.4686-0.4263)", "+0.042", "num", QC,
    lambda: Decimal("0.4686") - Decimal("0.4263"))

NOT_RECOMPUTABLE = [
    ("6.3", "canonical 2026-06-15 tables: nox-mem 0.5234/0.6535/0.5494 and 0.4263/0.5504/0.4464; Mem0 "
     "0.4764/0.6372/0.5107 and 0.4686/0.6171/0.4656; agentmemory 0.2803 and 0.1587; raw union 0.4173; 14.6% "
     "off-dataset; Mem0 LoCoMo coverage ~95%",
     "per-query outputs were not retained when the benchmark pod was terminated (stated in §6.3); "
     "X01-X03 check only the arithmetic of the printed deltas"),
    ("6.6", "capped smoke, nox-mem: 0.0466 FTS5-only, 0.0918 hybrid, 0.1835 LoCoMo-only",
     "the per-query output of those runs was overwritten in place by the 2026-05-24 full-corpus smoke "
     "(the file now at runs/smoke-2026-05/nox_mem.json, which gives S01); the Mem0 half (S07-S09) is recomputed"),
    ("6.3.1", "EverOS ingest: 6,822 documents retained in the index, 4 DuplicateDocumentError, no id absent "
     "from the index, no failed write is a gold document",
     "measured on the live EverOS store after its final sync; that store is not part of this dataset. "
     "The offered side (6,830 documents, 6,822 ids, 8 colliding ids) is recomputed in R24-R26"),
    ("6.3.1", "EverOS rerank_n = 50 and top_k_cap = 100",
     "service configuration, not an output; E18 recomputes the observable consequence (50 hits on every query)"),
    ("6.3.2 (a)", "mem0ai 2.0.10 at run time; the two 2.x strings absent from the 0.1.114 sdist (positive "
     "controls 23 and 21 files); 2.0.10 raising ValueError on the 0.1.x call shape",
     "requires the PyPI sdists of mem0ai 0.1.114 and 2.0.10, not distributed here. The two run-side "
     "strings are recomputed (R36, R37)"),
    ("6.3.2 (c)", "the back-filled chunk's query: Mem0 misses its gold in top-10 even when the chunk is present; "
     "zero aggregate effect", "needs a re-query of the Mem0 store with the chunk present; R40 recomputes "
     "that exactly one query is affected"),
    ("6.3.2 (e)", "EverOS also retained 6,822 (different run)", "see the EverOS ingest row above"),
    ("6.3.3", "§5.1.7 cross-encoder figures (-0.96 pp, +1.61 pp, -2.80 to -4.00 pp); 22 M vs 4 B parameters, "
     "180-fold", "Section 5 measurements and model cards, not Section 6 outputs"),
    ("6.3.3, 6.3.4", "standalone nox-mem hybrid p50 529 and ~940 ms (§5.7)", "Section 5 measurements"),
    ("6.3.4", "47 failures in 46 distinct sessions; 35 timeouts, 8 OpenAI 500s, 4 Bad file descriptor",
     "the outputs record the number of failed sessions per query (Z16 = 47) but not which session "
     "failed or why; the breakdown was classified on the run's console log, which is not in the "
     "code repository nor in this dataset"),
    ("6.8", "Table 2 (services, mandatory keys)", "read from each project's source/documentation; not outputs"),
    ("6.9", "Mem0 PID-limit exhaustion x3, ~5% LoCoMo vectors lost (2026-06-15 pod); Letta ~16 min/query",
     "operational observations of the canonical pod; no archived artifact"),
]


# ----------------------------------------------------------------------------- compare
def parse_paper(s: str) -> Decimal:
    t = s.replace(",", "").replace("+", "").replace("−", "-").strip()
    return Decimal(t)


def fmt(x) -> str:
    return x if isinstance(x, str) else repr(x)


def compare(paper: str, rule: str, got) -> tuple[bool, str]:
    if rule == "bool":
        return (bool(got) == (paper == "yes")), ("yes" if got else "no")
    if rule == "str":
        return got == paper, str(got)
    if rule == "min":
        h, m = paper.replace("min", "").split("h")
        want = int(h) * 60 + int(m)
        mins = int(Decimal(repr(got)).quantize(Decimal("1"), ROUND_HALF_UP))
        return mins == want, f"{mins // 60} h {mins % 60} min ({got:.2f} min)"
    want = parse_paper(paper)
    exp = want.as_tuple().exponent
    q = Decimal(1).scaleb(exp)
    gd = got if isinstance(got, Decimal) else Decimal(repr(float(got)))
    r = gd.quantize(q, ROUND_HALF_UP)
    return r == want, f"{r} (raw {fmt(got if not isinstance(got, Decimal) else str(got))})"


def section6(path: Path) -> str:
    t = path.read_text(encoding="utf-8")
    a = t.index("## 6. Cross-System Comparison")
    b = t.index("## 7. ", a)
    return t[a:b]


def declared_version(path: Path) -> str:
    for line in path.read_text(encoding="utf-8").splitlines()[:40]:
        if line.startswith("**Version**"):
            return line.split()[1]
    return "not found"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manuscript", help=f"path to paper-tecnico-nox-mem.md ({PAPER_VERSION} or later); "
                                         "checks every quote occurs in §6")
    a = ap.parse_args()

    nfiles = check_sums()
    nmet = sum(check_stored_metrics(p, lab) for lab, p in
               [("smoke/" + k, v) for k, v in SM.items()] + [("rc4/" + k, v) for k, v in RC.items()]
               + [("ablation/" + k, v) for k, v in AB.items()] + [("2026-09-10/" + k, v) for k, v in NT.items()])
    nagg = sum(check_aggregate(r) for r in ("rc4-2026-06-29", "rc4-ablation-2026-06-29", "2026-09-10"))
    print(f"files: {nfiles} checked against SHA256SUMS | per-query metrics: {nmet} re-scored, all in [0, 1] "
          f"unless listed below | shipped aggregates: {nagg} system rows reproduced")
    nrep, ngold = repeats(RC["mem0"])
    others = sum(repeats(p)[0] for p in [*SM.values(), RC["nox_mem"], AB["nox_mem"], *NT.values()])
    print(f"scoring rule: each retrieved id counts once, at its first rank in the top {K} (paper {PAPER_VERSION}); "
          f"rc4 Mem0 repeats an id in {nrep} queries ({ngold} of them a gold id), every other output in {others}")

    s6 = None
    if a.manuscript:
        mv = declared_version(Path(a.manuscript))
        print(f"manuscript declares {mv}; the printed values below are those of {PAPER_VERSION}"
              + ("" if mv == PAPER_VERSION else " (different version: the quote check decides)"))
        s6 = section6(Path(a.manuscript))
    rows, ok_n = [], 0
    for i, sec, what, paper, rule, quotes, fn in N:
        try:
            ok, shown = compare(paper, rule, fn())
        except Exception as e:  # noqa: BLE001
            ok, shown = False, f"ERROR {type(e).__name__}: {e}"
        qok = True
        if s6 is not None:
            for qt in quotes:
                if qt not in s6:
                    qok = False
                    fail(f"{i}: quote not found in manuscript §6: {qt!r}")
        status = "OK" if ok and qok else ("MISMATCH" if not ok else "QUOTE?")
        if not ok:
            fail(f"{i} §{sec} {what}: paper {paper} != recomputed {shown}")
        ok_n += ok and qok
        rows.append((i, sec, what, paper, shown, status))

    w = [max(len(str(r[k])) for r in rows) for k in range(6)]
    w[2] = min(w[2], 62)
    w[4] = min(w[4], 40)
    hdr = ("id", "section", "quantity", "paper", "recomputed", "status")
    print()
    print("  ".join(h.ljust(w[k]) for k, h in enumerate(hdr)))
    print("  ".join("-" * w[k] for k in range(6)))
    for r in rows:
        print("  ".join(str(r[k])[:w[k]].ljust(w[k]) for k in range(6)))
    print()
    print("Not recomputable from per-query outputs (declared; not counted in the exit code):")
    for sec, what, why in NOT_RECOMPUTABLE:
        print(f"  §{sec}: {what}\n      reason: {why}")
    print()
    if s6 is not None:
        print(f"manuscript quotes checked against §6 of {Path(a.manuscript).name}")
    if failures:
        print(f"FAIL — {len(failures)} problem(s):")
        for f in failures:
            print("  " + f)
        return 1
    print(f"OK — {ok_n}/{len(N)} Section 6 values checked and equal to the paper; "
          f"{len(NOT_RECOMPUTABLE)} groups declared not recomputable")
    return 0


if __name__ == "__main__":
    sys.exit(main())
