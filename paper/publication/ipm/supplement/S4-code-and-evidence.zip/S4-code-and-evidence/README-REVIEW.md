# Supplementary material S4: code and evidence (anonymized)

This copy is for double-anonymized review; the public locations are on the title page. The build
replaced the author's name, handle and e-mail address, the DOIs, the repository and container-image
links, the repository's name (now `research-repo`), the user name in a macOS path, the operator's
nickname (now "Operator"), the agents' names (now "Agent A" to "Agent F", as in S1 to S3), the
business names in one test fixture (now "Alfa" to "Epsilon") and one code comment that described
the author's work. It also dropped the author, homepage, repository and bugs fields from
`nox-mem/package.json`. Every other line is as in the source. Paths under `/root/.openclaw/` are the agent platform's defaults;
they identify no one, and the tests derive values from them, so they stay.

| directory | what it is | backs in the article |
|---|---|---|
| `nox-mem/` | the system: TypeScript source, tests, prompts, `package.json` (MIT), at release v3.4.0 (2026-09-28), the first tagged release and the nearest to the runs | Section 3 |
| `harness/q4-comparison/` | the cross-system harness: runners, one adapter per system, corpus loader, aggregation and scorer, tests and the compose file; `adapters/nox_mem.py` is the hybrid pipeline that Section 4 measured | Section 4 |
| `harness/evermembench/` | the EverMemBench harness: adapter, batch runners, aggregation scripts, per-batch results and the backbone matrix | Section 5 |
| `specs/` | the execution plan of the comparison, committed to the public repository before the first run | Section 4 (pre-specification) |
| `evidence/` | the deposited evidence record v1.0.0: per-query outputs of the full-set runs and `verify_dataset.py` | Section 4 figures |

## Checking the Section 4 figures

    cd evidence
    python3 verify_dataset.py

Python 3.9 or later, standard library only; it writes nothing and exits 0 only if every check
passes (`evidence/README.md` lists the checks). The data files under `evidence/runs/` and
`evidence/corpus/` are byte-identical to the deposited record. 4 text files of the record
carried an identifier and were edited (`LICENSE.txt`, `PROVENANCE.json`, `README.md`, `verify_dataset.py`); `SHA256SUMS` was regenerated for them, so its
lines for those files differ from the record's.

## What is not here, and why

- The raw outputs and caches of the Section 4 harness (`output*/`, `cache/`): they contain
  LoCoMo and LongMemEval text, and LoCoMo is CC BY-NC 4.0. The stripped outputs in `evidence/`
  keep every id, rank, score and latency needed to score the runs.
- The benchmarks themselves, which come from their authors under their own licences;
  `harness/q4-comparison/lib/corpus_loader.py` downloads LoCoMo and LongMemEval.
- The outputs of the canonical 2026-06-15 run (n = 100 per dataset), which were not retained;
  the article and `evidence/README.md` say so.
- Operational material of the author's deployment (installation guide, server runbooks, agent
  profiles), which is not part of the method.
- Git history. Commit dates (for example, that the execution plan predates the first run) can be
  checked in the public repository named on the title page.
