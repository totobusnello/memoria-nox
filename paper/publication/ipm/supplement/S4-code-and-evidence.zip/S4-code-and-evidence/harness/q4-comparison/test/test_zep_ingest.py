"""
Tests for the Zep adapter ingestion pipeline.

Two test tiers:
  1. UNIT  — no Zep daemon needed. Tests pure-Python logic (ID mapping,
             session naming, conv_id derivation, validate() static checks).
  2. INTEGRATION — requires Zep OSS running at ZEP_API_URL (default
             http://127.0.0.1:8000). Skipped automatically if not reachable.

Run unit only (fast, CI-safe):
    pytest test/test_zep_ingest.py -m "not integration" -v

Run all (after docker compose up):
    pytest test/test_zep_ingest.py -v

Environment:
    ZEP_API_URL  — override Zep base URL (default http://127.0.0.1:8000)

Adapter API (updated 2026-05-24 for zep-python==1.5.0 + Zep OSS 0.27.2):
    - ZepClient(base_url, api_key)
    - client.memory.add_session(Session(session_id, metadata))
    - client.memory.add_memory(session_id, Memory(messages=[Message,...]))
    - client.memory.search_memory(session_id, MemorySearchPayload(text), limit)
      ^ scoped per session; adapter fans out across all _sessions
    - r.message comes back as dict, r.dist is cosine similarity (higher=closer)
"""

from __future__ import annotations

import importlib
import os
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

# Make sure adapters/ is importable regardless of cwd.
HERE = Path(__file__).parent
ADAPTERS_DIR = HERE.parent
sys.path.insert(0, str(ADAPTERS_DIR))

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _zep_reachable() -> bool:
    """Return True if Zep /healthz responds 200."""
    try:
        import requests

        base = os.environ.get("ZEP_API_URL", "http://127.0.0.1:8000").rstrip("/")
        resp = requests.get(f"{base}/healthz", timeout=2)
        return resp.status_code == 200
    except Exception:
        return False


ZEP_UP = _zep_reachable()
integration = pytest.mark.skipif(not ZEP_UP, reason="Zep OSS not running — skipping integration")


# ---------------------------------------------------------------------------
# Fresh adapter import (clears module-level state between tests)
# ---------------------------------------------------------------------------


def _fresh_adapter() -> types.ModuleType:
    """Import (or re-import) adapters.zep with clean module-level state."""
    if "adapters.zep" in sys.modules:
        del sys.modules["adapters.zep"]
    mod = importlib.import_module("adapters.zep")
    # Reset mutable module globals
    mod._client = None
    mod._sessions.clear()
    return mod


def _mock_message(content: str, metadata: dict | None = None, uuid: str = "u-1") -> dict:
    """Build a dict-shaped message matching zep-python==1.5.0 search response."""
    return {
        "uuid": uuid,
        "role": "user",
        "content": content,
        "metadata": metadata or {},
    }


def _mock_search_result(message_dict: dict, dist: float = 0.9) -> MagicMock:
    """Build a MemorySearchResult-shaped mock matching the 1.5.0 SDK."""
    r = MagicMock()
    r.message = message_dict
    r.dist = dist
    return r


# ---------------------------------------------------------------------------
# Unit tests — no daemon required
# ---------------------------------------------------------------------------


class TestConvIdDerivation(unittest.TestCase):
    """_conv_id_from_gold_id pure-function tests."""

    def setUp(self):
        self.zep = _fresh_adapter()

    def test_locomo_standard(self):
        self.assertEqual(self.zep._conv_id_from_gold_id("conv-48::D2:13"), "conv-48")

    def test_locomo_deeper(self):
        self.assertEqual(
            self.zep._conv_id_from_gold_id("locomo::conv-50::chunk-7"),
            "locomo::conv-50",
        )

    def test_no_separator(self):
        """Single-segment IDs return themselves as the conversation group."""
        self.assertEqual(self.zep._conv_id_from_gold_id("flat-chunk-01"), "flat-chunk-01")

    def test_longmemeval_format(self):
        self.assertEqual(
            self.zep._conv_id_from_gold_id("conv-26::q6::answer-chunk-3"),
            "conv-26::q6",
        )


class TestSafeSessionId(unittest.TestCase):
    """Session IDs must be alphanum + _- only; deterministic from conv_id."""

    def test_simple_pass_through(self):
        zep = _fresh_adapter()
        self.assertEqual(zep._safe_session_id("conv-48"), "q4-conv-48")

    def test_special_chars_sanitised(self):
        zep = _fresh_adapter()
        # "::" must collapse to "__"
        self.assertEqual(zep._safe_session_id("locomo::conv-50"), "q4-locomo__conv-50")


class TestSessionNaming(unittest.TestCase):
    """Session IDs must be deterministic from conv_id."""

    def test_session_name_prefix(self):
        """Ensure naming convention: q4-<conv_id> for LoCoMo-style ids."""
        zep = _fresh_adapter()
        zep._wait_for_embeddings = lambda *a, **kw: None  # skip docker poll in unit test

        mock_client = MagicMock()
        # get_session raises to simulate "not found" -> triggers add_session
        mock_client.memory.get_session.side_effect = Exception("not found")
        mock_client.memory.add_session.return_value = MagicMock()
        mock_client.memory.add_memory.return_value = MagicMock()
        zep._client = mock_client

        chunks = [
            {"id": "conv-48::D2:13", "text": "Deborah finds peace in nature."},
            {"id": "conv-48::D4:34", "text": "Mountains give her serenity."},
        ]
        result = zep.ingest_corpus(chunks)

        calls = mock_client.memory.add_session.call_args_list
        self.assertEqual(len(calls), 1)
        # add_session takes a Session positional arg in 1.5.0
        session_arg = calls[0].args[0]
        self.assertEqual(session_arg.session_id, "q4-conv-48")

        self.assertEqual(result["sessions_created"], 1)
        self.assertEqual(result["messages_added"], 2)
        self.assertEqual(result["errors"], 0)


class TestIdempotentSessionCreation(unittest.TestCase):
    """ingest_corpus must not recreate sessions that already exist."""

    def test_existing_session_not_recreated(self):
        """If get_session succeeds, add_session should NOT be called."""
        zep = _fresh_adapter()
        zep._wait_for_embeddings = lambda *a, **kw: None

        mock_client = MagicMock()
        mock_client.memory.get_session.return_value = MagicMock()
        mock_client.memory.add_memory.return_value = MagicMock()
        zep._client = mock_client

        chunks = [{"id": "conv-48::D2:13", "text": "Deborah finds peace in nature."}]
        zep.ingest_corpus(chunks)

        mock_client.memory.add_session.assert_not_called()
        mock_client.memory.add_memory.assert_called_once()


class TestGoldIdRoundTrip(unittest.TestCase):
    """Gold IDs stored in metadata must survive the ingest round-trip."""

    def test_metadata_contains_gold_id(self):
        """Messages added to Zep must include gold_id in metadata."""
        zep = _fresh_adapter()
        zep._wait_for_embeddings = lambda *a, **kw: None

        mock_client = MagicMock()
        mock_client.memory.get_session.side_effect = Exception("not found")
        mock_client.memory.add_session.return_value = MagicMock()
        mock_client.memory.add_memory.return_value = MagicMock()
        zep._client = mock_client

        gold_id = "conv-48::D2:13"
        chunks = [{"id": gold_id, "text": "Deborah finds peace in nature."}]
        zep.ingest_corpus(chunks)

        add_calls = mock_client.memory.add_memory.call_args_list
        self.assertEqual(len(add_calls), 1)
        # signature: (session_id, Memory(messages=...))
        memory_arg = add_calls[0].args[1]
        self.assertTrue(len(memory_arg.messages) > 0, "Expected at least one message")
        msg = memory_arg.messages[0]
        meta = msg.metadata
        self.assertIn("gold_id", meta)
        self.assertEqual(meta["gold_id"], gold_id)


class TestMultipleConversationGroups(unittest.TestCase):
    """Chunks from different conversations must land in separate sessions."""

    def test_two_convs_two_sessions(self):
        zep = _fresh_adapter()
        zep._wait_for_embeddings = lambda *a, **kw: None

        mock_client = MagicMock()
        mock_client.memory.get_session.side_effect = Exception("not found")
        mock_client.memory.add_session.return_value = MagicMock()
        mock_client.memory.add_memory.return_value = MagicMock()
        zep._client = mock_client

        chunks = [
            {"id": "conv-48::D2:13", "text": "Alpha text."},
            {"id": "conv-48::D4:34", "text": "Alpha text 2."},
            {"id": "conv-50::D12:2", "text": "Beta text."},
        ]
        result = zep.ingest_corpus(chunks)
        self.assertEqual(result["sessions_created"], 2)

        all_add_calls = mock_client.memory.add_memory.call_args_list
        total_msgs = sum(len(c.args[1].messages) for c in all_add_calls)
        self.assertEqual(total_msgs, 3)


class TestExplicitConvId(unittest.TestCase):
    """Explicit conv_id field overrides the derived grouping."""

    def test_explicit_conv_id_used(self):
        zep = _fresh_adapter()
        zep._wait_for_embeddings = lambda *a, **kw: None

        mock_client = MagicMock()
        mock_client.memory.get_session.side_effect = Exception("not found")
        mock_client.memory.add_session.return_value = MagicMock()
        mock_client.memory.add_memory.return_value = MagicMock()
        zep._client = mock_client

        chunks = [
            {"id": "some-id-1", "text": "Text A.", "conv_id": "custom-session"},
            {"id": "some-id-2", "text": "Text B.", "conv_id": "custom-session"},
        ]
        zep.ingest_corpus(chunks)

        calls = mock_client.memory.add_session.call_args_list
        session_ids = [c.args[0].session_id for c in calls]
        self.assertIn("q4-custom-session", session_ids)
        self.assertEqual(len(set(session_ids)), 1, "Both chunks should land in the same session")


class TestSearchMapsGoldId(unittest.TestCase):
    """search() must map message metadata gold_id -> result id field."""

    def test_gold_id_extracted_when_present(self):
        zep = _fresh_adapter()
        mock_client = MagicMock()
        zep._client = mock_client
        zep._sessions = ["q4-conv-48"]

        msg = _mock_message(
            "Deborah finds peace in nature.",
            metadata={"gold_id": "conv-48::D2:13"},
            uuid="zep-uuid-xyz",
        )
        result = _mock_search_result(msg, dist=0.95)
        mock_client.memory.search_memory.return_value = [result]

        results = zep.search("peace", k=5)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["id"], "conv-48::D2:13")
        self.assertAlmostEqual(results[0]["score"], 0.95)
        self.assertEqual(results[0]["source"], "q4-conv-48")

    def test_fallback_to_zep_uuid_when_no_gold_id(self):
        """When metadata has no gold_id, result id falls back to Zep message UUID."""
        zep = _fresh_adapter()
        mock_client = MagicMock()
        zep._client = mock_client
        zep._sessions = ["q4-conv-48"]

        msg = _mock_message("Some text", metadata={}, uuid="zep-uuid-abc123")
        result = _mock_search_result(msg, dist=0.9)
        mock_client.memory.search_memory.return_value = [result]

        results = zep.search("test query", k=5)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["id"], "zep-uuid-abc123")


class TestSearchDeduplication(unittest.TestCase):
    """Duplicate results from multiple sessions must be collapsed."""

    def test_dedup_same_gold_id(self):
        zep = _fresh_adapter()
        mock_client = MagicMock()
        zep._client = mock_client
        zep._sessions = ["q4-conv-48", "q4-conv-50"]

        # Session 1 returns gold_id D2:13 with high score
        # Session 2 returns same gold_id D2:13 with lower score + a new gold_id D12:2
        def side_effect(session_id, payload, limit=None):
            if session_id == "q4-conv-48":
                return [
                    _mock_search_result(
                        _mock_message("Text", {"gold_id": "conv-48::D2:13"}), dist=0.95
                    )
                ]
            return [
                _mock_search_result(
                    _mock_message("Text", {"gold_id": "conv-48::D2:13"}), dist=0.80
                ),
                _mock_search_result(
                    _mock_message("Text", {"gold_id": "conv-50::D12:2"}), dist=0.70
                ),
            ]

        mock_client.memory.search_memory.side_effect = side_effect
        results = zep.search("peace", k=10)
        ids = [r["id"] for r in results]
        self.assertEqual(len(ids), len(set(ids)), "Duplicate IDs must be collapsed")
        self.assertEqual(len(results), 2)
        # higher-scoring D2:13 wins
        self.assertEqual(results[0]["id"], "conv-48::D2:13")
        self.assertAlmostEqual(results[0]["score"], 0.95)


class TestValidateStaticChecks(unittest.TestCase):
    """validate() must not crash and must return the correct shape."""

    def test_validate_ok_when_sdk_installed_and_key_set(self):
        """If zep_python is importable and OPENAI_API_KEY set, ok=True even when Zep daemon is down."""
        zep = _fresh_adapter()
        env_patch = {"OPENAI_API_KEY": "sk-test"}
        with patch.dict(os.environ, env_patch, clear=False):
            with patch("requests.get", side_effect=Exception("connection refused")):
                result = zep.validate()
        self.assertIn("ok", result)
        self.assertIn("version", result)
        self.assertIn("error", result)
        self.assertIn("notes", result)
        self.assertTrue(result["ok"])

    def test_validate_missing_openai_key(self):
        """OPENAI_API_KEY missing → ok=False (required for embeddings)."""
        zep = _fresh_adapter()
        env = os.environ.copy()
        env.pop("OPENAI_API_KEY", None)
        with patch.dict(os.environ, env, clear=True):
            with patch("requests.get", side_effect=Exception("offline")):
                result = zep.validate()
        self.assertFalse(result["ok"])
        self.assertIn("OPENAI_API_KEY", result["error"])

    def test_validate_returns_all_required_keys(self):
        """validate() result must always have ok/error/version/notes."""
        zep = _fresh_adapter()
        with patch("requests.get", side_effect=Exception("offline")):
            result = zep.validate()
        for key in ("ok", "error", "version", "notes"):
            self.assertIn(key, result, f"Missing key: {key}")


class TestSearchFallbackSingleSession(unittest.TestCase):
    """When no sessions are ingested, search falls back to ZEP_SESSION_ID env."""

    def test_fallback_uses_env_session_id(self):
        zep = _fresh_adapter()
        mock_client = MagicMock()
        zep._client = mock_client
        # _sessions is empty — triggers fallback
        mock_client.memory.search_memory.return_value = []

        with patch.dict(os.environ, {"ZEP_SESSION_ID": "my-custom-session"}):
            results = zep.search("test", k=5)

        # search_memory called with the env-provided session
        args, _ = mock_client.memory.search_memory.call_args
        self.assertEqual(args[0], "my-custom-session")
        self.assertIsInstance(results, list)

    def test_fallback_aborta_em_vez_de_devolver_vazio_quando_nao_ha_env(self):
        """
        ⚠️ ESTE TESTE FIXAVA O DEFEITO. Ele chamava-se
        `test_fallback_returns_empty_when_no_env` e exigia `results == []` quando
        não há sessões nem `ZEP_SESSION_ID` — isto é, garantia por contrato o
        comportamento que fazia a coluna do Zep sair **nDCG=0**.

        A fase de busca do harness roda noutro processo que a ingestão, logo
        `_sessions` nasce vazio e este era o caminho **normal**, não uma borda.
        Medido 2026-09-10: 5 de 5 consultas devolveram `hits=0` sobre um índice
        COM dados, e nada no retorno dizia por quê.

        Um zero por **configuração** e um zero por **retrieval** têm de ser
        distinguíveis. Invertido de propósito: agora exige o `raise`.

        🔑 Teste que fixa o comportamento errado é pior que teste nenhum — ele
        transforma o defeito em contrato e faz a correção parecer regressão.
        """
        zep = _fresh_adapter()
        zep._client = MagicMock()
        zep._sessions = []

        env = os.environ.copy()
        env.pop("ZEP_SESSION_ID", None)
        with patch.dict(os.environ, env, clear=True):
            with self.assertRaises(RuntimeError) as ctx:
                zep.search("test", k=5)
        self.assertIn("sessao", str(ctx.exception).lower())


# ---------------------------------------------------------------------------
# Integration tests — require live Zep OSS
# ---------------------------------------------------------------------------


@integration
class TestIntegrationSetup(unittest.TestCase):
    """validate() + setup() + teardown() work against live Zep."""

    def test_validate_reports_healthy(self):
        zep = _fresh_adapter()
        result = zep.validate()
        self.assertTrue(result["ok"], f"validate() failed: {result}")
        self.assertIn("healthy", result["notes"])

    def test_setup_teardown_idempotent(self):
        zep = _fresh_adapter()
        zep.setup()
        zep.setup()  # second call is a no-op
        zep.teardown()
        zep.teardown()  # double teardown is safe


@integration
class TestIntegrationIngestAndSearch(unittest.TestCase):
    """End-to-end: ingest chunks -> search returns mapped gold IDs."""

    _CONV_ID = "integration-test-conv"

    def setUp(self):
        self.zep = _fresh_adapter()
        # Skip docker exec poll in tests — we wait manually below
        self.zep._wait_for_embeddings = lambda *a, **kw: __import__("time").sleep(6)
        self.zep.setup()

    def tearDown(self):
        self.zep.teardown()

    def test_ingest_creates_sessions(self):
        chunks = [
            {"id": f"{self._CONV_ID}::chunk-1", "text": "Deborah finds peace in mountains."},
            {"id": f"{self._CONV_ID}::chunk-2", "text": "She meditates at dawn each day."},
        ]
        result = self.zep.ingest_corpus(chunks)
        self.assertEqual(result["errors"], 0, f"Ingest errors: {result['errors']}")
        self.assertGreater(result["messages_added"], 0)
        self.assertGreater(result["sessions_created"], 0)

    def test_search_returns_valid_items(self):
        """search() returns list[dict] with required id/score/text/source keys."""
        chunks = [
            {"id": f"{self._CONV_ID}::chunk-3", "text": "The lake at sunset fills her with calm."},
        ]
        self.zep.ingest_corpus(chunks)
        results = self.zep.search("lake sunset calm", k=5)

        self.assertIsInstance(results, list)
        for item in results:
            for key in ("id", "score", "text", "source"):
                self.assertIn(key, item, f"Missing key {key!r} in result")
            self.assertIsInstance(item["id"], str)
            self.assertTrue(len(item["id"]) > 0, "id must be non-empty")


if __name__ == "__main__":
    unittest.main()


# ── A espera de embeddings comparava GLOBAL contra INCREMENTO (2026-09-10) ────


def test_espera_de_embeddings_usa_linha_de_base_e_nao_o_incremento():
    """
    A espera tem de comparar `base + adicionadas`, nunca só `adicionadas`.

    Medido 2026-09-10: o código comparava o total GLOBAL de `message_embedding`
    contra o incremento DAQUELA chamada, e imprimia `embeddings ready: 170/1`.
    Depois das primeiras conversas o global é sempre muito maior que o incremento,
    logo `count >= expected` era verdade IMEDIATAMENTE — a espera nunca esperava,
    e a corrida seguia sobre um corpus meio embedado, que é exactamente o que o
    docstring dela diz que existe para impedir.

    Guarda cujo predicado não pode detectar o estado que ele existe para detectar
    (regra 9 do CLAUDE.md).
    """
    fonte = Path(__file__).resolve().parent.parent / "adapters" / "zep.py"
    src = fonte.read_text()
    assert "_wait_for_embeddings(_base_embeddings + messages_added" in src, (
        "a espera voltou a comparar o total global contra o incremento"
    )
    # A base tem de ser lida ANTES da escrita, senão já inclui o que se escreveu.
    #
    # ⚠️ Ancorar DENTRO de `ingest_corpus`. A primeira versão deste probe usava
    # `src.index("client.memory.add_memory(")` e casava a MENÇÃO no docstring do
    # módulo (offset 927), não a chamada — e por isso falhava com e sem a mutação,
    # isto é, não discriminava nada.
    corpo = src[src.index("def ingest_corpus(") : src.index("def _conta_embeddings")]
    i_base = corpo.index("_base_embeddings = _conta_embeddings()")
    i_add = corpo.index("client.memory.add_memory(")
    assert i_base < i_add, "a linha de base é lida DEPOIS de escrever — inútil"


def test_conta_embeddings_devolve_zero_quando_nao_consegue_medir():
    """
    Não inventar número quando a medição falha: 0 faz a espera exigir apenas o
    incremento (comportamento antigo, conservador), enquanto um valor fabricado
    faria a espera exigir algo que nunca chega e travar até o timeout.
    """
    fonte = Path(__file__).resolve().parent.parent / "adapters" / "zep.py"
    src = fonte.read_text()
    i = src.index("def _conta_embeddings")
    corpo = src[i : src.index("def _wait_for_embeddings")]
    assert "except Exception:" in corpo and "return 0" in corpo, corpo[-200:]


# ── search() devolvendo [] por falta de sessão publica nDCG=0 (2026-09-10) ────


def test_search_recusa_quando_nao_ha_sessao_para_varrer(monkeypatch):
    """
    `_sessions` vazio é falha de CONFIGURAÇÃO, não resultado de retrieval.

    Medido 2026-09-10: num processo novo o rescan era opt-in, `_sessions` ficava
    `[]`, e `search()` devolvia lista vazia em 5 de 5 consultas sobre um índice
    COM dados. A fase de busca roda noutro processo que a ingestão ⇒ esse era o
    caminho NORMAL, e a coluna do Zep sairia nDCG=0, publicada como qualidade do
    sistema.

    Um zero por configuração e um zero por retrieval têm de ser distinguíveis.
    """
    mod = importlib.import_module("adapters.zep")
    monkeypatch.setattr(mod, "_sessions", [], raising=False)
    monkeypatch.setattr(mod, "_client", object(), raising=False)
    monkeypatch.delenv("ZEP_SESSION_ID", raising=False)
    monkeypatch.setattr(mod, "setup", lambda: None)

    with pytest.raises(RuntimeError) as exc:
        mod.search("qualquer coisa", k=10)
    msg = str(exc.value)
    assert "sessao" in msg.lower(), msg
    assert "NOX_ZEP_RESCAN_SESSIONS" in msg, "a mensagem tem de dizer a alavanca"
    assert "nDCG" in msg, "tem de dizer POR QUE devolver [] seria pior"


def test_rescan_de_sessoes_e_o_default_e_nao_opt_in():
    """
    O rescan tem de correr por DEFAULT. Opt-in significa que o caminho normal
    (processo novo na fase de busca) nasce sem sessões — e falha calada.
    """
    fonte = Path(__file__).resolve().parent.parent / "adapters" / "zep.py"
    src = fonte.read_text()
    corpo = src[src.index("def setup()") : src.index("def _rescan_sessions_from_zep")]
    assert 'NOX_ZEP_RESCAN_SESSIONS") != "0"' in corpo, (
        "o rescan voltou a ser opt-in: " + corpo[-300:]
    )


def test_espera_de_embeddings_tem_granularidade_configuravel():
    """
    O predicado garante correção; a granularidade só custa tempo — e custava
    ~2,7 h (510 conversas × ~2 polls × 10 s), medido.
    """
    fonte = Path(__file__).resolve().parent.parent / "adapters" / "zep.py"
    src = fonte.read_text()
    assert 'ZEP_EMBED_POLL_SECS' in src
    assert "time.sleep(10)" not in src, "o sleep fixo de 10s voltou"


# ── fan-out degradado publica menos recall como qualidade (2026-09-10) ────────


def test_search_aborta_quando_o_fanout_degrada_acima_do_limite():
    """
    Medido com 192 workers: sessões falham com `[Errno 9] Bad file descriptor`, e
    o código fazia `print + continue`. Robusto para produção, **fatal para
    medição**: uma query respondida por 480 de 510 sessões devolve menos recall
    por FALHA DE VARREDURA, e nada no retorno dizia isso.

    O guarda e a proveniência por item têm de existir os dois: o guarda impede o
    número inválido, a proveniência deixa o artefato auditável quando a
    degradação está abaixo do limite.
    """
    fonte = Path(__file__).resolve().parent.parent / "adapters" / "zep.py"
    src = fonte.read_text()
    assert "ZEP_MAX_ERRO_SESSAO" in src, "o guarda de varredura desapareceu"
    assert "erros_sessao.append" in src, "os erros voltaram a ser só impressos"
    assert '"sessoes_com_erro"' in src and '"sessoes_varridas"' in src, (
        "a proveniência da varredura não está em cada item"
    )
    # O guarda tem de vir ANTES da montagem da lista, senão devolve-se o número
    # degradado e só depois se reclama.
    corpo = src[src.index("def search(") : src.index("def _search_one")]
    assert corpo.index("ZEP_MAX_ERRO_SESSAO") < corpo.index("all_results.sort"), (
        "o guarda está DEPOIS da montagem — devolveria a lista degradada"
    )


def _adapter_com_sessoes(monkeypatch, n_sessoes: int, n_falhas: int):
    """Monta o fan-out real com `n_falhas` sessões que estouram. Stub por SUBTRAÇÃO."""
    mod = importlib.import_module("adapters.zep")
    sessoes = [f"q4-s{i:04d}" for i in range(n_sessoes)]
    ruins = set(sessoes[:n_falhas])

    class _Mem:
        def search_memory(self, sid, payload, limit=10):
            if sid in ruins:
                raise OSError(9, "Bad file descriptor")
            return []  # sessão sã, sem hits — o guarda é sobre VARREDURA, não recall

    # ⚠️ O `search()` importa `zep_python` TARDE (dentro da função). Sem injetar o
    # módulo em `sys.modules`, o teste morre de `ModuleNotFoundError` antes de
    # alcançar o guarda — que é a causa das 11 falhas pré-existentes desta suíte.
    # Stub por SUBTRAÇÃO: só o que o caminho real toca.
    falso = types.ModuleType("zep_python")
    falso.MemorySearchPayload = lambda text=None, **kw: types.SimpleNamespace(text=text)
    monkeypatch.setitem(sys.modules, "zep_python", falso)

    cli = types.SimpleNamespace(memory=_Mem())
    monkeypatch.setattr(mod, "_sessions", sessoes, raising=False)
    monkeypatch.setattr(mod, "_get_client", lambda: cli)
    monkeypatch.setattr(mod, "setup", lambda: None)
    monkeypatch.setenv("NOX_ZEP_SEARCH_WORKERS", "4")
    return mod


def test_fanout_com_5pct_de_falhas_aborta(monkeypatch):
    """5 de 100 sessões falhando (5% > 1%) ⇒ o número não é comparável ⇒ aborta."""
    mod = _adapter_com_sessoes(monkeypatch, 100, 5)
    with pytest.raises(RuntimeError) as exc:
        mod.search("qualquer", k=10)
    m = str(exc.value)
    assert "degradado" in m and "5 de 100" in m, m
    assert "NOX_ZEP_SEARCH_WORKERS" in m, "não diz a alavanca"


def test_fanout_com_1pct_de_falhas_nao_aborta(monkeypatch):
    """
    1 de 100 (1%, NÃO maior que o limite) tem de passar — o par completo
    `aborta`/`não aborta` é o que prova que o limite é o limite, e não que o
    guarda dispara sempre.
    """
    mod = _adapter_com_sessoes(monkeypatch, 100, 1)
    assert mod.search("qualquer", k=10) == []


def test_limite_default_e_um_por_cento(monkeypatch):
    """
    O DEFAULT é parte do guarda. Uma mutação que troque `"0.01"` por `1.0` deixa o
    guarda presente e inerte — e um teste que só procura o NOME da variável no
    fonte aprova isso (foi o que aconteceu: a mutação M3 não mordeu).
    """
    mod = _adapter_com_sessoes(monkeypatch, 100, 2)
    monkeypatch.delenv("ZEP_MAX_ERRO_SESSAO", raising=False)
    with pytest.raises(RuntimeError):
        mod.search("qualquer", k=10)   # 2% > 1% default
